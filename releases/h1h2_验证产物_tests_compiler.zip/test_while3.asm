  JMP main_entry
  JMP main_entry
oc:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
fn_exit0:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
main_entry:
  LDI r0,#0
  LDI r3,#0
STR r0,r3
il1:
  LDI r2,#0
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r0,#5
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il3
  LDI r0,#1
  JS il4
il3:
  LDI r0,#0
il4:
  LDI r1,#0
  CMP r0,r1
  JZ il2
  JMP il1
il2:
  LDI r2,#128
LDR r0,r2
  PUSH r0
  LDI r2,#132
LDR r0,r2
  PUSH r0
  LDI r2,#136
LDR r0,r2
  PUSH r0
  LDI r2,#140
LDR r0,r2
  PUSH r0
  LDI r2,#0
LDR r0,r2
  MOV r1,r0
  INC r0
  LDI r3,#0
STR r0,r3
  MOV r0,r1
  LDI r3,#128
STR r0,r3
  CALL oc
  POP r0
  LDI r3,#140
STR r0,r3
  POP r0
  LDI r3,#136
STR r0,r3
  POP r0
  LDI r3,#132
STR r0,r3
  POP r0
  LDI r3,#128
STR r0,r3
  LDI r2,#0
LDR r0,r2
  HLT
  HLT
printnum_sub:
  PUSH r0
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  MOV r1, r0
  LDI r2, #100
  LDI r3, #0
pn_hun5:
  CMP r1, r2
  JS pn_ten6
  SUB r1, r2
  LDI r0, #1
  ADD r3, r0
  JMP pn_hun5
pn_ten6:
  MOV r4, r1
  LDI r2, #10
  LDI r1, #0
pn_ten27:
  CMP r4, r2
  JS pn_uni
  SUB r4, r2
  LDI r0, #1
  ADD r1, r0
  JMP pn_ten27
pn_uni:
  PUSH r1
  LDI r0, #0
  CMP r3, r0
  JZ pn_skip_h8
  LDI r0, #48
  ADD r0, r3
  MOV r1, r0
  LDI r0, #0
  SYSCALL
pn_skip_h8:
  POP r1
  PUSH r1
  LDI r0, #0
  CMP r3, r0
  JZ pn_chk_ten9
  JMP pn_prt_ten10
pn_chk_ten9:
  LDI r0, #0
  CMP r1, r0
  JZ pn_skip_t10
pn_prt_ten10:
  LDI r0, #48
  ADD r0, r1
  MOV r1, r0
  LDI r0, #0
  SYSCALL
pn_skip_t10:
  POP r1
  MOV r0, r4
  LDI r1, #48
  ADD r0, r1
  MOV r1, r0
  LDI r0, #0
  SYSCALL
  POP r4
  POP r3
  POP r2
  POP r1
  POP r0
  RET
strcmp_sub:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  LDI r2,#128
LDR r1,r2
  LDI r2,#132
LDR r2,r2
sc_lp:
  LDR r3,r1
  LDR r4,r2
  CMP r3,r4
  JNZ sc_ne
  LDI r4,#0
  CMP r3,r4
  JZ sc_eq
  LDI r4,#1
  ADD r1,r4
  ADD r2,r4
  JMP sc_lp
sc_ne:
  LDI r0,#1
  JMP sc_ex
sc_eq:
  LDI r0,#0
sc_ex:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
strncpy_sub:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  LDI r2,#128
LDR r1,r2
  LDI r2,#132
LDR r2,r2
  LDI r4,#136
LDR r4,r4
sn_lp:
  LDI r3,#0
  CMP r4,r3
  JZ sn_ex
  LDR r3,r2
  STR r3,r1
  LDI r3,#1
  ADD r1,r3
  ADD r2,r3
  LDI r3,#1
  SUB r4,r3
  JMP sn_lp
sn_ex:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
memset_sub:
  PUSH r1
  PUSH r2
  PUSH r3
  LDI r2,#128
LDR r1,r2
  LDI r2,#132
LDR r2,r2
  LDI r3,#136
LDR r3,r3
ms_lp:
  LDI r0,#0
  CMP r3,r0
  JZ ms_ex
  STR r2,r1
  LDI r0,#1
  ADD r1,r0
  SUB r3,r0
  JMP ms_lp
ms_ex:
  POP r3
  POP r2
  POP r1
  RET
; pp=81 tok=37
