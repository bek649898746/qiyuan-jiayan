/* test while loop compilation */
int x;
int main(void){
 x=0;
 while(x<5){
   x=x+1;
 }
 return x;
}
