  JMP main_entry
  JMP main_entry
main_entry:
  LDI r0,#1
  LDI r3,#0
STR r0,r3
  LDI r2,#0
LDR r0,r2
  LDI r1,#0
  CMP r0,r1
  JNZ il2
  LDI r0,#0
  LDI r1,#0
  CMP r0,r1
  JNZ il2
  LDI r0,#0
  JMP il3
il2:
  LDI r0,#1
il3:
  LDI r1,#0
  CMP r0,r1
  JZ il0
  LDI r0,#1
  HLT
il0:
il1:
  LDI r0,#0
  HLT
