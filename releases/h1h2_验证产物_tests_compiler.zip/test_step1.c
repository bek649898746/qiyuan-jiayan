char src[512];char dbuf[256];int di;
int tt[128];char tn[128][32];
void doc(int c){if(di<255)dbuf[di]=c;di++;dbuf[di]=0;}
void scp(char*d,char*s){int i=0;while(s[i*4]){d[i*4]=s[i*4];i++;}d[i*4]=0;}
int main(void){
 scp(src,"int");
 di=0;doc(src[0]);doc(src[1]);doc(src[2]);
 putstr(dbuf);
 return 0;
}
