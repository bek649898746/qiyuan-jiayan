char buf[256];int bp;
void oc(int c){if(bp<255)buf[bp]=c;bp++;buf[bp]=0;}
void os(char*s){int i=0;while(s[i]){oc(s[i]);i=i+4;}}
int main(void){
 bp=0;
 os("HELLO");
 putstr(buf);
 return 0;
}
