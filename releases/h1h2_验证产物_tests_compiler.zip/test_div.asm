  JMP main_entry
main_entry:
  LDI r0,#100
  LDI r1,#5
  DIV r0,r1
  HLT
