  JMP main_entry
  JMP main_entry
lex:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  LDI r0,#0
  STRW r0,#324
  LDI r0,#0
  STRW r0,#320
il1:
  LDRW r0,#324
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  LDR r0,r1
  LDI r1,#0
  CMP r0,r1
  JZ il3
  LDRW r0,#320
  PUSH r0
  LDI r0,#10
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il4
  LDI r0,#1
  JS il5
il4:
  LDI r0,#0
il5:
  LDI r1,#0
  CMP r0,r1
  JZ il3
  LDI r0,#1
il3:
  LDI r1,#0
  CMP r0,r1
  JZ il2
il6:
  LDI r0,#1
  LDI r1,#0
  CMP r0,r1
  JZ il7
  LDRW r0,#324
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  LDR r0,r1
  PUSH r0
  LDI r0,#32
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il10
  LDI r0,#0
  JMP il11
il10:
  LDI r0,#1
il11:
  LDI r1,#0
  CMP r0,r1
  JZ il8
  LDRW r0,#324
  INC r0
  STRW r0,#324
  JMP il6
  JMP il9
il8:
il9:
  LDRW r0,#324
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  LDR r0,r1
  PUSH r0
  LDI r0,#10
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il14
  LDI r0,#0
  JMP il15
il14:
  LDI r0,#1
il15:
  LDI r1,#0
  CMP r0,r1
  JZ il12
  LDRW r0,#324
  INC r0
  STRW r0,#324
  JMP il6
  JMP il13
il12:
il13:
  LDRW r0,#324
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  LDR r0,r1
  PUSH r0
  LDI r0,#9
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il18
  LDI r0,#0
  JMP il19
il18:
  LDI r0,#1
il19:
  LDI r1,#0
  CMP r0,r1
  JZ il16
  LDRW r0,#324
  INC r0
  STRW r0,#324
  JMP il6
  JMP il17
il16:
il17:
  LDRW r0,#324
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  LDR r0,r1
  PUSH r0
  LDI r0,#13
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il22
  LDI r0,#0
  JMP il23
il22:
  LDI r0,#1
il23:
  LDI r1,#0
  CMP r0,r1
  JZ il20
  LDRW r0,#324
  INC r0
  STRW r0,#324
  JMP il6
  JMP il21
il20:
il21:
  JMP il7
  JMP il6
il7:
  LDRW r0,#324
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  LDR r0,r1
  LDI r1,#0
  CMP r0,r1
  JZ il26
  LDI r0,#0
  JMP il27
il26:
  LDI r0,#1
il27:
  LDI r1,#0
  CMP r0,r1
  JZ il24
  JMP il25
il24:
il25:
  JMP il2
  LDRW r0,#320
  INC r0
  STRW r0,#320
  LDRW r0,#324
  INC r0
  STRW r0,#324
  JMP il1
il2:
fn_exit0:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
main_entry:
  LDI r0,#0
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  PUSH r1
  LDI r0,#105
  POP r1
  STR r0,r1
  LDI r0,#1
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  PUSH r1
  LDI r0,#110
  POP r1
  STR r0,r1
  LDI r0,#2
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  PUSH r1
  LDI r0,#116
  POP r1
  STR r0,r1
  LDI r0,#3
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  PUSH r1
  LDI r0,#32
  POP r1
  STR r0,r1
  LDI r0,#4
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  PUSH r1
  LDI r0,#109
  POP r1
  STR r0,r1
  LDI r0,#5
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  PUSH r1
  LDI r0,#97
  POP r1
  STR r0,r1
  LDI r0,#6
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  PUSH r1
  LDI r0,#105
  POP r1
  STR r0,r1
  LDI r0,#7
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  PUSH r1
  LDI r0,#110
  POP r1
  STR r0,r1
  LDI r0,#8
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  PUSH r1
  LDI r0,#40
  POP r1
  STR r0,r1
  LDI r0,#9
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  PUSH r1
  LDI r0,#41
  POP r1
  STR r0,r1
  LDI r0,#10
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  PUSH r1
  LDI r0,#123
  POP r1
  STR r0,r1
  LDI r0,#11
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  PUSH r1
  LDI r0,#0
  POP r1
  STR r0,r1
  LDRW r0,#128
  STRW r0,#80
  LDRW r0,#132
  STRW r0,#84
  LDRW r0,#136
  STRW r0,#88
  LDRW r0,#140
  STRW r0,#92
  CALL lex
  LDRW r0,#80
  STRW r0,#128
  LDRW r0,#84
  STRW r0,#132
  LDRW r0,#88
  STRW r0,#136
  LDRW r0,#92
  STRW r0,#140
  LDRW r0,#320
  HLT
  HLT
printnum_sub:
  PUSH r0
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  MOV r1, r0
  LDI r2, #100
  LDI r3, #0
pn_hun28:
  CMP r1, r2
  JS pn_ten29
  SUB r1, r2
  LDI r0, #1
  ADD r3, r0
  JMP pn_hun28
pn_ten29:
  MOV r4, r1
  LDI r2, #10
  LDI r1, #0
pn_ten230:
  CMP r4, r2
  JS pn_uni
  SUB r4, r2
  LDI r0, #1
  ADD r1, r0
  JMP pn_ten230
pn_uni:
  PUSH r1
  LDI r0, #0
  CMP r3, r0
  JZ pn_skip_h31
  LDI r0, #48
  ADD r0, r3
  MOV r1, r0
  LDI r0, #0
  SYSCALL
pn_skip_h31:
  POP r1
  PUSH r1
  LDI r0, #0
  CMP r3, r0
  JZ pn_chk_ten32
  JMP pn_prt_ten33
pn_chk_ten32:
  LDI r0, #0
  CMP r1, r0
  JZ pn_skip_t33
pn_prt_ten33:
  LDI r0, #48
  ADD r0, r1
  MOV r1, r0
  LDI r0, #0
  SYSCALL
pn_skip_t33:
  POP r1
  MOV r0, r4
  LDI r1, #48
  ADD r0, r1
  MOV r1, r0
  LDI r0, #0
  SYSCALL
  POP r4
  POP r3
  POP r2
  POP r1
  POP r0
  RET
strcmp_sub:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  LDI r2,#128
LDR r1,r2
  LDI r2,#132
LDR r2,r2
sc_lp:
  LDR r3,r1
  LDR r4,r2
  CMP r3,r4
  JNZ sc_ne
  LDI r4,#0
  CMP r3,r4
  JZ sc_eq
  LDI r4,#4
  ADD r1,r4
  ADD r2,r4
  JMP sc_lp
sc_ne:
  LDI r0,#1
  JMP sc_ex
sc_eq:
  LDI r0,#0
sc_ex:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
strncpy_sub:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  LDI r2,#128
LDR r1,r2
  LDI r2,#132
LDR r2,r2
  LDI r4,#136
LDR r4,r4
sn_lp:
  LDI r3,#0
  CMP r4,r3
  JZ sn_ex
  LDR r3,r2
  STR r3,r1
  LDI r3,#4
  ADD r1,r3
  ADD r2,r3
  LDI r3,#1
  SUB r4,r3
  JMP sn_lp
sn_ex:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
memset_sub:
  PUSH r1
  PUSH r2
  PUSH r3
  LDI r2,#128
LDR r1,r2
  LDI r2,#132
LDR r2,r2
  LDI r3,#136
LDR r3,r3
ms_lp:
  LDI r0,#0
  CMP r3,r0
  JZ ms_ex
  STR r2,r1
  LDI r0,#4
  ADD r1,r0
  SUB r3,r0
  JMP ms_lp
ms_ex:
  POP r3
  POP r2
  POP r1
  RET
; pp=460 tok=238
