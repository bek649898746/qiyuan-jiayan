#define MAXL 4096
#define MAXLB 64
static char LNS[MAXL][128];
static int NL;
static char LN[MAXLB][64];
static int LA[MAXLB];
static int NB;
int main(){return 0;}