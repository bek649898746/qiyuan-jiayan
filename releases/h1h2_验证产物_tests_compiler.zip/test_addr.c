int test_bp;char test_buf[64];
int main(void){
 test_bp=0;
 test_buf[0]=72;test_buf[4]=105;test_buf[8]=0;
 putstr(test_buf);
 return 0;
}
