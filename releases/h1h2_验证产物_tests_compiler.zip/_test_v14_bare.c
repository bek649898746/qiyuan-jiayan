#include <stdio.h>
#include <string.h>
int tt[128];int tv[128];char tn[128][32];int tc;int ti;
char src[256];char out[4096];int op;
int isdig(int c){if(c>47&&c<58)return 1;return 0;}
int isidc(int c){if((c>96&&c<123)||(c>64&&c<91)||c==95)return 1;return 0;}
int isan(int c){if(isdig(c)||isidc(c))return 1;return 0;}
int seq(char*a,char*b){int i=0;while(a[i]&&b[i]&&a[i]==b[i])i+=4;if(a[i]==b[i])return 1;return 0;}
void oc(int c){if(op<4095)out[op]=c;op++;out[op]=0;}
void os(char*s){int i=0;while(s[i]){oc(s[i]);i++;}}
void on(int v){char b[16];int i=14;b[14]=0;b[15]=0;
 while(v>0&&i>0){b[--i]=48+(v%10);v=v/10;}
 if(i==14){oc(48);return;}while(b[i]){oc(b[i]);i++;}}
int ilab;
void lex(void){
 int i;i=0;tc=0;
 while(src[i]&&tc<128){
  while(1){
   if(src[i]==32){i++;continue;}
   if(src[i]==10){i++;continue;}
   if(src[i]==9){i++;continue;}
   if(src[i]==13){i++;continue;}
   break;
  }
  if(!src[i]){tc=128;continue;}char c=src[i];
  if(c==40){tt[tc]=8;i++;}else if(c==41){tt[tc]=9;i++;}
  else if(c==123){tt[tc]=10;i++;}else if(c==125){tt[tc]=11;i++;}
  else if(c==59){tt[tc]=12;i++;}
  else if(c==61){tt[tc]=13;i++;}
  else if(c==43){tt[tc]=14;i++;}else if(c==45){tt[tc]=15;i++;}else if(c==42){tt[tc]=16;i++;}
  else if(isdig(c)){tt[tc]=7;tv[tc]=0;
   while(isdig(src[i])){tv[tc]=tv[tc]*10+(src[i]-48);i++;}}
  else if(isidc(c)){int j;j=0;
   while(isan(src[i])||src[i]==95){if(j<31){tn[tc][j]=src[i];j++;}i++;}tn[tc][j]=0;
   if(tn[tc][0]==105&&tn[tc][1]==110&&tn[tc][2]==116&&tn[tc][3]==0)tt[tc]=1;
   else if(tn[tc][0]==114&&tn[tc][1]==101&&tn[tc][2]==116&&tn[tc][3]==117&&tn[tc][4]==114&&tn[tc][5]==110&&tn[tc][6]==0)tt[tc]=2;
   else tt[tc]=6;
  }else i++;
  tc++;
 }
 tt[tc]=0;
}
char sn[32][32];int sa[32];int sc;
int sv_tc(int tidx){
 for(int i=0;i<sc;i++){
  int eq=1;for(int j=0;j<32;j++){if(tn[tidx][j]!=sn[i][j]){eq=0;break;}if(!tn[tidx][j])break;}
  if(eq)return sa[i];
 }
 if(sc>=32)return 0;
 for(int j=0;j<32;j++){sn[sc][j]=tn[tidx][j];if(!tn[tidx][j])break;}
 sa[sc]=sc*4;sc++;return sa[sc-1];
}
int sf_tc(int tidx){
 for(int i=0;i<sc;i++){
  int eq=1;for(int j=0;j<32;j++){if(tn[tidx][j]!=sn[i][j]){eq=0;break;}if(!tn[tidx][j])break;}
  if(eq)return sa[i];
 }
 return -1;
}
void expr(void);
void stmt(void);
void expr(void){
 int a;a=tt[ti];
 if(a==7){os("  LDI r0,#");on(tv[ti]);os("\n");ti++;}
 else if(a==6){int ad;ad=sf_tc(ti);ti++;
  if(ad>=0){os("  LDI r3,#");on(ad);os("\nLDR r0,r3\n");}}
 int op2;op2=tt[ti];
 if(op2==14||op2==15||op2==16){
  ti++;os("  LDI r3,#60\nSTR r0,r3\n");expr();
  os("  LDI r3,#64\nSTR r0,r3\n");os("  LDI r3,#60\nLDR r0,r3\n  LDI r3,#64\nLDR r1,r3\n");
  if(op2==14)os("  ADD r0,r1\n");else if(op2==15)os("  SUB r0,r1\n");else os("  MUL r0,r1\n");
 }
}
void stmt(void){
 int a;a=tt[ti];
 if(a==1){ti++;
  if(tt[ti]==6){sv_tc(ti);ti++;
   if(tt[ti]==13){ti++;expr();int ad;ad=sf_tc(ti-3);
    if(ad>=0){os("  LDI r3,#");on(ad);os("\nSTR r0,r3\n");}}}
  if(tt[ti]==12)ti++;
 }else if(a==2){ti++;expr();os("  HLT\n");if(tt[ti]==12)ti++;}
 else if(a==10){ti++;while(tt[ti]!=11&&tt[ti]!=0)stmt();if(tt[ti]==11)ti++;}
 else if(a==6){int tidx;tidx=ti;ti++;
  if(tt[ti]==13){ti++;expr();int ad;ad=sf_tc(tidx);if(ad>=0){os("  LDI r3,#");on(ad);os("\nSTR r0,r3\n");}}
  if(tt[ti]==12)ti++;
 }else ti++;
}
void compile(void){
 ti=0;sc=0;ilab=0;
 os("  JMP main_entry\n");
 while(tt[ti]!=0){
  if(tt[ti]==1&&tt[ti+1]==6&&tt[ti+2]==8){
   int fn;fn=ti+1;ti+=2;
   int ismain;ismain=1;
   if(tn[fn][0]!=109)ismain=0;
   if(tn[fn][1]!=97)ismain=0;
   if(tn[fn][2]!=105)ismain=0;
   if(tn[fn][3]!=110)ismain=0;
   while(tt[ti]!=9&&tt[ti]!=0)ti++;if(tt[ti]==9)ti++;
   if(tt[ti]==10){ti++;
    if(ismain)os("main_entry:\n");else{os(tn[fn]);os(":\n");}
    while(tt[ti]!=11&&tt[ti]!=0)stmt();if(tt[ti]==11)ti++;
    if(ismain)os("  HLT\n");else os("  RET\n");
   }
  }else ti++;
 }
}
int main(void){
 strcpy(src, "int main(void){int a;a=42;return a;}");
 lex();
 printf("tc=%d\n", tc);
 for(int i=0;i<tc&&i<128;i++) printf(" tt[%d]=%d", i, tt[i]);
 printf("\n");
 for(int i=0;i<tc&&i<10;i++) printf(" tn[%d]=%s\n", i, tn[i]);
 ti=0;sc=0;ilab=0;op=0;compile();
 printf("=== output ===\n%s", out);
 printf("=== end ===\n");
 return 0;
}
