char src[256];
void scp_src(char*s){int i=0;while(s[i*4]){src[i]=s[i*4];i++;}src[i]=0;}
int main(void){
 scp_src("int main(void){int a;a=42;return a;}");
 return src[0];
}
