; Minimal OR test: a=0; if(a||1) return 1 else return 0
  JMP main_entry
main_entry:
  LDI r0,#0
  LDI r3,#0
STR r0,r3        ; a = 0 at addr 0
  
  ; Evaluate left: a
  LDI r2,#0
LDR r0,r2        ; r0 = a = 0
  
  ; || check left
  LDI r1,#0
  CMP r0,r1
  JNZ il2        ; a=0, ZF=1 → NOT taken
  
  ; Evaluate right: 1
  LDI r0,#1
  
  ; || check right
  LDI r1,#0
  CMP r0,r1
  JNZ il2        ; r0=1, ZF=0 → TAKEN → jump to il2
  
  ; Both false
  LDI r0,#0
  JMP il3
  
il2:
  LDI r0,#1      ; true
il3:
  ; if(result) return 1 else return 0
  LDI r1,#0
  CMP r0,r1
  JZ return0
  LDI r0,#1
  HLT
return0:
  LDI r0,#0
  HLT
