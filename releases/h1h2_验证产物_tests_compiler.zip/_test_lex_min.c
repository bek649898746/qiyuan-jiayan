int src[64];int tc;
void lex(void){
 int i;i=0;tc=0;
 while(src[i]&&tc<10){
  while(1){
   if(src[i]==32){i++;continue;}
   if(src[i]==10){i++;continue;}
   break;
  }
  tc++;
 }
}
int main(void){
 src[0]=105;src[4]=32;src[8]=110;src[12]=0;
 lex();return tc;
}
