/* Debug asm_p1 label counting */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#define OP_JMPW 6
#define ENC(op,rd,val) ((uint16_t)(((op)&0x1F)<<11)|(((rd)&7)<<8)|((val)&0xFF))
static uint16_t M[65536];

#define MAXL 4096
#define MAXLB 4096
char LNS[MAXL][128];int NL;
char LN[MAXLB][64];int LA[MAXLB];int NB;

static void asm_p1(){
 int a=256;
 for(int i=0;i<NL;i++){
  char*p=LNS[i];while(*p==' '||*p=='\t')p++;
  if(!*p||*p==';')continue;char*c=strchr(p,':');
  if(c){*c=0;strncpy(LN[NB],p,63);LN[NB][63]=0;LA[NB]=a;NB++;
   printf("  LABEL '%s' -> LA[%d]=%d\n",p,NB-1,a);
   char*r=c+1;while(*r==' '||*r=='\t')r++;continue;}a++;
 }
}
static int flb(char*s){for(int i=0;i<NB;i++)if(!strcmp(LN[i],s))return i;return-1;}

static int asm_assemble(const char*text){
 NL=0;NB=0;memset(M,0,sizeof(M));
 char buf[65536];strncpy(buf,text,65535);buf[65535]=0;
 char*tok=strtok(buf,"\n");while(tok&&NL<MAXL){strncpy(LNS[NL],tok,127);LNS[NL][127]=0;NL++;tok=strtok(NULL,"\n");}
 printf("asm_p1 start:\n");asm_p1();
 printf("\nSecond pass:\n");int a=256;
 for(int i=0;i<NL;i++){
  char*p=LNS[i];while(*p==' '||*p=='\t')p++;if(!*p||*p==';')continue;if(strchr(p,':')){printf("  SKIP label: %s\n",p);continue;}
  char w[16];int n1=0,n2=0,imm=0;sscanf(p,"%15s r%d",w,&n1);
  char*h=strchr(p,'#');if(h){imm=1;n2=atoi(h+1);}uint16_t e=0;
  if(!strcmp(w,"JMP")||!strcmp(w,"JZ")||!strcmp(w,"JNZ")){
   int op=8,opw=OP_JMPW;
   char lb[32];sscanf(p,"%*s %31s",lb);int f=flb(lb),off=(f>=0?LA[f]-(a+1):0);
   if(off>=-128&&off<128){e=ENC(op,0,off&0xFF);printf("  SHORT JMP %s(LA[%d]=%d) off=%d -> M[%d]\n",lb,f,LA[f],off,a);M[a++]=e;}
   else{printf("  WIDE JMP %s(LA[%d]=%d) -> M[%d]=JMPW M[%d]=%d\n",lb,f,LA[f],a,a+1,LA[f]);
    M[a]=(opw<<11);M[a+1]=LA[f];a+=2;continue;}
  }else if(!strcmp(w,"HLT"))e=ENC(11,0,0);
  else if(!strcmp(w,"LDI"))e=ENC(2,n1,n2&0xFF);
  else continue;
  printf("  %s -> M[%d]=%u\n",p,a,e);M[a++]=e;
 }
 printf("\nFinal: a=%d M[256]=%u M[257]=%u M[258]=%u M[259]=%u M[260]=%u M[261]=%u\n",a,M[256],M[257],M[258],M[259],M[260],M[261]);
 return a;
}

int main(){
 const char*src=
  "  JMP main_entry\n"
  "  JMP main_entry\n"
  "main_entry:\n"
  "  LDI r0,#42\n"
  "  HLT\n";
 int n=asm_assemble(src);
 printf("\n=== RUN VM ===\n");
 int PC=0,RUN=1,R[8]={0};int ZF=0,SF=0,SP=65280;int s=0;
 while(RUN&&PC>=0&&PC<65536&&s<100){
  uint16_t I=M[PC++];s++;int op=(I>>11)&0x1F,rd=(I>>8)&7,val=I&0xFF;
  printf("step %d: PC=%d M=%u op=%d\n",s,PC-1,I,op);
  switch(op){
  case 0:break;case 2:R[rd]=val;printf("  LDI r%d,#%d\n",rd,val);break;
  case 6:if(PC<65535){printf("  JMPW -> M[%d]=%d\n",PC,M[PC]);PC=M[PC];}break;
  case 8:PC+=(int8_t)val;printf("  JMP -> PC=%d\n",PC);break;
  case 11:RUN=0;break;
  default:printf("  unknown op=%d\n",op);break;
  }
 }
 printf("r0=%d PC=%d steps=%d\n",R[0],PC,s);
 return 0;
}
