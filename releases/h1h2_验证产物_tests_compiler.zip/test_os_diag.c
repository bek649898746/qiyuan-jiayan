char out[128];int op;
void oc(int c){if(op<127)out[op]=c;op++;out[op]=0;}
void os(char*s){oc(48+(s[0*4]/10)%10);oc(48+s[0*4]%10);}
int main(void){
 op=0;
 os("TEST");
 putstr(out);
 return 0;
}
