  JMP main_entry
  JMP main_entry
isdig:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  LDI r2,#128
LDR r0,r2
  PUSH r0
  LDI r0,#47
  LDI r1,#0
  CMP r0,r1
  JZ il5
  LDI r2,#128
LDR r0,r2
  PUSH r0
  LDI r0,#58
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il6
  LDI r0,#1
  JS il7
il6:
  LDI r0,#0
il7:
  LDI r1,#0
  CMP r0,r1
  JZ il5
  LDI r0,#1
il5:
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il3
  JS il3
  LDI r0,#1
  JMP il4
il3:
  LDI r0,#0
il4:
  LDI r1,#0
  CMP r0,r1
  JZ il1
  JMP il2
il1:
il2:
  LDI r0,#1
  JMP fn_exit0
  LDI r0,#0
  JMP fn_exit0
fn_exit0:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
isidc:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  LDI r2,#128
LDR r0,r2
  PUSH r0
  LDI r0,#96
  LDI r1,#0
  CMP r0,r1
  JZ il13
  LDI r2,#128
LDR r0,r2
  PUSH r0
  LDI r0,#123
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il14
  LDI r0,#1
  JS il15
il14:
  LDI r0,#0
il15:
  LDI r1,#0
  CMP r0,r1
  JZ il13
  LDI r0,#1
il13:
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il11
  JS il11
  LDI r0,#1
  JMP il12
il11:
  LDI r0,#0
il12:
  LDI r1,#0
  CMP r0,r1
  JNZ il16
  LDI r2,#128
LDR r0,r2
  PUSH r0
  LDI r0,#64
  LDI r1,#0
  CMP r0,r1
  JZ il20
  LDI r2,#128
LDR r0,r2
  PUSH r0
  LDI r0,#91
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il21
  LDI r0,#1
  JS il22
il21:
  LDI r0,#0
il22:
  LDI r1,#0
  CMP r0,r1
  JZ il20
  LDI r0,#1
il20:
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il18
  JS il18
  LDI r0,#1
  JMP il19
il18:
  LDI r0,#0
il19:
  LDI r1,#0
  CMP r0,r1
  JNZ il23
  LDI r2,#128
LDR r0,r2
  PUSH r0
  LDI r0,#95
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il25
  LDI r0,#0
  JMP il26
il25:
  LDI r0,#1
il26:
  LDI r1,#0
  CMP r0,r1
  JNZ il23
  LDI r0,#0
  JMP il24
il23:
  LDI r0,#1
il24:
  LDI r1,#0
  CMP r0,r1
  JNZ il16
  LDI r0,#0
  JMP il17
il16:
  LDI r0,#1
il17:
  LDI r1,#0
  CMP r0,r1
  JZ il9
  JMP il10
il9:
il10:
  LDI r0,#1
  JMP fn_exit8
  LDI r0,#0
  JMP fn_exit8
fn_exit8:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
isan:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  LDI r2,#128
LDR r0,r2
  LDI r3,#40
STR r0,r3
  LDRW r0,#128
  STRW r0,#80
  LDRW r0,#132
  STRW r0,#84
  LDRW r0,#136
  STRW r0,#88
  LDRW r0,#140
  STRW r0,#92
  LDI r3,#40
LDR r0,r3
  LDI r3,#128
STR r0,r3
  CALL isdig
  LDRW r0,#80
  STRW r0,#128
  LDRW r0,#84
  STRW r0,#132
  LDRW r0,#88
  STRW r0,#136
  LDRW r0,#92
  STRW r0,#140
  LDI r1,#0
  CMP r0,r1
  JNZ il30
  LDI r2,#128
LDR r0,r2
  LDI r3,#40
STR r0,r3
  LDRW r0,#128
  STRW r0,#80
  LDRW r0,#132
  STRW r0,#84
  LDRW r0,#136
  STRW r0,#88
  LDRW r0,#140
  STRW r0,#92
  LDI r3,#40
LDR r0,r3
  LDI r3,#128
STR r0,r3
  CALL isidc
  LDRW r0,#80
  STRW r0,#128
  LDRW r0,#84
  STRW r0,#132
  LDRW r0,#88
  STRW r0,#136
  LDRW r0,#92
  STRW r0,#140
  LDI r1,#0
  CMP r0,r1
  JNZ il30
  LDI r0,#0
  JMP il31
il30:
  LDI r0,#1
il31:
  LDI r1,#0
  CMP r0,r1
  JZ il28
  JMP il29
il28:
il29:
  LDI r0,#1
  JMP fn_exit27
  LDI r0,#0
  JMP fn_exit27
fn_exit27:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
seq:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
il33:
  LDI r2,#128
LDR r0,r2
  LDI r3,#68
STR r0,r3
  LDRW r0,#2980
  LDI r3,#64
STR r0,r3
  LDI r3,#68
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  LDI r1,#0
  CMP r0,r1
  JZ il35
  LDI r2,#132
LDR r0,r2
  LDI r3,#68
STR r0,r3
  LDRW r0,#2980
  LDI r3,#64
STR r0,r3
  LDI r3,#68
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  LDI r1,#0
  CMP r0,r1
  JZ il36
  LDI r2,#128
LDR r0,r2
  LDI r3,#68
STR r0,r3
  LDRW r0,#2980
  LDI r3,#64
STR r0,r3
  LDI r3,#68
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  PUSH r0
  LDI r2,#132
LDR r0,r2
  LDI r3,#68
STR r0,r3
  LDRW r0,#2980
  LDI r3,#64
STR r0,r3
  LDI r3,#68
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il37
  LDI r0,#0
  JMP il38
il37:
  LDI r0,#1
il38:
  LDI r1,#0
  CMP r0,r1
  JZ il36
  LDI r0,#1
il36:
  LDI r1,#0
  CMP r0,r1
  JZ il35
  LDI r0,#1
il35:
  LDI r1,#0
  CMP r0,r1
  JZ il34
  JMP il33
il34:
  LDI r2,#128
LDR r0,r2
  LDI r3,#68
STR r0,r3
  LDRW r0,#2980
  LDI r3,#64
STR r0,r3
  LDI r3,#68
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  PUSH r0
  LDI r2,#132
LDR r0,r2
  LDI r3,#68
STR r0,r3
  LDRW r0,#2980
  LDI r3,#64
STR r0,r3
  LDI r3,#68
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il41
  LDI r0,#0
  JMP il42
il41:
  LDI r0,#1
il42:
  LDI r1,#0
  CMP r0,r1
  JZ il39
  JMP il40
il39:
il40:
  LDI r0,#1
  JMP fn_exit32
  LDI r0,#0
  JMP fn_exit32
fn_exit32:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
lex:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  LDI r0,#0
  STRW r0,#2984
  LDI r0,#0
  STRW r0,#2976
il44:
  LDRW r0,#2984
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  LDR r0,r1
  LDI r1,#0
  CMP r0,r1
  JZ il46
  LDRW r0,#2976
  PUSH r0
  LDI r0,#10
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il47
  LDI r0,#1
  JS il48
il47:
  LDI r0,#0
il48:
  LDI r1,#0
  CMP r0,r1
  JZ il46
  LDI r0,#1
il46:
  LDI r1,#0
  CMP r0,r1
  JZ il45
il49:
  LDI r0,#1
  LDI r1,#0
  CMP r0,r1
  JZ il50
  LDRW r0,#2984
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  LDR r0,r1
  PUSH r0
  LDI r0,#32
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il53
  LDI r0,#0
  JMP il54
il53:
  LDI r0,#1
il54:
  LDI r1,#0
  CMP r0,r1
  JZ il51
  LDRW r0,#2984
  INC r0
  STRW r0,#2984
  JMP il49
  JMP il52
il51:
il52:
  LDRW r0,#2984
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  LDR r0,r1
  PUSH r0
  LDI r0,#10
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il57
  LDI r0,#0
  JMP il58
il57:
  LDI r0,#1
il58:
  LDI r1,#0
  CMP r0,r1
  JZ il55
  LDRW r0,#2984
  INC r0
  STRW r0,#2984
  JMP il49
  JMP il56
il55:
il56:
  LDRW r0,#2984
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  LDR r0,r1
  PUSH r0
  LDI r0,#9
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il61
  LDI r0,#0
  JMP il62
il61:
  LDI r0,#1
il62:
  LDI r1,#0
  CMP r0,r1
  JZ il59
  LDRW r0,#2984
  INC r0
  STRW r0,#2984
  JMP il49
  JMP il60
il59:
il60:
  LDRW r0,#2984
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  LDR r0,r1
  PUSH r0
  LDI r0,#13
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il65
  LDI r0,#0
  JMP il66
il65:
  LDI r0,#1
il66:
  LDI r1,#0
  CMP r0,r1
  JZ il63
  LDRW r0,#2984
  INC r0
  STRW r0,#2984
  JMP il49
  JMP il64
il63:
il64:
  JMP il50
  JMP il49
il50:
  LDRW r0,#2984
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  LDR r0,r1
  LDI r1,#0
  CMP r0,r1
  JZ il69
  LDI r0,#0
  JMP il70
il69:
  LDI r0,#1
il70:
  LDI r1,#0
  CMP r0,r1
  JZ il67
  JMP il68
il67:
il68:
  JMP il45
  LDRW r0,#2984
  LDRW r0,#2988
  PUSH r0
  LDI r0,#40
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il73
  LDI r0,#0
  JMP il74
il73:
  LDI r0,#1
il74:
  LDI r1,#0
  CMP r0,r1
  JZ il71
  LDRW r0,#2976
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  LDI r4,#1
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  PUSH r1
  LDI r0,#8
  POP r1
  STR r0,r1
  LDRW r0,#2984
  INC r0
  STRW r0,#2984
  JMP il72
il71:
il72:
  LDRW r0,#2988
  PUSH r0
  LDI r0,#41
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il77
  LDI r0,#0
  JMP il78
il77:
  LDI r0,#1
il78:
  LDI r1,#0
  CMP r0,r1
  JZ il75
  LDRW r0,#2976
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  LDI r4,#1
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  PUSH r1
  LDI r0,#9
  POP r1
  STR r0,r1
  LDRW r0,#2984
  INC r0
  STRW r0,#2984
  JMP il76
il75:
il76:
  LDRW r0,#2988
  PUSH r0
  LDI r0,#123
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il81
  LDI r0,#0
  JMP il82
il81:
  LDI r0,#1
il82:
  LDI r1,#0
  CMP r0,r1
  JZ il79
  LDRW r0,#2976
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  LDI r4,#1
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  PUSH r1
  LDI r0,#10
  POP r1
  STR r0,r1
  LDRW r0,#2984
  INC r0
  STRW r0,#2984
  JMP il80
il79:
il80:
  LDRW r0,#2988
  PUSH r0
  LDI r0,#125
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il85
  LDI r0,#0
  JMP il86
il85:
  LDI r0,#1
il86:
  LDI r1,#0
  CMP r0,r1
  JZ il83
  LDRW r0,#2976
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  LDI r4,#1
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  PUSH r1
  LDI r0,#11
  POP r1
  STR r0,r1
  LDRW r0,#2984
  INC r0
  STRW r0,#2984
  JMP il84
il83:
il84:
  LDRW r0,#2988
  PUSH r0
  LDI r0,#59
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il89
  LDI r0,#0
  JMP il90
il89:
  LDI r0,#1
il90:
  LDI r1,#0
  CMP r0,r1
  JZ il87
  LDRW r0,#2976
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  LDI r4,#1
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  PUSH r1
  LDI r0,#12
  POP r1
  STR r0,r1
  LDRW r0,#2984
  INC r0
  STRW r0,#2984
  JMP il88
il87:
il88:
  LDRW r0,#2988
  PUSH r0
  LDI r0,#61
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il93
  LDI r0,#0
  JMP il94
il93:
  LDI r0,#1
il94:
  LDI r1,#0
  CMP r0,r1
  JZ il91
  LDRW r0,#2976
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  LDI r4,#1
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  PUSH r1
  LDI r0,#13
  POP r1
  STR r0,r1
  LDRW r0,#2984
  INC r0
  STRW r0,#2984
  JMP il92
il91:
il92:
  LDRW r0,#2988
  LDI r3,#40
STR r0,r3
  LDRW r0,#128
  STRW r0,#80
  LDRW r0,#132
  STRW r0,#84
  LDRW r0,#136
  STRW r0,#88
  LDRW r0,#140
  STRW r0,#92
  LDI r3,#40
LDR r0,r3
  LDI r3,#128
STR r0,r3
  CALL isdig
  LDRW r0,#80
  STRW r0,#128
  LDRW r0,#84
  STRW r0,#132
  LDRW r0,#88
  STRW r0,#136
  LDRW r0,#92
  STRW r0,#140
  LDI r1,#0
  CMP r0,r1
  JZ il95
  LDRW r0,#2976
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  LDI r4,#1
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  PUSH r1
  LDI r0,#7
  POP r1
  STR r0,r1
  LDRW r0,#2976
  ADD r0,r0
  ADD r0,r0
  LDI r1,#80
  LDI r4,#1
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  PUSH r1
  LDI r0,#0
  POP r1
  STR r0,r1
il97:
  LDI r0,#1
  LDI r1,#0
  CMP r0,r1
  JZ il98
  LDRW r0,#2984
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  LDR r0,r1
  LDI r3,#40
STR r0,r3
  LDRW r0,#128
  STRW r0,#80
  LDRW r0,#132
  STRW r0,#84
  LDRW r0,#136
  STRW r0,#88
  LDRW r0,#140
  STRW r0,#92
  LDI r3,#40
LDR r0,r3
  LDI r3,#128
STR r0,r3
  CALL isdig
  LDRW r0,#80
  STRW r0,#128
  LDRW r0,#84
  STRW r0,#132
  LDRW r0,#88
  STRW r0,#136
  LDRW r0,#92
  STRW r0,#140
  LDI r1,#0
  CMP r0,r1
  JZ il101
  LDI r0,#0
  JMP il102
il101:
  LDI r0,#1
il102:
  LDI r1,#0
  CMP r0,r1
  JZ il99
  JMP il100
il99:
il100:
  JMP il98
  LDRW r0,#2976
  ADD r0,r0
  ADD r0,r0
  LDI r1,#80
  LDI r4,#1
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  PUSH r1
  LDRW r0,#2976
  ADD r0,r0
  ADD r0,r0
  LDI r1,#80
  LDI r4,#1
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  LDR r0,r1
  PUSH r0
  LDI r0,#10
  PUSH r0
  LDRW r0,#2984
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  LDR r0,r1
  PUSH r0
  LDI r0,#48
  MOV r1,r0
  POP r0
  SUB r0,r1
  MOV r1,r0
  POP r0
  ADD r0,r1
  MOV r1,r0
  POP r0
  MUL r0,r1
  POP r1
  STR r0,r1
  LDRW r0,#2984
  INC r0
  STRW r0,#2984
  JMP il97
il98:
  JMP il96
il95:
il96:
  LDRW r0,#2988
  LDI r3,#40
STR r0,r3
  LDRW r0,#128
  STRW r0,#80
  LDRW r0,#132
  STRW r0,#84
  LDRW r0,#136
  STRW r0,#88
  LDRW r0,#140
  STRW r0,#92
  LDI r3,#40
LDR r0,r3
  LDI r3,#128
STR r0,r3
  CALL isidc
  LDRW r0,#80
  STRW r0,#128
  LDRW r0,#84
  STRW r0,#132
  LDRW r0,#88
  STRW r0,#136
  LDRW r0,#92
  STRW r0,#140
  LDI r1,#0
  CMP r0,r1
  JZ il103
  LDI r0,#0
  STRW r0,#2992
il105:
  LDI r0,#1
  LDI r1,#0
  CMP r0,r1
  JZ il106
  LDRW r0,#2984
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  LDR r0,r1
  LDI r3,#40
STR r0,r3
  LDRW r0,#128
  STRW r0,#80
  LDRW r0,#132
  STRW r0,#84
  LDRW r0,#136
  STRW r0,#88
  LDRW r0,#140
  STRW r0,#92
  LDI r3,#40
LDR r0,r3
  LDI r3,#128
STR r0,r3
  CALL isan
  LDRW r0,#80
  STRW r0,#128
  LDRW r0,#84
  STRW r0,#132
  LDRW r0,#88
  STRW r0,#136
  LDRW r0,#92
  STRW r0,#140
  LDI r1,#0
  CMP r0,r1
  JZ il109
  LDRW r0,#2984
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  LDR r0,r1
  PUSH r0
  LDI r0,#95
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il110
  LDI r0,#1
  JMP il111
il110:
  LDI r0,#0
il111:
  LDI r1,#0
  CMP r0,r1
  JZ il109
  LDI r0,#1
il109:
  LDI r1,#0
  CMP r0,r1
  JZ il112
  LDI r0,#0
  JMP il113
il112:
  LDI r0,#1
il113:
  LDI r1,#0
  CMP r0,r1
  JZ il107
  JMP il108
il107:
il108:
  JMP il106
  LDRW r0,#2992
  PUSH r0
  LDI r0,#31
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il116
  LDI r0,#1
  JS il117
il116:
  LDI r0,#0
il117:
  LDI r1,#0
  CMP r0,r1
  JZ il114
  LDRW r0,#2976
  ADD r0,r0
  ADD r0,r0
  ADD r0,r0
  ADD r0,r0
  ADD r0,r0
  ADD r0,r0
  ADD r0,r0
  LDI r1,#160
  LDI r4,#1
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  LDI r3,#60
STR r1,r3
  LDRW r0,#2992
  ADD r0,r0
  ADD r0,r0
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  PUSH r0
  LDRW r0,#2984
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  LDR r0,r1
  POP r1
  STR r0,r1
  LDRW r0,#2992
  INC r0
  STRW r0,#2992
  JMP il115
il114:
il115:
  LDRW r0,#2984
  INC r0
  STRW r0,#2984
  JMP il105
il106:
  LDRW r0,#2976
  ADD r0,r0
  ADD r0,r0
  ADD r0,r0
  ADD r0,r0
  ADD r0,r0
  ADD r0,r0
  ADD r0,r0
  LDI r1,#160
  LDI r4,#1
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  LDI r3,#60
STR r1,r3
  LDRW r0,#2992
  ADD r0,r0
  ADD r0,r0
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  PUSH r0
  LDI r0,#0
  POP r1
  STR r0,r1
  LDRW r0,#2976
  ADD r0,r0
  ADD r0,r0
  ADD r0,r0
  ADD r0,r0
  ADD r0,r0
  ADD r0,r0
  ADD r0,r0
  LDI r1,#160
  LDI r4,#1
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  MOV r0,r1
  LDI r3,#40
STR r0,r3
  LDI r0,#105
  STRW r0,#2996
  LDI r0,#110
  STRW r0,#3000
  LDI r0,#116
  STRW r0,#3004
  LDI r0,#0
  STRW r0,#3008
  LDI r0,#180
  LDI r4,#11
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r0,r4
  LDI r3,#44
STR r0,r3
  LDRW r0,#128
  STRW r0,#80
  LDRW r0,#132
  STRW r0,#84
  LDRW r0,#136
  STRW r0,#88
  LDRW r0,#140
  STRW r0,#92
  LDI r3,#40
LDR r0,r3
  LDI r3,#128
STR r0,r3
  LDI r3,#44
LDR r0,r3
  LDI r3,#132
STR r0,r3
  CALL seq
  LDRW r0,#80
  STRW r0,#128
  LDRW r0,#84
  STRW r0,#132
  LDRW r0,#88
  STRW r0,#136
  LDRW r0,#92
  STRW r0,#140
  LDI r1,#0
  CMP r0,r1
  JZ il118
  JMP il119
il118:
il119:
  LDRW r0,#2976
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  LDI r4,#1
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  PUSH r1
  LDI r0,#1
  POP r1
  STR r0,r1
  LDRW r0,#2976
  ADD r0,r0
  ADD r0,r0
  ADD r0,r0
  ADD r0,r0
  ADD r0,r0
  ADD r0,r0
  ADD r0,r0
  LDI r1,#160
  LDI r4,#1
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  MOV r0,r1
  LDI r3,#40
STR r0,r3
  LDI r0,#114
  STRW r0,#3012
  LDI r0,#101
  STRW r0,#3016
  LDI r0,#116
  STRW r0,#3020
  LDI r0,#117
  STRW r0,#3024
  LDI r0,#114
  STRW r0,#3028
  LDI r0,#110
  STRW r0,#3032
  LDI r0,#0
  STRW r0,#3036
  LDI r0,#196
  LDI r4,#11
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r0,r4
  LDI r3,#44
STR r0,r3
  LDRW r0,#128
  STRW r0,#80
  LDRW r0,#132
  STRW r0,#84
  LDRW r0,#136
  STRW r0,#88
  LDRW r0,#140
  STRW r0,#92
  LDI r3,#40
LDR r0,r3
  LDI r3,#128
STR r0,r3
  LDI r3,#44
LDR r0,r3
  LDI r3,#132
STR r0,r3
  CALL seq
  LDRW r0,#80
  STRW r0,#128
  LDRW r0,#84
  STRW r0,#132
  LDRW r0,#88
  STRW r0,#136
  LDRW r0,#92
  STRW r0,#140
  LDI r1,#0
  CMP r0,r1
  JZ il120
  JMP il121
il120:
il121:
  LDRW r0,#2976
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  LDI r4,#1
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  PUSH r1
  LDI r0,#2
  POP r1
  STR r0,r1
  LDRW r0,#2976
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  LDI r4,#1
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  PUSH r1
  LDI r0,#6
  POP r1
  STR r0,r1
  JMP il104
il103:
il104:
  LDRW r0,#2984
  INC r0
  STRW r0,#2984
  LDRW r0,#2976
  INC r0
  STRW r0,#2976
  JMP il44
il45:
  LDRW r0,#2976
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  LDI r4,#1
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  PUSH r1
  LDI r0,#0
  POP r1
  STR r0,r1
fn_exit43:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
main_entry:
  LDI r0,#0
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  PUSH r1
  LDI r0,#105
  POP r1
  STR r0,r1
  LDI r0,#1
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  PUSH r1
  LDI r0,#110
  POP r1
  STR r0,r1
  LDI r0,#2
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  PUSH r1
  LDI r0,#116
  POP r1
  STR r0,r1
  LDI r0,#3
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  PUSH r1
  LDI r0,#32
  POP r1
  STR r0,r1
  LDI r0,#4
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  PUSH r1
  LDI r0,#109
  POP r1
  STR r0,r1
  LDI r0,#5
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  PUSH r1
  LDI r0,#97
  POP r1
  STR r0,r1
  LDI r0,#6
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  PUSH r1
  LDI r0,#105
  POP r1
  STR r0,r1
  LDI r0,#7
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  PUSH r1
  LDI r0,#110
  POP r1
  STR r0,r1
  LDI r0,#8
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  PUSH r1
  LDI r0,#40
  POP r1
  STR r0,r1
  LDI r0,#9
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  PUSH r1
  LDI r0,#41
  POP r1
  STR r0,r1
  LDI r0,#10
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  PUSH r1
  LDI r0,#123
  POP r1
  STR r0,r1
  LDI r0,#11
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  PUSH r1
  LDI r0,#0
  POP r1
  STR r0,r1
  LDRW r0,#128
  STRW r0,#80
  LDRW r0,#132
  STRW r0,#84
  LDRW r0,#136
  STRW r0,#88
  LDRW r0,#140
  STRW r0,#92
  CALL lex
  LDRW r0,#80
  STRW r0,#128
  LDRW r0,#84
  STRW r0,#132
  LDRW r0,#88
  STRW r0,#136
  LDRW r0,#92
  STRW r0,#140
  LDRW r0,#2976
  HLT
  HLT
printnum_sub:
  PUSH r0
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  MOV r1, r0
  LDI r2, #100
  LDI r3, #0
pn_hun122:
  CMP r1, r2
  JS pn_ten123
  SUB r1, r2
  LDI r0, #1
  ADD r3, r0
  JMP pn_hun122
pn_ten123:
  MOV r4, r1
  LDI r2, #10
  LDI r1, #0
pn_ten2124:
  CMP r4, r2
  JS pn_uni
  SUB r4, r2
  LDI r0, #1
  ADD r1, r0
  JMP pn_ten2124
pn_uni:
  PUSH r1
  LDI r0, #0
  CMP r3, r0
  JZ pn_skip_h125
  LDI r0, #48
  ADD r0, r3
  MOV r1, r0
  LDI r0, #0
  SYSCALL
pn_skip_h125:
  POP r1
  PUSH r1
  LDI r0, #0
  CMP r3, r0
  JZ pn_chk_ten126
  JMP pn_prt_ten127
pn_chk_ten126:
  LDI r0, #0
  CMP r1, r0
  JZ pn_skip_t127
pn_prt_ten127:
  LDI r0, #48
  ADD r0, r1
  MOV r1, r0
  LDI r0, #0
  SYSCALL
pn_skip_t127:
  POP r1
  MOV r0, r4
  LDI r1, #48
  ADD r0, r1
  MOV r1, r0
  LDI r0, #0
  SYSCALL
  POP r4
  POP r3
  POP r2
  POP r1
  POP r0
  RET
strcmp_sub:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  LDI r2,#128
LDR r1,r2
  LDI r2,#132
LDR r2,r2
sc_lp:
  LDR r3,r1
  LDR r4,r2
  CMP r3,r4
  JNZ sc_ne
  LDI r4,#0
  CMP r3,r4
  JZ sc_eq
  LDI r4,#4
  ADD r1,r4
  ADD r2,r4
  JMP sc_lp
sc_ne:
  LDI r0,#1
  JMP sc_ex
sc_eq:
  LDI r0,#0
sc_ex:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
strncpy_sub:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  LDI r2,#128
LDR r1,r2
  LDI r2,#132
LDR r2,r2
  LDI r4,#136
LDR r4,r4
sn_lp:
  LDI r3,#0
  CMP r4,r3
  JZ sn_ex
  LDR r3,r2
  STR r3,r1
  LDI r3,#4
  ADD r1,r3
  ADD r2,r3
  LDI r3,#1
  SUB r4,r3
  JMP sn_lp
sn_ex:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
memset_sub:
  PUSH r1
  PUSH r2
  PUSH r3
  LDI r2,#128
LDR r1,r2
  LDI r2,#132
LDR r2,r2
  LDI r3,#136
LDR r3,r3
ms_lp:
  LDI r0,#0
  CMP r3,r0
  JZ ms_ex
  STR r2,r1
  LDI r0,#4
  ADD r1,r0
  SUB r3,r0
  JMP ms_lp
ms_ex:
  POP r3
  POP r2
  POP r1
  RET
; pp=1321 tok=723
