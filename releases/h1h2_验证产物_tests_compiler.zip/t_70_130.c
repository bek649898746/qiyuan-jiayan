  case OP_NOP:break;case OP_MOV:R[rd]=R[rs];break;case OP_LDI:R[rd]=val;break;case OP_ADD:R[rd]+=R[rs];break;
  case OP_SUB:R[rd]-=R[rs];break;case OP_MUL:R[rd]*=R[rs];break;
  case OP_CMP:ZF=(R[rd]==R[rs]);SF=((int16_t)(R[rd]-R[rs])<0);break;
  case OP_JMP:PC+=(int8_t)val;break;case OP_JZ:if(ZF)PC+=(int8_t)val;break;case OP_JNZ:if(!ZF)PC+=(int8_t)val;break;
  case OP_JMPW:if(PC<65535)PC=M[PC];break;case OP_JZW:if(ZF&&PC<65535)PC=M[PC];break;case OP_JNZW:if(!ZF&&PC<65535)PC=M[PC];break;
  case OP_HLT:RUN=0;break;
  case OP_LOAD:R[rd]=M[SP+(int8_t)val];break;case OP_STORE:M[SP+(int8_t)val]=R[rd];break;
  case OP_CALL:SP--;M[SP]=PC;PC+=(int8_t)val;break;case OP_CALLW:SP--;M[SP]=PC+1;PC=M[PC];break;case OP_RET:PC=M[SP];SP++;break;
  case OP_PUSH:SP--;M[SP]=R[rd];break;case OP_POP:R[rd]=M[SP];SP++;break;
  case OP_JS:if(SF)PC+=(int8_t)val;break;case OP_INC:R[rd]++;break;case OP_DEC:R[rd]--;break;
  case OP_LDR:R[rd]=M[R[rs]];break;case OP_STR:M[R[rs]]=R[rd];break;
  case OP_STRW:if(PC<65535){M[M[PC]]=R[rd];PC++;}break;
  case OP_LDRW:if(PC<65535){R[rd]=M[M[PC]];PC++;}break;
  case OP_SYSCALL:
   if(R[0]==0){ /* putchar */
    char ch=(char)R[1];putchar(ch);fflush(stdout);
    if(vm_op<65535){vm_out[vm_op++]=ch;vm_out[vm_op]=0;}
    if(vm_logfile)fputc(ch,vm_logfile);
   }else if(R[0]==1){int ch=getchar();if(ch==EOF)ch=0;R[1]=ch;
   }else if(R[0]==2){ /* write file: R[1]=char */
    if(vm_logfile&&R[1])fputc((int)R[1],vm_logfile);
   }
   break;
  }
 }
}
#define MAXL 4096
#define MAXLB 64
static char LNS[MAXL][128];static int NL;
static char LN[MAXLB][64];static int LA[MAXLB];static int NB;
static void asm_p1(){
 int a=256;for(int i=0;i<NL;i++){
  for(int j=0;LNS[i][j];j++)if(LNS[i][j]==13)LNS[i][j]=32;
  char*p=LNS[i];while(*p==' '||*p=='\t')p++;
  if(!*p||*p==';')continue;char*c=strchr(p,':');if(c){*c=0;strncpy(LN[NB],p,63);LN[NB][63]=0;LA[NB]=a;NB++;
   char*r=c+1;while(*r==' '||*r=='\t')r++;if(0){strncpy(LNS[i],r,127);i--;}continue;}a++;
 }
}
static int flb(char*s){for(int i=0;i<NB;i++)if(!strcmp(LN[i],s))return i;return-1;}
static int asm_assemble(const char*text){
 NL=0;NB=0;memset(M,0,sizeof(M));char buf[32768];strncpy(buf,text,32767);buf[32767]=0;
 char*tok=strtok(buf,"\n");while(tok&&NL<MAXL){strncpy(LNS[NL],tok,127);LNS[NL][127]=0;NL++;tok=strtok(NULL,"\n");}
 asm_p1();int a=256;
 for(int i=0;i<NL;i++){
  for(char*s=LNS[i];*s;s++)if(*s=='\r')*s=' ';
  char*p=LNS[i];while(*p==' '||*p=='\t')p++;if(!*p||*p==';')continue;if(strchr(p,':'))continue;
  char w[16];int n1=0,n2=0,imm=0;sscanf(p,"%15s r%d",w,&n1);
  char*h=strchr(p,'#');if(h){imm=1;n2=atoi(h+1);}uint16_t e=0;
  if(!strcmp(w,"HLT"))e=ENC(OP_HLT,0,0);else if(!strcmp(w,"NOP"))e=0;
  else if(!strcmp(w,"MOV")||!strcmp(w,"LDI")){if(imm)e=ENC(OP_LDI,n1,n2&0xFF);else{sscanf(p,"%*s r%d, r%d",&n1,&n2);e=ENC(OP_MOV,n1,n2&7);}}
  else if(!strcmp(w,"ADD")){sscanf(p,"%*s r%d, r%d",&n1,&n2);e=ENC(OP_ADD,n1,n2&7);}
  else if(!strcmp(w,"SUB")){sscanf(p,"%*s r%d, r%d",&n1,&n2);e=ENC(OP_SUB,n1,n2&7);}
  else if(!strcmp(w,"MUL")){sscanf(p,"%*s r%d, r%d",&n1,&n2);e=ENC(OP_MUL,n1,n2&7);}
  else if(!strcmp(w,"CMP")){int r2=0;sscanf(p,"%*s r%d, r%d",&n1,&r2);e=ENC(OP_CMP,n1,r2&7);}
  else if(!strcmp(w,"JMP")||!strcmp(w,"JZ")||!strcmp(w,"JNZ")){
   int op=OP_JMP,opw=OP_JMPW;if(!strcmp(w,"JZ")){op=OP_JZ;opw=OP_JZW;}else if(!strcmp(w,"JNZ")){op=OP_JNZ;opw=OP_JNZW;}
   char lb[32];sscanf(p,"%*s %31s",lb);int f=flb(lb),off=(f>=0?LA[f]-(a+1):0);
   if(off>=-128&&off<128){e=ENC(op,0,off&0xFF);}else{M[a]=(opw<<11);M[a+1]=LA[f];a+=2;continue;}}
  else if(!strcmp(w,"JS")){char lb[32];sscanf(p,"%*s %31s",lb);int f=flb(lb),off=(f>=0?LA[f]-(a+1):0);e=ENC(OP_JS,0,off&0xFF);}
  else if(!strcmp(w,"CALL")){char lb[32];sscanf(p,"%*s %31s",lb);int f=flb(lb),off=(f>=0?LA[f]-(a+1):0);if(off>=-127&&off<128){e=ENC(OP_CALL,0,off&0xFF);}else{M[a]=(OP_CALLW<<11);M[a+1]=LA[f];a+=2;continue;}}
  else if(!strcmp(w,"RET"))e=ENC(OP_RET,0,0);
