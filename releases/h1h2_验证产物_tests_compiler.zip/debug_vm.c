/* Debug: check what asm_assemble puts in M[] for a simple program */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

/* === Copy the VM and assembler from v14_self === */
#define OP_NOP 0
#define OP_MOV 1
#define OP_LDI 2
#define OP_JMPW 6
#define OP_HLT 11
#define OP_JMP 8
#define ENC(op,rd,val) ((uint16_t)(((op)&0x1F)<<11)|(((rd)&7)<<8)|((val)&0xFF))

static uint16_t M[65536],R[8],SP;
static int PC,ZF,SF,RUN;

#define MAXL 4096
#define MAXLB 4096
static char LNS[MAXL][128];static int NL;
static char LN[MAXLB][64];static int LA[MAXLB];static int NB;

static void asm_p1(){
 int a=256;for(int i=0;i<NL;i++){
  for(int j=0;LNS[i][j];j++)if(LNS[i][j]==13)LNS[i][j]=32;
  char*p=LNS[i];while(*p==' '||*p=='\t')p++;
  if(!*p||*p==';')continue;char*c=strchr(p,':');if(c){*c=0;strncpy(LN[NB],p,63);LN[NB][63]=0;LA[NB]=a;NB++;
   char*r=c+1;while(*r==' '||*r=='\t')r++;if(0){strncpy(LNS[i],r,127);i--;}continue;}a++;
 }
}
static int flb(char*s){for(int i=0;i<NB;i++)if(!strcmp(LN[i],s))return i;return-1;}

static int asm_assemble(const char*text){
 NL=0;NB=0;memset(M,0,sizeof(M));
 char*buf=malloc(65536);if(!buf)return 0;
 strncpy(buf,text,65535);buf[65535]=0;
 char*tok=strtok(buf,"\n");while(tok&&NL<MAXL){strncpy(LNS[NL],tok,127);LNS[NL][127]=0;NL++;tok=strtok(NULL,"\n");}
 asm_p1();int a=256;
 for(int i=0;i<NL;i++){
  for(char*s=LNS[i];*s;s++)if(*s=='\r')*s=' ';
  char*p=LNS[i];while(*p==' '||*p=='\t')p++;if(!*p||*p==';')continue;if(strchr(p,':'))continue;
  char w[16];int n1=0,n2=0,imm=0;sscanf(p,"%15s r%d",w,&n1);
  char*h=strchr(p,'#');if(h){imm=1;n2=atoi(h+1);}uint16_t e=0;
  if(!strcmp(w,"HLT"))e=ENC(OP_HLT,0,0);else if(!strcmp(w,"NOP"))e=0;
  else if(!strcmp(w,"MOV")||!strcmp(w,"LDI")){if(imm)e=ENC(OP_LDI,n1,n2&0xFF);else{sscanf(p,"%*s r%d, r%d",&n1,&n2);e=ENC(OP_MOV,n1,n2&7);}}
  else if(!strcmp(w,"ADD")){sscanf(p,"%*s r%d, r%d",&n1,&n2);e=ENC(OP_ADD,n1,n2&7);}
  else if(!strcmp(w,"SUB")){sscanf(p,"%*s r%d, r%d",&n1,&n2);e=ENC(OP_SUB,n1,n2&7);}
  else if(!strcmp(w,"JMP")||!strcmp(w,"JZ")||!strcmp(w,"JNZ")){
   int op=OP_JMP,opw=OP_JMPW;if(!strcmp(w,"JZ")){op=OP_JZ;opw=OP_JZW;}else if(!strcmp(w,"JNZ")){op=OP_JNZ;opw=OP_JNZW;}
   char lb[32];sscanf(p,"%*s %31s",lb);int f=flb(lb),off=(f>=0?LA[f]-(a+1):0);
   if(off>=-128&&off<128){e=ENC(op,0,off&0xFF);}else{M[a]=(opw<<11);M[a+1]=LA[f];a+=2;continue;}}
  else continue;M[a++]=e;}free(buf);return a;
}

int main(){
 const char*src="  JMP main_entry\n  JMP main_entry\nmain_entry:\n  LDI r0,#42\n  HLT\n";
 int n=asm_assemble(src);
 printf("asm result: %d instructions\n", n);
 printf("M[0]=%u M[1]=%u M[255]=%u M[256]=%u M[257]=%u M[258]=%u M[259]=%u\n",
   M[0], M[1], M[255], M[256], M[257], M[258], M[259]);
 printf("LA[0]=%d (main_entry)\n", flb("main_entry")>=0?LA[flb("main_entry")]:-1);
 
 /* Try running VM */
 PC=0;ZF=0;SF=0;RUN=1;memset(R,0,sizeof(R));SP=65280;
 int s=0;
 while(RUN&&PC>=0&&PC<65536&&s<500000){
  uint16_t I=M[PC++];s++;
  printf("step %d: PC=%d I=%u op=%d\n",s,PC-1,I,(I>>11)&0x1F);
  int op=(I>>11)&0x1F;
  if(op==OP_NOP)break;/* NOP */else if(op==OP_HLT){RUN=0;break;}else{if(op==OP_JMPW){if(PC<65535)PC=M[PC];printf("  JMPW -> PC=%d\n",PC);break;}
   else if(op==OP_LDI){int rd=(I>>8)&7,val=I&0xFF;R[rd]=val;printf("  LDI r%d,#%d\n",rd,val);}
   else break;}
 }
 printf("After: r0=%d PC=%d steps=%d RUN=%d\n",R[0],PC,s,RUN);
 return 0;
}
