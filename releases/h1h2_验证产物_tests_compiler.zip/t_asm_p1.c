void asm_p1(){
 int a=256;
 int i=0;
 while(i<10){
  i=i+1;
 }
}
int main(){asm_p1();return 0;}