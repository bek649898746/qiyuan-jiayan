/* Minimal reproducer for the crash */
#include <stdio.h>
#include <string.h>
#include <stdint.h>

#define MAXL 4096
#define MAXLB 64
#define L_MAX 512

static uint16_t M[65536];
static char LNS[MAXL][128]; static int NL;
static char LN[L_MAX][64]; static int LA[L_MAX]; static int NB;

int main(int argc, char** argv) {
    FILE* f = fopen("C:\\Users\\Administrator\\Desktop\\grok-build\\bare_small.asm", "rb");
    fseek(f, 0, SEEK_END); long sz = ftell(f); rewind(f);
    char* buf = malloc(sz + 1);
    fread(buf, 1, sz, f); buf[sz] = 0; fclose(f);
    
    // Keep only first 680 lines
    NL = 0;
    char* tok = strtok(buf, "\n");
    while (tok && NL < MAXL && NL < 680) {
        strncpy(LNS[NL], tok, 127); LNS[NL][127] = 0;
        NL++; tok = strtok(NULL, "\n");
    }
    printf("Lines: %d\n", NL);
    
    // Test asm_p1
    NB = 0;
    int a = 256;
    for (int i = 0; i < NL; i++) {
        for (int j = 0; LNS[i][j]; j++) if (LNS[i][j] == 13) LNS[i][j] = 32;
        char* p = LNS[i];
        while (*p == ' ' || *p == '\t') p++;
        if (!*p || *p == ';') continue;
        char* c = strchr(p, ':');
        if (c) {
            *c = 0;
            strncpy(LN[NB], p, 63); LN[NB][63] = 0;
            LA[NB] = a; NB++;
            printf("Label %d: '%s' -> LA=%d\n", NB-1, p, a);
            continue;
        }
        a++;
    }
    printf("Labels: %d, a=%d\n", NB, a);
    printf("Success!\n");
    return 0;
}
