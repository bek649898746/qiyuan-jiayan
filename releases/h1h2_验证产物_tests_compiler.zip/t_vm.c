static void vm_init(void){memset(vm_out,0,sizeof(vm_out));vm_op=0;vm_logfile=NULL;}
int main(){vm_init();return 0;}