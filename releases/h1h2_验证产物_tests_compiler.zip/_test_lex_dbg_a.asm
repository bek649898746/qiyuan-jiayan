  JMP main_entry
  JMP main_entry
lex:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  LDI r0,#0
  STRW r0,#292
  LDI r0,#0
  STRW r0,#288
il1:
  LDRW r0,#292
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  LDR r0,r1
  LDI r1,#0
  CMP r0,r1
  JZ il3
  LDRW r0,#288
  PUSH r0
  LDI r0,#10
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il4
  LDI r0,#1
  JS il5
il4:
  LDI r0,#0
il5:
  LDI r1,#0
  CMP r0,r1
  JZ il3
  LDI r0,#1
il3:
  LDI r1,#0
  CMP r0,r1
  JZ il2
il6:
  LDI r0,#1
  LDI r1,#0
  CMP r0,r1
  JZ il7
  LDRW r0,#292
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  LDR r0,r1
  PUSH r0
  LDI r0,#32
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il10
  LDI r0,#0
  JMP il11
il10:
  LDI r0,#1
il11:
  LDI r1,#0
  CMP r0,r1
  JZ il8
  LDRW r0,#292
  INC r0
  STRW r0,#292
  JMP il6
  JMP il9
il8:
il9:
  LDRW r0,#292
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  LDR r0,r1
  PUSH r0
  LDI r0,#10
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il14
  LDI r0,#0
  JMP il15
il14:
  LDI r0,#1
il15:
  LDI r1,#0
  CMP r0,r1
  JZ il12
  LDRW r0,#292
  INC r0
  STRW r0,#292
  JMP il6
  JMP il13
il12:
il13:
  JMP il7
  JMP il6
il7:
  LDRW r0,#288
  INC r0
  STRW r0,#288
  LDRW r0,#292
  INC r0
  STRW r0,#292
  JMP il1
il2:
fn_exit0:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
main_entry:
  LDI r0,#0
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  PUSH r1
  LDI r0,#105
  POP r1
  STR r0,r1
  LDI r0,#1
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  PUSH r1
  LDI r0,#32
  POP r1
  STR r0,r1
  LDI r0,#2
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  PUSH r1
  LDI r0,#110
  POP r1
  STR r0,r1
  LDI r0,#3
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  PUSH r1
  LDI r0,#0
  POP r1
  STR r0,r1
  LDRW r0,#128
  STRW r0,#80
  LDRW r0,#132
  STRW r0,#84
  LDRW r0,#136
  STRW r0,#88
  LDRW r0,#140
  STRW r0,#92
  CALL lex
  LDRW r0,#80
  STRW r0,#128
  LDRW r0,#84
  STRW r0,#132
  LDRW r0,#88
  STRW r0,#136
  LDRW r0,#92
  STRW r0,#140
  LDRW r0,#288
  HLT
  HLT
printnum_sub:
  PUSH r0
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  MOV r1, r0
  LDI r2, #100
  LDI r3, #0
pn_hun16:
  CMP r1, r2
  JS pn_ten17
  SUB r1, r2
  LDI r0, #1
  ADD r3, r0
  JMP pn_hun16
pn_ten17:
  MOV r4, r1
  LDI r2, #10
  LDI r1, #0
pn_ten218:
  CMP r4, r2
  JS pn_uni
  SUB r4, r2
  LDI r0, #1
  ADD r1, r0
  JMP pn_ten218
pn_uni:
  PUSH r1
  LDI r0, #0
  CMP r3, r0
  JZ pn_skip_h19
  LDI r0, #48
  ADD r0, r3
  MOV r1, r0
  LDI r0, #0
  SYSCALL
pn_skip_h19:
  POP r1
  PUSH r1
  LDI r0, #0
  CMP r3, r0
  JZ pn_chk_ten20
  JMP pn_prt_ten21
pn_chk_ten20:
  LDI r0, #0
  CMP r1, r0
  JZ pn_skip_t21
pn_prt_ten21:
  LDI r0, #48
  ADD r0, r1
  MOV r1, r0
  LDI r0, #0
  SYSCALL
pn_skip_t21:
  POP r1
  MOV r0, r4
  LDI r1, #48
  ADD r0, r1
  MOV r1, r0
  LDI r0, #0
  SYSCALL
  POP r4
  POP r3
  POP r2
  POP r1
  POP r0
  RET
strcmp_sub:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  LDI r2,#128
LDR r1,r2
  LDI r2,#132
LDR r2,r2
sc_lp:
  LDR r3,r1
  LDR r4,r2
  CMP r3,r4
  JNZ sc_ne
  LDI r4,#0
  CMP r3,r4
  JZ sc_eq
  LDI r4,#4
  ADD r1,r4
  ADD r2,r4
  JMP sc_lp
sc_ne:
  LDI r0,#1
  JMP sc_ex
sc_eq:
  LDI r0,#0
sc_ex:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
strncpy_sub:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  LDI r2,#128
LDR r1,r2
  LDI r2,#132
LDR r2,r2
  LDI r4,#136
LDR r4,r4
sn_lp:
  LDI r3,#0
  CMP r4,r3
  JZ sn_ex
  LDR r3,r2
  STR r3,r1
  LDI r3,#4
  ADD r1,r3
  ADD r2,r3
  LDI r3,#1
  SUB r4,r3
  JMP sn_lp
sn_ex:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
memset_sub:
  PUSH r1
  PUSH r2
  PUSH r3
  LDI r2,#128
LDR r1,r2
  LDI r2,#132
LDR r2,r2
  LDI r3,#136
LDR r3,r3
ms_lp:
  LDI r0,#0
  CMP r3,r0
  JZ ms_ex
  STR r2,r1
  LDI r0,#4
  ADD r1,r0
  SUB r3,r0
  JMP ms_lp
ms_ex:
  POP r3
  POP r2
  POP r1
  RET
; pp=276 tok=134
