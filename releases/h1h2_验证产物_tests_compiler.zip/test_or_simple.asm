; Simple OR test: if(0 || 1) return 1 else return 0
; Simulates: int a=0; if(a<0 || a==0) return 1; return 0;
  JMP main_entry
main_entry:
  ; a = 0, stored at addr 0
  LDI r0,#0
  LDI r3,#0
STR r0,r3
  
  ; Evaluate a < 0
  LDI r2,#0
LDR r0,r2           ; r0 = a = 0
  LDI r3,#60
STR r0,r3           ; temp[60] = 0
  LDI r0,#0         ; r0 = 0
  LDI r3,#64
STR r0,r3           ; temp[64] = 0
  LDI r3,#60
LDR r0,r3           ; r0 = 0
  LDI r3,#64
LDR r1,r3           ; r1 = 0
  CMP r0,r1          ; compare 0, 0
  JZ il_lcmp1        ; ZF=1, so jump (a==0, so a<0 is false)
  LDI r0,#1
  JS il_ldone1       ; would jump if a<0
il_lcmp1:
  LDI r0,#0          ; false - a<0 is false (r0=0)
il_ldone1:
  ; || short-circuit: if left (a<0) is non-zero, skip right
  LDI r1,#0
  CMP r0,r1          ; r0=0, compare with 0
  JNZ il_lor2        ; r0=0, ZF=1, NOT taken
  
  ; Evaluate a == 0
  LDI r2,#0
LDR r0,r2           ; r0 = a = 0
  LDI r3,#60
STR r0,r3           ; temp[60] = 0
  LDI r0,#0         ; r0 = 0
  LDI r3,#64
STR r0,r3           ; temp[64] = 0
  LDI r3,#60
LDR r0,r3           ; r0 = 0
  LDI r3,#64
LDR r1,r3           ; r1 = 0
  CMP r0,r1          ; compare 0, 0
  JZ il_ldone2       ; ZF=1, a==0 true! Jump to ldone2
  LDI r0,#0          ; (skipped)
  JMP il_lcmp2       ; (skipped)
il_ldone2:
  LDI r0,#1          ; true! r0=1
il_lcmp2:
  ; || right side result check
  LDI r1,#0
  CMP r0,r1          ; r0=1, compare with 0
  JNZ il_lor2        ; ZF=0, JNZ TAKEN! Skip to lor2
  
  ; Both false
  LDI r0,#0
  JMP il_ldone3
  
il_lor2:
  LDI r0,#1          ; true! r0=1
il_ldone3:
  ; Now r0=1, if(r0) return 1
  LDI r1,#0
  CMP r0,r1
  JZ il_return0
  LDI r0,#1          ; return 1
  HLT
il_return0:
  LDI r0,#0          ; return 0
  HLT
