char dbuf[64];int di;
void doc(int c){if(di<63)dbuf[di]=c;di++;dbuf[di]=0;}
void dos(char*s){int i=0;while(s[i*4]){doc(s[i*4]);i++;}}
int tt[128];char tn[128][32];int tc;
int seq(char*a,char*b){int i=0;while(a[i*4]&&b[i*4]&&a[i*4]==b[i*4])i++;if(a[i*4]==b[i*4])return 1;return 0;}
void scp(char*d,char*s){int i=0;while(s[i*4]){d[i*4]=s[i*4];i++;}d[i*4]=0;}
void lex(char*s){
 int i=0;tc=0;
 while(s[i*4]&&tc<128){
  while(s[i*4]==32||s[i*4]==10||s[i*4]==9||s[i*4]==13)i++;
  if(!s[i*4])break;char c=s[i*4];
  if(c==40){tt[tc]=8;i++;}else if(c==41){tt[tc]=9;i++;}
  else if(c==123){tt[tc]=10;i++;}else if(c==125){tt[tc]=11;i++;}
  else if(c==59){tt[tc]=12;i++;}else if(c==61){tt[tc]=13;i++;}
  else if(c==43){tt[tc]=14;i++;}else if(c==45){tt[tc]=15;i++;}else if(c==42){tt[tc]=16;i++;}
  else if(isdig(c)){tt[tc]=7;while(isdig(s[i*4])){i++;}}
  else if(isidc(c)){int j=0;while(isan(s[i*4])||s[i*4]==95){if(j<31){tn[tc][j]=s[i*4];j++;}i++;}tn[tc][j]=0;
   if(seq(tn[tc],"int"))tt[tc]=1;else if(seq(tn[tc],"return"))tt[tc]=2;else tt[tc]=6;
  }else i++;tc++;
 }tt[tc]=0;
}
int isdig(int c){if(c>47&&c<58)return 1;return 0;}
int isidc(int c){if((c>96&&c<123)||(c>64&&c<91)||c==95)return 1;return 0;}
int isan(int c){if(isdig(c)||isidc(c))return 1;return 0;}
char src[256];
int main(void){
 di=0;scp(src,"int");lex(src);
 doc(48+tc);doc(48+tt[0]);doc(48+tt[1]);
 putstr(dbuf);
 return 0;
}
