char buf[256];int bp;
void oc(int c){if(bp<255)buf[bp]=c;bp++;buf[bp]=0;}
void os(char*s){int i=0;while(s[i*4]){oc(s[i*4]);i++;}}
void on(int v){char b[16];int i=14;b[14]=0;b[15]=0;
 while(v>0&&i>0){b[--i]=48+(v%10);v=v/10;}
 if(i==14){oc(48);return;}os(b+i*4);}
int main(void){
 bp=0;
 os("HELLO");on(42);os(" WORLD");
 putstr(buf);
 return 0;
}
