; Test JG: 5 > 3 → JG should jump to good label
  JMP main_entry
good:
  LDI r0,#42   ; expected result
  HLT
bad:
  LDI r0,#0    ; wrong path
  HLT
main_entry:
  LDI r0,#5
  LDI r1,#3
  CMP r0,r1     ; ZF=0, SF=0 (5>3)
  JG good       ; should jump -> r0=42
  JMP bad       ; should not reach here
