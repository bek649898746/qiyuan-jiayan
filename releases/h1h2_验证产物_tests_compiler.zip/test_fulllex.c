int tt[128];int tv[128];char tn[128][32];int tc;int ti;
int isdig(int c){if(c>47&&c<58)return 1;return 0;}
int isidc(int c){if((c>96&&c<123)||(c>64&&c<91)||c==95)return 1;return 0;}
int isan(int c){if(isdig(c)||isidc(c))return 1;return 0;}
int seq(char*a,char*b){int i=0;while(a[i]&&b[i]&&a[i]==b[i])i+=4;if(a[i]==b[i])return 1;return 0;}
void scp_src(char*s){int i=0;while(s[i*4]){src[i]=s[i*4];i++;}src[i]=0;}
char src[256];char out[4096];int op;char dbuf[64];int di;
void doc(int c){if(di<63)dbuf[di]=c;di++;dbuf[di]=0;}
void oc(int c){if(op<4095)out[op]=c;op++;out[op]=0;}
void os(char*s){int i=0;while(s[i*4]){oc(s[i*4]);i++;}}
void on(int v){char b[16];int i=14;b[14]=0;b[15]=0;
 while(v>0&&i>0){b[--i]=48+(v%10);v=v/10;}
 if(i==14){oc(48);return;}while(b[i]){oc(b[i]);i++;}}
int ilab;
void lex(void){
 int i=0;tc=0;
 while(src[i]&&tc<128){
  while(src[i]==32||src[i]==10||src[i]==9||src[i]==13)i++;
  if(!src[i])break;char c=src[i];
  if(c==40){tt[tc]=8;i++;}else if(c==41){tt[tc]=9;i++;}
  else if(c==123){tt[tc]=10;i++;}else if(c==125){tt[tc]=11;i++;}
  else if(c==59){tt[tc]=12;i++;}
  else if(c==61){tt[tc]=13;i++;}
  else if(c==43){tt[tc]=14;i++;}else if(c==45){tt[tc]=15;i++;}else if(c==42){tt[tc]=16;i++;}
  else if(isdig(c)){tt[tc]=7;tv[tc]=0;
   while(isdig(src[i])){tv[tc]=tv[tc]*10+(src[i]-48);i++;}}
  else if(isidc(c)){int j=0;
   while(isan(src[i])||src[i]==95){if(j<31){tn[tc][j]=src[i];j++;}i++;}tn[tc][j]=0;
   if(seq(tn[tc],"int"))tt[tc]=1;
   else if(seq(tn[tc],"return"))tt[tc]=2;
   else tt[tc]=6;
  }else i++;
  tc++;
 }
 tt[tc]=0;
}
int main(void){
 scp_src("int");
 lex();
 di=0;doc(48+tc);doc(48+tt[0]);doc(48+tt[1]);
 putstr(dbuf);
 return 0;
}
