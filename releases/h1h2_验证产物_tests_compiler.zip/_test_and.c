int on(int v){int i;i=14;
 while(v>0 && i>0){i--;}
 return v;
}
int main(void){
 return on(17);
}
