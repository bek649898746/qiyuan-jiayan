int src[64];int tt[8];int tv[8];int tc;
/* 4 whitespace checks like step1, but no extra if(!src[i])break and no tt[tc]=0 */
void lex(void){
 int i;i=0;tc=0;
 while(src[i]&&tc<10){
  while(1){
   if(src[i]==32){i++;continue;}
   if(src[i]==10){i++;continue;}
   if(src[i]==9){i++;continue;}
   if(src[i]==13){i++;continue;}
   break;
  }
  tc++;i++;
 }
}
int main(void){
 src[0]=105;src[1]=110;src[2]=116;src[3]=32;
 src[4]=109;src[5]=97;src[6]=105;src[7]=110;
 src[8]=40;src[9]=41;src[10]=123;src[11]=0;
 lex();return tc;
}
