char buf[32];int bp;
void oc(int c){if(bp<31)buf[bp++]=c;buf[bp]=0;}
void os(char*s){while(*s){oc(*s);s+=4;}}
int main(void){
 bp=0;
 os("TEST OK");
 putstr(buf);
 return 0;
}
