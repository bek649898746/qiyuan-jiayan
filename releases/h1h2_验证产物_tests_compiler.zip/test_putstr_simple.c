char buf[64];
int main(void){
 buf[0]=72;buf[1]=105;buf[2]=0;
 putstr(buf);
 return 0;
}
