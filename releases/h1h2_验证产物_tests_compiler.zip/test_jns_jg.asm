; Test JNS (jump if SF==0): 5 >= 3 should not jump over r0=42
  JMP main_entry
skip:
  LDI r0,#99
  HLT
main_entry:
  LDI r0,#5
  LDI r1,#3
  CMP r0,r1     ; ZF=0 SF=0 (5 > 3)
  JNS skip      ; SF==0 -> should NOT jump (5>3, signed flag is 0 = not negative)
  LDI r0,#42
  HLT
