  JMP main_entry
  JMP main_entry
main_entry:
  LDI r0,#42
  LDI r3,#0
STR r0,r3
  LDI r0,#13
  LDI r3,#4
STR r0,r3
  LDI r2,#0
LDR r0,r2
  HLT
