int src[64];int tt[20];int tv[20];char tn[20][32];int tc;
int isdig(int c){if(c>47&&c<58)return 1;return 0;}
int isidc(int c){if((c>96&&c<123)||(c>64&&c<91)||c==95)return 1;return 0;}
int isan(int c){if(isdig(c)||isidc(c))return 1;return 0;}
int seq(char*a,char*b){int i=0;while(a[i]&&b[i]&&a[i]==b[i])i+=4;if(a[i]==b[i])return 1;return 0;}
void lex(void){
 int i;i=0;tc=0;
 while(src[i]&&tc<10){
  while(1){
   if(src[i]==32){i++;continue;}
   if(src[i]==10){i++;continue;}
   if(src[i]==9){i++;continue;}
   if(src[i]==13){i++;continue;}
   break;
  }
  if(!src[i])break;char c=src[i];
  if(c==40){tt[tc]=8;i++;}else if(c==41){tt[tc]=9;i++;}
  else if(c==123){tt[tc]=10;i++;}else if(c==125){tt[tc]=11;i++;}
  else if(c==59){tt[tc]=12;i++;}
  else if(c==61){tt[tc]=13;i++;}
  else if(isdig(c)){tt[tc]=7;tv[tc]=0;
   while(1){if(!isdig(src[i]))break;tv[tc]=tv[tc]*10+(src[i]-48);i++;}}
  else if(isidc(c)){int j;j=0;
   while(1){if(!isan(src[i])&&src[i]!=95)break;if(j<31){tn[tc][j]=src[i];j++;}i++;}tn[tc][j]=0;
   if(seq(tn[tc],"int"))tt[tc]=1;
   else if(seq(tn[tc],"return"))tt[tc]=2;
   else tt[tc]=6;
  }else i++;
  tc++;
 }
 tt[tc]=0;
}
int main(void){
 src[0]=105;src[1]=110;src[2]=116;src[3]=32;  /* "int " */
 src[4]=109;src[5]=97;src[6]=105;src[7]=110;  /* "main" */
 src[8]=40;src[9]=41;src[10]=123;src[11]=0;   /* "(){" */
 lex();return tc;
}
