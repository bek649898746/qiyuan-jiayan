  JMP main_entry
main_entry:
  LDI r0,#0
  LDI r3,#0
  STR r0,r3
loop:
  LDI r2,#0
  LDR r0,r2
  LDI r1,#3
  CMP r0,r1
  JZ exit
  ADI r0,#1
  STR r0,r3
  JMP loop
exit:
  LDI r2,#0
  LDR r0,r2
  HLT
