/* V14_self补丁 — 在sb_cstmt里加for循环处理 */
/* 这个文件插在 sb_cstmt 函数的 TK_WH 处理之后 */
/*
  else if(a==TK_FOR){
   int lf=sb_ilab++;int le=sb_ilab++;
   sb_tk++;if(sb_tt[sb_tk]==TK_LP)sb_tk++;
   if(sb_tt[sb_tk]==TK_INT)sb_tk++;
   while(sb_tt[sb_tk]!=TK_SEMI&&sb_tt[sb_tk]!=TK_EOF){sb_cexpr();}
   if(sb_tt[sb_tk]==TK_SEMI)sb_tk++;
   sb_puts("il");sb_putn(lf);sb_puts(":\n");
   sb_cexpr();sb_puts("  LDI r1,#0\n  CMP r0,r1\n  JZ il");sb_putn(le);sb_puts("\n");
   if(sb_tt[sb_tk]==TK_SEMI)sb_tk++;
   int is=sb_tk,id=0;
   while(!(sb_tt[sb_tk]==TK_RP&&id==0)){
    if(sb_tt[sb_tk]==TK_LP)id++;if(sb_tt[sb_tk]==TK_RP)id--;sb_tk++;if(sb_tt[sb_tk]==TK_EOF)break;
   }
   if(sb_tt[sb_tk]==TK_RP)sb_tk++;
   if(sb_tt[sb_tk]==TK_LB){sb_tk++;while(sb_tt[sb_tk]!=TK_RB&&sb_tt[sb_tk]!=TK_EOF)sb_cstmt();if(sb_tt[sb_tk]==TK_RB)sb_tk++;}
   sb_tk=is;while(sb_tt[sb_tk]!=TK_RP)sb_cexpr();
   sb_puts("  JMP il");sb_putn(lf);sb_puts("\nil");sb_putn(le);sb_puts(":\n");
  }
*/
int main(){printf("patched\n");return 0;}
