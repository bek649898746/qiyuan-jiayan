/* test seed compiler with added putstr */
#include <stdio.h>

int tt[128];int tv[128];char tn[128][32];int tc;int ti;

int isdig(int c){if(c>47&&c<58)return 1;return 0;}
int isidc(int c){if((c>96&&c<123)||(c>64&&c<91)||c==95)return 1;return 0;}
int isan(int c){if(isdig(c)||isidc(c))return 1;return 0;}
int seq(char*a,char*b){int i=0;while(a[i]&&b[i]&&a[i]==b[i])i++;if(a[i]==b[i])return 1;return 0;}
void scp(char*d,char*s){int i=0;while(s[i]){d[i]=s[i];i++;}d[i]=0;}
void lex(char*s){
 int i=0;tc=0;
 while(s[i]&&tc<128){
  while(s[i]==32||s[i]==10||s[i]==9||s[i]==13)i++;
  if(!s[i])break;
  char c=s[i];
  if(c==40){tt[tc]=8;i++;}else if(c==41){tt[tc]=9;i++;}
  else if(c==123){tt[tc]=10;i++;}else if(c==125){tt[tc]=11;i++;}
  else if(c==59){tt[tc]=12;i++;}
  else if(c==61){tt[tc]=13;i++;}
  else if(c==43){tt[tc]=14;i++;}else if(c==45){tt[tc]=15;i++;}else if(c==42){tt[tc]=16;i++;}
  else if(isdig(c)){tt[tc]=7;tv[tc]=0;
   while(isdig(s[i])){tv[tc]=tv[tc]*10+(s[i]-48);i++;}}
  else if(isidc(c)){int j=0;
   while(isan(s[i])||s[i]==95){if(j<31){tn[tc][j]=s[i];j++;}i++;}tn[tc][j]=0;
   if(seq(tn[tc],"int"))tt[tc]=1;
   else if(seq(tn[tc],"return"))tt[tc]=2;
   else tt[tc]=6;
  }else i++;
  tc++;
 }
 tt[tc]=0;
}

char sn[32][32];int sa[32];int sc;
int sv(char*n){int i;for(i=0;i<sc;i++)if(seq(sn[i],n))return sa[i];
 if(sc>=32)return 0;scp(sn[sc],n);sa[sc]=sc*4;sc++;return sa[sc-1];}
int sf(char*n){int i;for(i=0;i<sc;i++)if(seq(sn[i],n))return sa[i];return -1;}
char out[4096];int op;
void oc(int c){if(op<4095)out[op++]=c;out[op]=0;}
void os(char*s){while(*s){oc(*s);s++;}}
void on(int v){char b[16];int i=14;b[15]=0;
 while(v>0&&i>0){b[--i]=48+(v%10);v/=10;}
 if(i==14){oc(48);return;}os(b+i);}
int ilab;
void expr(void);
void stmt(void);
void expr(void){
 int a=tt[ti];
 if(a==7){os("  LDI r0,#");on(tv[ti]);os("\n");ti++;}
 else if(a==6){ti++;}
 int op=tt[ti];
 if(op==14||op==15||op==16){
  ti++;os("  LDI r3,#60\nSTR r0,r3\n");expr();
  os("  LDI r3,#64\nSTR r0,r3\n");os("  LDI r3,#60\nLDR r0,r3\n  LDI r3,#64\nLDR r1,r3\n");
  if(op==14)os("  ADD r0,r1\n");else if(op==15)os("  SUB r0,r1\n");else os("  MUL r0,r1\n");
 }
}
void stmt(void){
 int a=tt[ti];
 if(a==1){ti++;
  if(tt[ti]==6){char nm[32];int ni=0;while(tn[ti][ni]){nm[ni]=tn[ti][ni];ni++;}nm[ni]=0;ti++;
   sv(nm);if(tt[ti]==13){ti++;expr();int ad=sf(nm);
    if(ad>=0){os("  LDI r3,#");on(ad);os("\nSTR r0,r3\n");}}}
  if(tt[ti]==12)ti++;
 }else if(a==2){ti++;expr();os("  HLT\n");if(tt[ti]==12)ti++;}
 else if(a==10){ti++;while(tt[ti]!=11&&tt[ti]!=0)stmt();if(tt[ti]==11)ti++;}
 else if(a==6){
  char nm[32];int ni=0;while(tn[ti][ni]){nm[ni]=tn[ti][ni];ni++;}nm[ni]=0;ti++;
  if(tt[ti]==13){ti++;expr();int ad=sf(nm);if(ad>=0){os("  LDI r3,#");on(ad);os("\nSTR r0,r3\n");}}
  if(tt[ti]==12)ti++;
 }else ti++;
}
void compile(void){
 ti=0;sc=0;ilab=0;
 os("  JMP main_entry\n");os("  JMP main_entry\n");
 while(tt[ti]!=0){
  if(tt[ti]==1&&tt[ti+1]==6&&tt[ti+2]==8){
   ti++;char fn[32];int fi=0;while(tn[ti][fi]){fn[fi]=tn[ti][fi];fi++;}fn[fi]=0;ti++;
   int ismain=seq(fn,"main");
   while(tt[ti]!=9&&tt[ti]!=0)ti++;if(tt[ti]==9)ti++;
   if(tt[ti]==10){ti++;
    if(ismain)os("main_entry:\n");else{os(fn);os(":\n");}
    while(tt[ti]!=11&&tt[ti]!=0)stmt();if(tt[ti]==11)ti++;
    if(ismain)os("  HLT\n");else os("  RET\n");
   }
  }else ti++;
 }
}
void putstr(char* s){while(*s)putchar(*s++);}

char src[256];int si;
int main(void){
 scp(src,"int main(void){int a;a=42;return a;}");
 lex(src);ti=0;sc=0;ilab=0;op=0;compile();
 printf("output (%d chars):\n",op);
 putstr(out);
 printf("\n");
 return 0;
}
