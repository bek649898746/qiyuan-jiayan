MOV r1, #0
STORE r1, #4
MOV r1, #1
STORE r1, #8
MOV r1, #10
STORE r1, #12
W0:
LOAD r1, #12
MOV r2, #0
CMP r1, r2
JZ W0_exit
LOAD r1, #4
STORE r1, #20
LOAD r1, #8
STORE r1, #4
LOAD r1, #20
LOAD r2, #8
ADD r1, r2
STORE r1, #8
LOAD r1, #12
MOV r2, #1
SUB r1, r2
STORE r1, #12
JMP W0
W0_exit:
LOAD r0, #4
HLT

HLT
