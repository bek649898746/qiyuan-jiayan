/* Same as minimal, but with extra global vars */
int src[64];int pad[8];int tc;
void lex(void){
 int i;i=0;tc=0;
 while(src[i]&&tc<10){
  while(1){
   if(src[i]==32){i++;continue;}
   if(src[i]==10){i++;continue;}
   break;
  }
  tc++;i++;
 }
}
int main(void){
 src[0]=105;src[1]=32;src[2]=110;src[3]=0;
 lex();return tc;
}
