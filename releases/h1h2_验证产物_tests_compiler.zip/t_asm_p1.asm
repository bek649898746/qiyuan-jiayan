  JMP main_entry
  JMP main_entry
asm_p1:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
il1:
  LDI r2,#4
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r0,#10
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il3
  LDI r0,#1
  JS il4
il3:
  LDI r0,#0
il4:
  LDI r1,#0
  CMP r0,r1
  JZ il2
  LDI r2,#4
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r0,#1
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDI r3,#4
STR r0,r3
  JMP il1
il2:
fn_exit0:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
main_entry:
  LDI r0,#0
  HLT
  HLT
printnum_sub:
  PUSH r0
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  MOV r1, r0
  LDI r2, #100
  LDI r3, #0
pn_hun5:
  CMP r1, r2
  JS pn_ten6
  SUB r1, r2
  LDI r0, #1
  ADD r3, r0
  JMP pn_hun5
pn_ten6:
  MOV r4, r1
  LDI r2, #10
  LDI r1, #0
pn_ten27:
  CMP r4, r2
  JS pn_uni
  SUB r4, r2
  LDI r0, #1
  ADD r1, r0
  JMP pn_ten27
pn_uni:
  PUSH r1
  LDI r0, #0
  CMP r3, r0
  JZ pn_skip_h8
  LDI r0, #48
  ADD r0, r3
  MOV r1, r0
  LDI r0, #0
  SYSCALL
pn_skip_h8:
  POP r1
  PUSH r1
  LDI r0, #0
  CMP r3, r0
  JZ pn_chk_ten9
  JMP pn_prt_ten10
pn_chk_ten9:
  LDI r0, #0
  CMP r1, r0
  JZ pn_skip_t10
pn_prt_ten10:
  LDI r0, #48
  ADD r0, r1
  MOV r1, r0
  LDI r0, #0
  SYSCALL
pn_skip_t10:
  POP r1
  MOV r0, r4
  LDI r1, #48
  ADD r0, r1
  MOV r1, r0
  LDI r0, #0
  SYSCALL
  POP r4
  POP r3
  POP r2
  POP r1
  POP r0
  RET
