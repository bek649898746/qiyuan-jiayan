int main(){int a;int r;a=0;r=0;if(a<0||a>0||a==0){r=1;}return r;}
