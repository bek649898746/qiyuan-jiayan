[FAIL] t_tiny.c
