  JMP main_entry
  JMP main_entry
main_entry:
  LDI r0,#104
  LDI r3,#4
STR r0,r3
  LDI r0,#101
  LDI r3,#5
STR r0,r3
  LDI r0,#108
  LDI r3,#6
STR r0,r3
  LDI r0,#108
  LDI r3,#7
STR r0,r3
  LDI r0,#111
  LDI r3,#8
STR r0,r3
  LDI r0,#0
  LDI r3,#9
STR r0,r3
  LDI r0,#4
  LDI r3,#0
STR r0,r3
  LDI r0,#42
  HLT
