/* Test seed compiler lex under GCC - stride-1 compatible */
#include <stdio.h>
int tt[128];int tv[128];char tn[128][32];int tc;int ti;
char src[256];
int isdig(int c){if(c>47&&c<58)return 1;return 0;}
int isidc(int c){if((c>96&&c<123)||(c>64&&c<91)||c==95)return 1;return 0;}
int isan(int c){if(isdig(c)||isidc(c))return 1;return 0;}
int seq(char*a,char*b){int i=0;while(a[i]&&b[i]&&a[i]==b[i])i++;if(a[i]==b[i])return 1;return 0;}
void scp(char*d,char*s){int i=0;while(s[i]){d[i]=s[i];i++;}d[i]=0;}
void lex(void){
 int i=0;tc=0;
 while(src[i]&&tc<128){
  while(1){
   if(src[i]==32){i++;continue;}
   if(src[i]==10){i++;continue;}
   if(src[i]==9){i++;continue;}
   if(src[i]==13){i++;continue;}
   break;
  }
  if(!src[i])break;char c=src[i];
  if(c==40){tt[tc]=8;i++;}else if(c==41){tt[tc]=9;i++;}
  else if(c==123){tt[tc]=10;i++;}else if(c==125){tt[tc]=11;i++;}
  else if(c==59){tt[tc]=12;i++;}
  else if(c==61){tt[tc]=13;i++;}
  else if(c==43){tt[tc]=14;i++;}else if(c==45){tt[tc]=15;i++;}else if(c==42){tt[tc]=16;i++;}
  else if(isdig(c)){tt[tc]=7;tv[tc]=0;
   while(1){if(!isdig(src[i]))break;tv[tc]=tv[tc]*10+(src[i]-48);i++;}}
  else if(isidc(c)){int j=0;
   while(1){if(!isan(src[i])&&src[i]!=95)break;if(j<31){tn[tc][j]=src[i];j++;}i++;}tn[tc][j]=0;
   if(seq(tn[tc],"int"))tt[tc]=1;
   else if(seq(tn[tc],"return"))tt[tc]=2;
   else tt[tc]=6;
  }else i++;
  tc++;
 }
 tt[tc]=0;
}
int main(void){
 scp(src,"int main(void){int a;a=42;return a;}");
 lex();printf("tc=%d\n",tc);
 for(int i=0;i<tc;i++)printf("  [%d] tt=%d tv=%d tn='%s'\n",i,tt[i],tv[i],tn[i]);
 return 0;
}
