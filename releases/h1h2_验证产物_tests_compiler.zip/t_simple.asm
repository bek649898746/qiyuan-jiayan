  LDI r0,#40
  LDI r1,#2
  ADD r0,r1
  HLT
