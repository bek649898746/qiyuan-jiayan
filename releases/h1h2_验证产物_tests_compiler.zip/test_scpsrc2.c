char src[256];char dbuf[64];int di;
void doc(int c){if(di<63)dbuf[di]=c;di++;dbuf[di]=0;}
void scp_src(char*s){int i=0;while(s[i*4]){src[i]=s[i*4];i++;}src[i]=0;}
int main(void){
 scp_src("int");
 di=0;doc(48+src[0]/10);doc(48+src[0]%10);
 putstr(dbuf);
 return 0;
}
