char src[64];char d[64];int di;
void doc(int c){if(di<63)d[di]=c;di++;d[di]=0;}
void scp(char*d,char*s){int i=0;while(s[i*4]){d[i*4]=s[i*4];i++;}d[i*4]=0;}
int main(void){
 scp(src,"int");
 di=0;doc(src[0]);doc(src[1]);doc(src[2]);
 putstr(d);
 return 0;
}
