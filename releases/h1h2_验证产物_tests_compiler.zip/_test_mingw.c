#include <stdio.h>
int main() {
    printf("hello from mingw\n");
    printf("1+1=%d\n", 2);
    int x = 0;
    for (int i = 0; i < 1000000; i++) { x += i; }
    printf("sum=%d\n", x);
    return 0;
}
