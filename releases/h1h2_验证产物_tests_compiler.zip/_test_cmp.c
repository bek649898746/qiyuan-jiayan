int a; int b; int c;
int main(void) {
    int x; x=105;
    int y; y=a;
    int z; z=0;
    if(y==x)z=1;
    if(z==1)c=99;
    b=z;
    return b;
}
