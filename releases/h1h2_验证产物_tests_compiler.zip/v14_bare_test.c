/*
 * 测试种子编译器 v14_bare 的输出
 * 编译: gcc -o v14_bare_test.exe v14_bare_test.c
 */
#include <stdio.h>
#include <string.h>

/* putstr: CPU64平台输出函数 — 在PC上定义为printf */
void putstr(char *s) { printf("%s", s); fflush(stdout); }

/* 直接包含种子编译器源码 */
#include "srclib/v14_bare.c"

int main_original(void); /* 屏蔽原始main */

int main(void) {
    printf("=== 种子编译器输出 ===\n");
    fflush(stdout);
    
    /* 运行种子编译器 */
    op=0; lex(); cmain(); out[op]=0; putstr(out);
    
    printf("\n=== 分析 ===\n");
    printf("输出长度: %d\n", op);
    printf("前20字节: ");
    for(int i=0; i<20 && i<op; i++) {
        printf("%02X ", (unsigned char)out[i]);
    }
    printf("\n");
    
    /* 检查第一字节 */
    if(op > 0) {
        printf("首字节: '%c' (0x%02X)\n", out[0], (unsigned char)out[0]);
        if(out[0] == 0) printf("⚠️ 首字节为空! putstr输出空字符串\n");
    } else {
        printf("❌ 输出为空! 种子编译器未生成任何代码\n");
    }
    
    return 0;
}
