/* test while with bare function call body - no braces */
void oc(int c){}
int x;
int main(void){
 x=0;
 while(x<5) oc(x++);
 return x;
}
