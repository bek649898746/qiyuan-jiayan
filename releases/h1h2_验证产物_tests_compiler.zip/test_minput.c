char out[64];int op;
void oc(int c){if(op<63)out[op]=c;op++;out[op]=0;}
int main(void){
 op=0;oc(72);oc(105);putstr(out);
 return 0;
}
