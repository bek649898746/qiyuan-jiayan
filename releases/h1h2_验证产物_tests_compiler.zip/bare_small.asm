  JMP main_entry
  JMP main_entry
isdig:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  LDI r2,#128
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r0,#47
  LDI r1,#0
  CMP r0,r1
  JZ il5
  LDI r2,#128
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r0,#58
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il6
  LDI r0,#1
  JS il7
il6:
  LDI r0,#0
il7:
  LDI r1,#0
  CMP r0,r1
  JZ il5
  LDI r0,#1
il5:
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il3
  JS il3
  LDI r0,#1
  JMP il4
il3:
  LDI r0,#0
il4:
  LDI r1,#0
  CMP r0,r1
  JZ il1
  JMP il2
il1:
il2:
  LDI r0,#1
  JMP fn_exit0
  LDI r0,#0
  JMP fn_exit0
fn_exit0:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
isidc:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  LDI r2,#128
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r0,#96
  LDI r1,#0
  CMP r0,r1
  JZ il13
  LDI r2,#128
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r0,#123
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il14
  LDI r0,#1
  JS il15
il14:
  LDI r0,#0
il15:
  LDI r1,#0
  CMP r0,r1
  JZ il13
  LDI r0,#1
il13:
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il11
  JS il11
  LDI r0,#1
  JMP il12
il11:
  LDI r0,#0
il12:
  LDI r1,#0
  CMP r0,r1
  JNZ il16
  LDI r2,#128
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r0,#64
  LDI r1,#0
  CMP r0,r1
  JZ il20
  LDI r2,#128
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r0,#91
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il21
  LDI r0,#1
  JS il22
il21:
  LDI r0,#0
il22:
  LDI r1,#0
  CMP r0,r1
  JZ il20
  LDI r0,#1
il20:
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il18
  JS il18
  LDI r0,#1
  JMP il19
il18:
  LDI r0,#0
il19:
  LDI r1,#0
  CMP r0,r1
  JNZ il23
  LDI r2,#128
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r0,#95
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il26
  LDI r0,#0
  JMP il25
il26:
  LDI r0,#1
il26:
  LDI r1,#0
  CMP r0,r1
  JNZ il23
  LDI r0,#0
  JMP il24
il23:
  LDI r0,#1
il24:
  LDI r1,#0
  CMP r0,r1
  JNZ il16
  LDI r0,#0
  JMP il17
il16:
  LDI r0,#1
il17:
  LDI r1,#0
  CMP r0,r1
  JZ il9
  JMP il10
il9:
il10:
  LDI r0,#1
  JMP fn_exit8
  LDI r0,#0
  JMP fn_exit8
fn_exit8:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
isan:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  LDI r2,#128
LDR r0,r2
  LDI r3,#128
STR r0,r3
  CALL isdig
  LDI r1,#0
  CMP r0,r1
  JNZ il30
  LDI r2,#128
LDR r0,r2
  LDI r3,#128
STR r0,r3
  CALL isidc
  LDI r1,#0
  CMP r0,r1
  JNZ il30
  LDI r0,#0
  JMP il31
il30:
  LDI r0,#1
il31:
  LDI r1,#0
  CMP r0,r1
  JZ il28
  JMP il29
il28:
il29:
  LDI r0,#1
  JMP fn_exit27
  LDI r0,#0
  JMP fn_exit27
fn_exit27:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
seq:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
il33:
  LDI r2,#128
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r2,#0
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  LDI r1,#0
  CMP r0,r1
  JZ il35
  LDI r2,#132
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r2,#0
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  LDI r1,#0
  CMP r0,r1
  JZ il36
  LDI r2,#128
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r2,#0
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  LDI r3,#60
STR r0,r3
  LDI r2,#132
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r2,#0
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il38
  LDI r0,#0
  JMP il37
il38:
  LDI r0,#1
il38:
  LDI r1,#0
  CMP r0,r1
  JZ il36
  LDI r0,#1
il36:
  LDI r1,#0
  CMP r0,r1
  JZ il35
  LDI r0,#1
il35:
  LDI r1,#0
  CMP r0,r1
  JZ il34
  JMP il33
il34:
  LDI r2,#0
LDR r0,r2
  INC r0
  STR r0,r2
  LDI r2,#128
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r2,#0
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  LDI r3,#60
STR r0,r3
  LDI r2,#132
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r2,#0
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il42
  LDI r0,#0
  JMP il41
il42:
  LDI r0,#1
il42:
  LDI r1,#0
  CMP r0,r1
  JZ il39
  JMP il40
il39:
il40:
  LDI r0,#1
  JMP fn_exit32
  LDI r0,#0
  JMP fn_exit32
fn_exit32:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
scp:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
il44:
  LDI r2,#132
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r2,#4
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  LDI r1,#0
  CMP r0,r1
  JZ il45
  LDI r2,#128
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r2,#4
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDI r3,#68
STR r0,r3
  LDI r2,#132
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r2,#4
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  LDI r3,#68
LDR r1,r3
  STR r0,r1
  LDI r2,#4
LDR r0,r2
  INC r0
  STR r0,r2
  JMP il44
il45:
  LDI r2,#128
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r2,#4
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDI r3,#68
STR r0,r3
  LDI r0,#0
  LDI r3,#68
LDR r1,r3
  STR r0,r1
fn_exit43:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
lex:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  LDI r0,#0
  LDI r3,#12
STR r0,r3
il47:
  LDI r2,#128
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r2,#8
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  LDI r1,#0
  CMP r0,r1
  JZ il49
  LDI r2,#12
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r0,#128
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il50
  LDI r0,#1
  JS il51
il50:
  LDI r0,#0
il51:
  LDI r1,#0
  CMP r0,r1
  JZ il49
  LDI r0,#1
il49:
  LDI r1,#0
  CMP r0,r1
  JZ il48
il52:
  LDI r2,#128
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r2,#8
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  LDI r3,#60
STR r0,r3
  LDI r0,#32
  LDI r1,#0
  CMP r0,r1
  JNZ il56
  LDI r2,#128
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r2,#8
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  LDI r3,#60
STR r0,r3
  LDI r0,#10
  LDI r1,#0
  CMP r0,r1
  JNZ il60
  LDI r2,#128
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r2,#8
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  LDI r3,#60
STR r0,r3
  LDI r0,#9
  LDI r1,#0
  CMP r0,r1
  JNZ il64
  LDI r2,#128
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r2,#8
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  LDI r3,#60
STR r0,r3
  LDI r0,#13
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il67
  LDI r0,#0
  JMP il66
il67:
  LDI r0,#1
il67:
  LDI r1,#0
  CMP r0,r1
  JNZ il64
  LDI r0,#0
  JMP il65
il64:
  LDI r0,#1
il65:
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il63
  LDI r0,#0
  JMP il62
il63:
  LDI r0,#1
il63:
  LDI r1,#0
  CMP r0,r1
  JNZ il60
  LDI r0,#0
  JMP il61
il60:
  LDI r0,#1
il61:
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il59
  LDI r0,#0
  JMP il58
il59:
  LDI r0,#1
il59:
  LDI r1,#0
  CMP r0,r1
  JNZ il56
  LDI r0,#0
  JMP il57
il56:
  LDI r0,#1
il57:
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il55
  LDI r0,#0
  JMP il54
il55:
  LDI r0,#1
il55:
  LDI r1,#0
  CMP r0,r1
  JZ il53
  JMP il52
il53:
  LDI r2,#8
LDR r0,r2
  INC r0
  STR r0,r2
  LDI r2,#128
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r2,#8
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  LDI r1,#0
  CMP r0,r1
  JZ il70
  LDI r0,#0
  JMP il71
il70:
  LDI r0,#1
il71:
  LDI r1,#0
  CMP r0,r1
  JZ il68
  JMP il69
il68:
il69:
  LDI r2,#128
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r2,#8
LDR r0,r2
  LDI r2,#16
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r0,#40
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il75
  LDI r0,#0
  JMP il74
il75:
  LDI r0,#1
il75:
  LDI r1,#0
  CMP r0,r1
  JZ il72
  LDI r0,#0
  LDI r3,#60
STR r0,r3
  LDI r2,#12
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDI r3,#68
STR r0,r3
  LDI r0,#8
  LDI r3,#68
LDR r1,r3
  STR r0,r1
  LDI r2,#8
LDR r0,r2
  INC r0
  STR r0,r2
  JMP il73
il72:
il73:
  LDI r2,#16
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r0,#41
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il79
  LDI r0,#0
  JMP il78
il79:
  LDI r0,#1
il79:
  LDI r1,#0
  CMP r0,r1
  JZ il76
  LDI r0,#0
  LDI r3,#60
STR r0,r3
  LDI r2,#12
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDI r3,#68
STR r0,r3
  LDI r0,#9
  LDI r3,#68
LDR r1,r3
  STR r0,r1
  LDI r2,#8
LDR r0,r2
  INC r0
  STR r0,r2
  JMP il77
il76:
il77:
  LDI r2,#16
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r0,#123
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il83
  LDI r0,#0
  JMP il82
il83:
  LDI r0,#1
il83:
  LDI r1,#0
  CMP r0,r1
  JZ il80
  LDI r0,#0
  LDI r3,#60
STR r0,r3
  LDI r2,#12
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDI r3,#68
STR r0,r3
  LDI r0,#10
  LDI r3,#68
LDR r1,r3
  STR r0,r1
  LDI r2,#8
LDR r0,r2
  INC r0
  STR r0,r2
  JMP il81
il80:
il81:
  LDI r2,#16
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r0,#125
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il87
  LDI r0,#0
  JMP il86
il87:
  LDI r0,#1
il87:
  LDI r1,#0
  CMP r0,r1
  JZ il84
  LDI r0,#0
  LDI r3,#60
STR r0,r3
  LDI r2,#12
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDI r3,#68
STR r0,r3
  LDI r0,#11
  LDI r3,#68
LDR r1,r3
  STR r0,r1
  LDI r2,#8
LDR r0,r2
  INC r0
  STR r0,r2
  JMP il85
il84:
il85:
  LDI r2,#16
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r0,#59
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il91
  LDI r0,#0
  JMP il90
il91:
  LDI r0,#1
il91:
  LDI r1,#0
  CMP r0,r1
  JZ il88
  LDI r0,#0
  LDI r3,#60
STR r0,r3
  LDI r2,#12
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDI r3,#68
STR r0,r3
  LDI r0,#12
  LDI r3,#68
LDR r1,r3
  STR r0,r1
  LDI r2,#8
LDR r0,r2
  INC r0
  STR r0,r2
  JMP il89
il88:
il89:
  LDI r2,#16
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r0,#61
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il95
  LDI r0,#0
  JMP il94
il95:
  LDI r0,#1
il95:
  LDI r1,#0
  CMP r0,r1
  JZ il92
  LDI r0,#0
  LDI r3,#60
STR r0,r3
  LDI r2,#12
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDI r3,#68
STR r0,r3
  LDI r0,#13
  LDI r3,#68
LDR r1,r3
  STR r0,r1
  LDI r2,#8
LDR r0,r2
  INC r0
  STR r0,r2
  JMP il93
il92:
il93:
  LDI r2,#16
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r0,#43
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il99
  LDI r0,#0
  JMP il98
il99:
  LDI r0,#1
il99:
  LDI r1,#0
  CMP r0,r1
  JZ il96
  LDI r0,#0
  LDI r3,#60
STR r0,r3
  LDI r2,#12
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDI r3,#68
STR r0,r3
  LDI r0,#14
  LDI r3,#68
LDR r1,r3
  STR r0,r1
  LDI r2,#8
LDR r0,r2
  INC r0
  STR r0,r2
  JMP il97
il96:
il97:
  LDI r2,#16
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r0,#45
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il103
  LDI r0,#0
  JMP il102
il103:
  LDI r0,#1
il103:
  LDI r1,#0
  CMP r0,r1
  JZ il100
  LDI r0,#0
  LDI r3,#60
STR r0,r3
  LDI r2,#12
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDI r3,#68
STR r0,r3
  LDI r0,#15
  LDI r3,#68
LDR r1,r3
  STR r0,r1
  LDI r2,#8
LDR r0,r2
  INC r0
  STR r0,r2
  JMP il101
il100:
il101:
  LDI r2,#16
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r0,#42
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il107
  LDI r0,#0
  JMP il106
il107:
  LDI r0,#1
il107:
  LDI r1,#0
  CMP r0,r1
  JZ il104
  LDI r0,#0
  LDI r3,#60
STR r0,r3
  LDI r2,#12
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDI r3,#68
STR r0,r3
  LDI r0,#16
  LDI r3,#68
LDR r1,r3
  STR r0,r1
  LDI r2,#8
LDR r0,r2
  INC r0
  STR r0,r2
  JMP il105
il104:
il105:
  LDI r2,#16
LDR r0,r2
  LDI r3,#128
STR r0,r3
  CALL isdig
  LDI r1,#0
  CMP r0,r1
  JZ il108
  LDI r0,#0
  LDI r3,#60
STR r0,r3
  LDI r2,#12
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDI r3,#68
STR r0,r3
  LDI r0,#7
  LDI r3,#68
LDR r1,r3
  STR r0,r1
  LDI r0,#0
  LDI r3,#60
STR r0,r3
  LDI r2,#12
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDI r3,#68
STR r0,r3
  LDI r0,#0
  LDI r3,#68
LDR r1,r3
  STR r0,r1
il110:
  LDI r2,#128
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r2,#8
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  LDI r3,#128
STR r0,r3
  CALL isdig
  LDI r1,#0
  CMP r0,r1
  JZ il111
  LDI r0,#0
  LDI r3,#60
STR r0,r3
  LDI r2,#12
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDI r3,#68
STR r0,r3
  LDI r0,#0
  LDI r3,#60
STR r0,r3
  LDI r2,#12
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  LDI r3,#60
STR r0,r3
  LDI r0,#10
  LDI r3,#60
STR r0,r3
  LDI r2,#128
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r2,#8
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  LDI r3,#60
STR r0,r3
  LDI r0,#48
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  SUB r0,r1
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  MUL r0,r1
  LDI r3,#68
LDR r1,r3
  STR r0,r1
  LDI r2,#8
LDR r0,r2
  INC r0
  STR r0,r2
  JMP il110
il111:
  JMP il109
il108:
il109:
  LDI r2,#16
LDR r0,r2
  LDI r3,#128
STR r0,r3
  CALL isidc
  LDI r1,#0
  CMP r0,r1
  JZ il112
  JMP il113
il112:
il113:
  JMP il47
il48:
fn_exit46:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
  HLT
printnum_sub:
  PUSH r0
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  MOV r1, r0
  LDI r2, #100
  LDI r3, #0
pn_hun114:
  CMP r1, r2
  JS pn_ten115
  SUB r1, r2
  LDI r0, #1
  ADD r3, r0
  JMP pn_hun114
pn_ten115:
  MOV r4, r1
  LDI r2, #10
  LDI r1, #0
pn_ten2116:
  CMP r4, r2
  JS pn_uni
  SUB r4, r2
  LDI r0, #1
  ADD r1, r0
  JMP pn_ten2116
pn_uni:
  PUSH r1
  LDI r0, #0
  CMP r3, r0
  JZ pn_skip_h117
  LDI r0, #48
  ADD r0, r3
  MOV r1, r0
  LDI r0, #0
  SYSCALL
pn_skip_h117:
  POP r1
  PUSH r1
  LDI r0, #0
  CMP r3, r0
  JZ pn_chk_ten118
  JMP pn_prt_ten119
pn_chk_ten118:
  LDI r0, #0
  CMP r1, r0
  JZ pn_skip_t119
pn_prt_ten119:
  LDI r0, #48
  ADD r0, r1
  MOV r1, r0
  LDI r0, #0
  SYSCALL
pn_skip_t119:
  POP r1
  MOV r0, r4
  LDI r1, #48
  ADD r0, r1
  MOV r1, r0
  LDI r0, #0
  SYSCALL
  POP r4
  POP r3
  POP r2
  POP r1
  POP r0
  RET
strcmp_sub:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  LDI r2,#128
LDR r1,r2
  LDI r2,#132
LDR r2,r2
sc_lp:
  LDR r3,r1
  LDR r4,r2
  CMP r3,r4
  JNZ sc_ne
  LDI r4,#0
  CMP r3,r4
  JZ sc_eq
  LDI r4,#1
  ADD r1,r4
  ADD r2,r4
  JMP sc_lp
sc_ne:
  LDI r0,#1
  JMP sc_ex
sc_eq:
  LDI r0,#0
sc_ex:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
strncpy_sub:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  LDI r2,#128
LDR r1,r2
  LDI r2,#132
LDR r2,r2
  LDI r4,#136
LDR r4,r4
sn_lp:
  LDI r3,#0
  CMP r4,r3
  JZ sn_ex
  LDR r3,r2
  STR r3,r1
  LDI r3,#1
  ADD r1,r3
  ADD r2,r3
  LDI r3,#1
  SUB r4,r3
  JMP sn_lp
sn_ex:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
memset_sub:
  PUSH r1
  PUSH r2
  PUSH r3
  LDI r2,#128
LDR r1,r2
  LDI r2,#132
LDR r2,r2
  LDI r3,#136
LDR r3,r3
ms_lp:
  LDI r0,#0
  CMP r3,r0
  JZ ms_ex
  STR r2,r1
  LDI r0,#1
  ADD r1,r0
  SUB r3,r0
  JMP ms_lp
ms_ex:
  POP r3
  POP r2
  POP r1
  RET
; pp=949 tok=549
