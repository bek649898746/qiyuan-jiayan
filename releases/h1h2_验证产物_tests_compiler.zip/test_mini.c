char dbuf[64];int di;
void doc(int c){if(di<63)dbuf[di]=c;di++;dbuf[di]=0;}
void dos(char*s){int i=0;while(s[i*4]){doc(s[i*4]);i++;}}
void don(int v){char b[16];int i=14;b[14]=0;b[15]=0;
 while(v>0&&i>0){b[--i]=48+(v%10);v=v/10;}
 if(i==14){doc(48);return;}dos(b+i*4);}
int main(void){
 di=0;dos("AB");don(123);dos("XY");putstr(dbuf);
 return 0;
}
