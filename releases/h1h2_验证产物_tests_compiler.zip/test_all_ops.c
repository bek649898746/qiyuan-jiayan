int main(){int a;int r;a=5;r=0;if(a>2&&a<10){r=1;}return r;}
