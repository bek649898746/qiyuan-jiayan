char out[128];int op;
void oc(int c){if(op<127)out[op]=c;op++;out[op]=0;}
void os(char*s){int i=0;while(s[i*4]){oc(s[i*4]);i++;}}
int main(void){
 op=0;
 os("TEST");
 putstr(out);
 return 0;
}
