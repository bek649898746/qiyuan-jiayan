char src[256];char dbuf[64];int di;
int tt[128];int tc;
void doc(int c){if(di<63)dbuf[di]=c;di++;dbuf[di]=0;}
void scp_src(char*s){int i=0;while(s[i*4]){src[i]=s[i*4];i++;}src[i]=0;}
void lex(void){
 int i=0;tc=0;
 if(!src[i])return;   /* just check and return */
 tt[tc]=99;tc++;i++;
 if(!src[i])return;
 tt[tc]=99;tc++;i++;
 if(!src[i])return;
 tt[tc]=99;tc++;i++;
}
int main(void){
 scp_src("int");
 lex();
 di=0;doc(48+tc);
 putstr(dbuf);
 return 0;
}
