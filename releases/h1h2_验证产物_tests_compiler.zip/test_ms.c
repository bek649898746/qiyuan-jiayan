/* mini_seed but with putstr provided */
#include <stdio.h>
char out[256];int op;
void oc(int c){if(op<255)out[op++]=c;out[op]=0;}
void os(char*s){while(*s)oc(*s++);}
int main(void){
 os("Hello World");
 printf("out=%s op=%d\n",out,op);
 return 0;
}
