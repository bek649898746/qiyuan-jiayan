char buf[256];int bi;
int main(void){
 bi=0;
 buf[bi]=72;bi+=4;
 buf[bi]=105;bi+=4;
 buf[bi]=0;
 putstr(buf);
 return 0;
}
