char tn[128][32];char src[256];
int tt[128];int tv[128];int tc;
int isdig(int c){if(c>47&&c<58)return 1;return 0;}
int isidc(int c){if((c>96&&c<123)||(c>64&&c<91)||c==95)return 1;return 0;}
int isan(int c){if(isdig(c)||isidc(c))return 1;return 0;}
int seq(char*a,char*b){int i=0;while(a[i*4]&&b[i*4]&&a[i*4]==b[i*4])i++;if(a[i*4]==b[i*4])return 1;return 0;}
void scp(char*d,char*s){int i=0;while(s[i*4]){d[i*4]=s[i*4];i++;}d[i*4]=0;}
void lex(char*s){
 int i=0;tc=0;
 while(s[i*4]&&tc<128){
  while(s[i*4]==32||s[i*4]==10||s[i*4]==9||s[i*4]==13)i++;
  if(!s[i*4])break;
  char c=s[i*4];
  if(c==40){tt[tc]=8;i++;}else if(c==41){tt[tc]=9;i++;}
  else if(c==123){tt[tc]=10;i++;}else if(c==125){tt[tc]=11;i++;}
  else if(c==59){tt[tc]=12;i++;}
  else if(c==61){tt[tc]=13;i++;}
  else if(c==43){tt[tc]=14;i++;}else if(c==45){tt[tc]=15;i++;}else if(c==42){tt[tc]=16;i++;}
  else if(isdig(c)){tt[tc]=7;tv[tc]=0;
   while(isdig(s[i*4])){tv[tc]=tv[tc]*10+(s[i*4]-48);i++;}}
  else if(isidc(c)){int j=0;
   while(isan(s[i*4])||s[i*4]==95){if(j<31){tn[tc][j]=s[i*4];j++;}i++;}tn[tc][j]=0;
   if(seq(tn[tc],"int"))tt[tc]=1;
   else if(seq(tn[tc],"return"))tt[tc]=2;
   else tt[tc]=6;
  }else i++;
  tc++;
 }
 tt[tc]=0;
}
char buf[64];int bp;
void oc(int c){if(bp<63)buf[bp]=c;bp++;buf[bp]=0;}
void os(char*s){int i=0;while(s[i*4]){oc(s[i*4]);i++;}}
int main(void){
 bp=0;scp(src,"int");lex(src);
 os("t1=");on(tt[0]);os(" t2=");on(tt[1]);os(" tc=");on(tc);os("\n");
 putstr(buf);
 return 0;
}
