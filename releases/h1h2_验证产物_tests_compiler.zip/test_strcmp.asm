; Test strcmp with actual strings
;"hello" at addr 10, "hello" at addr 20 -> strcmp should return 0
  JMP main_entry
main_entry:
  ; Store "hello\0" at addr 10
  LDI r0,#104
  LDI r3,#10
STR r0,r3
  LDI r0,#101
  LDI r3,#11
STR r0,r3
  LDI r0,#108
  LDI r3,#12
STR r0,r3
  LDI r0,#108
  LDI r3,#13
STR r0,r3
  LDI r0,#111
  LDI r3,#14
STR r0,r3
  LDI r0,#0
  LDI r3,#15
STR r0,r3
  ; Store "hello\0" at addr 20
  LDI r0,#104
  LDI r3,#20
STR r0,r3
  LDI r0,#101
  LDI r3,#21
STR r0,r3
  LDI r0,#108
  LDI r3,#22
STR r0,r3
  LDI r0,#108
  LDI r3,#23
STR r0,r3
  LDI r0,#111
  LDI r3,#24
STR r0,r3
  LDI r0,#0
  LDI r3,#25
STR r0,r3
  ; strcmp(10, 20) -> should return 0 (equal)
  LDI r0,#10
  LDI r3,#128
STR r0,r3
  LDI r0,#20
  LDI r3,#132
STR r0,r3
  CALL strcmp_sub
  HLT
  HLT
strcmp_sub:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  LDI r2,#128
LDR r1,r2
  LDI r2,#132
LDR r2,r2
sc_lp:
  LDR r3,r1
  LDR r4,r2
  CMP r3,r4
  JNZ sc_ne
  LDI r4,#0
  CMP r3,r4
  JZ sc_eq
  LDI r4,#1
  ADD r1,r4
  ADD r2,r4
  JMP sc_lp
sc_ne:
  LDI r0,#1
  JMP sc_ex
sc_eq:
  LDI r0,#0
sc_ex:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
