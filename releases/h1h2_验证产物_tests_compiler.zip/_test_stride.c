char src[256];
int main(void){
 src[0]=105;
 src[1]=110;
 src[2]=116;
 return src[0]+src[1]+src[2];
}
