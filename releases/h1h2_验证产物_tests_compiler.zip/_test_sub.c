int a; int b; int c;
int main(void) {
    int x; x=105;
    int y; y=a;
    int z; z=y-x;
    if(z==0)b=99;
    return b;
}
