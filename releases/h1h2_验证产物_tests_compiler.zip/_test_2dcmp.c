char tn[4][32];int fn;
int main(void){
 tn[1][0]=109;tn[1][1]=97;tn[1][2]=105;tn[1][3]=110;tn[1][4]=0;
 int ismain;ismain=1;
 if(tn[fn][0]!=109)ismain=0;
 if(tn[fn][1]!=97)ismain=0;
 if(tn[fn][2]!=105)ismain=0;
 if(tn[fn][3]!=110)ismain=0;
 return ismain;
}
