  LDI r0,#0
  LDI r3,#0
  STR r0,r3
loop: LDI r2,#0
  LDR r0,r2
  LDI r1,#3
  CMP r0,r1
  JZ done
  ADD r0,r1
  STR r0,r3
  JMP loop
done: LDI r2,#0
  LDR r0,r2
  HLT
