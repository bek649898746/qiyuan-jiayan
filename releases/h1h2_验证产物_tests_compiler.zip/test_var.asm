  JMP main_entry
  JMP main_entry
isdig:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  LDI r2,#128
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r0,#47
  LDI r1,#0
  CMP r0,r1
  JZ il5
  LDI r2,#128
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r0,#58
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il6
  LDI r0,#1
  JS il7
il6:
  LDI r0,#0
il7:
  LDI r1,#0
  CMP r0,r1
  JZ il5
  LDI r0,#1
il5:
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il3
  JS il3
  LDI r0,#1
  JMP il4
il3:
  LDI r0,#0
il4:
  LDI r1,#0
  CMP r0,r1
  JZ il1
  JMP il2
il1:
il2:
  LDI r0,#1
  JMP fn_exit0
  LDI r0,#0
  JMP fn_exit0
fn_exit0:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
isidc:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  LDI r2,#128
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r0,#96
  LDI r1,#0
  CMP r0,r1
  JZ il13
  LDI r2,#128
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r0,#123
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il14
  LDI r0,#1
  JS il15
il14:
  LDI r0,#0
il15:
  LDI r1,#0
  CMP r0,r1
  JZ il13
  LDI r0,#1
il13:
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il11
  JS il11
  LDI r0,#1
  JMP il12
il11:
  LDI r0,#0
il12:
  LDI r1,#0
  CMP r0,r1
  JNZ il16
  LDI r2,#128
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r0,#64
  LDI r1,#0
  CMP r0,r1
  JZ il20
  LDI r2,#128
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r0,#91
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il21
  LDI r0,#1
  JS il22
il21:
  LDI r0,#0
il22:
  LDI r1,#0
  CMP r0,r1
  JZ il20
  LDI r0,#1
il20:
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il18
  JS il18
  LDI r0,#1
  JMP il19
il18:
  LDI r0,#0
il19:
  LDI r1,#0
  CMP r0,r1
  JNZ il23
  LDI r2,#128
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r0,#95
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il26
  LDI r0,#0
  JMP il25
il26:
  LDI r0,#1
il26:
  LDI r1,#0
  CMP r0,r1
  JNZ il23
  LDI r0,#0
  JMP il24
il23:
  LDI r0,#1
il24:
  LDI r1,#0
  CMP r0,r1
  JNZ il16
  LDI r0,#0
  JMP il17
il16:
  LDI r0,#1
il17:
  LDI r1,#0
  CMP r0,r1
  JZ il9
  JMP il10
il9:
il10:
  LDI r0,#1
  JMP fn_exit8
  LDI r0,#0
  JMP fn_exit8
fn_exit8:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
isan:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  LDI r2,#128
LDR r0,r2
  LDI r3,#128
STR r0,r3
  CALL isdig
  LDI r1,#0
  CMP r0,r1
  JNZ il30
  LDI r2,#128
LDR r0,r2
  LDI r3,#128
STR r0,r3
  CALL isidc
  LDI r1,#0
  CMP r0,r1
  JNZ il30
  LDI r0,#0
  JMP il31
il30:
  LDI r0,#1
il31:
  LDI r1,#0
  CMP r0,r1
  JZ il28
  JMP il29
il28:
il29:
  LDI r0,#1
  JMP fn_exit27
  LDI r0,#0
  JMP fn_exit27
fn_exit27:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
seq:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
il33:
  LDI r2,#128
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r2,#0
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  LDI r1,#0
  CMP r0,r1
  JZ il35
  LDI r2,#132
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r2,#0
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  LDI r1,#0
  CMP r0,r1
  JZ il36
  LDI r2,#128
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r2,#0
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  LDI r3,#60
STR r0,r3
  LDI r2,#132
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r2,#0
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il38
  LDI r0,#0
  JMP il37
il38:
  LDI r0,#1
il38:
  LDI r1,#0
  CMP r0,r1
  JZ il36
  LDI r0,#1
il36:
  LDI r1,#0
  CMP r0,r1
  JZ il35
  LDI r0,#1
il35:
  LDI r1,#0
  CMP r0,r1
  JZ il34
  JMP il33
il34:
  LDI r2,#0
LDR r0,r2
  INC r0
  STR r0,r2
  LDI r2,#128
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r2,#0
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  LDI r3,#60
STR r0,r3
  LDI r2,#132
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r2,#0
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il42
  LDI r0,#0
  JMP il41
il42:
  LDI r0,#1
il42:
  LDI r1,#0
  CMP r0,r1
  JZ il39
  JMP il40
il39:
il40:
  LDI r0,#1
  JMP fn_exit32
  LDI r0,#0
  JMP fn_exit32
fn_exit32:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
scp:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
il44:
  LDI r2,#132
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r2,#4
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  LDI r1,#0
  CMP r0,r1
  JZ il45
  LDI r2,#128
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r2,#4
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDI r3,#68
STR r0,r3
  LDI r2,#132
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r2,#4
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  LDI r3,#68
LDR r1,r3
  STR r0,r1
  LDI r2,#4
LDR r0,r2
  INC r0
  STR r0,r2
  JMP il44
il45:
  LDI r2,#128
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r2,#4
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDI r3,#68
STR r0,r3
  LDI r0,#0
  LDI r3,#68
LDR r1,r3
  STR r0,r1
fn_exit43:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
lex:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  LDI r0,#0
  LDI r3,#12
STR r0,r3
il47:
  LDI r2,#128
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r2,#8
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  LDI r1,#0
  CMP r0,r1
  JZ il49
  LDI r2,#12
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r0,#128
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il50
  LDI r0,#1
  JS il51
il50:
  LDI r0,#0
il51:
  LDI r1,#0
  CMP r0,r1
  JZ il49
  LDI r0,#1
il49:
  LDI r1,#0
  CMP r0,r1
  JZ il48
il52:
  LDI r2,#128
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r2,#8
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  LDI r3,#60
STR r0,r3
  LDI r0,#32
  LDI r1,#0
  CMP r0,r1
  JNZ il56
  LDI r2,#128
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r2,#8
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  LDI r3,#60
STR r0,r3
  LDI r0,#10
  LDI r1,#0
  CMP r0,r1
  JNZ il60
  LDI r2,#128
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r2,#8
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  LDI r3,#60
STR r0,r3
  LDI r0,#9
  LDI r1,#0
  CMP r0,r1
  JNZ il64
  LDI r2,#128
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r2,#8
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  LDI r3,#60
STR r0,r3
  LDI r0,#13
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il67
  LDI r0,#0
  JMP il66
il67:
  LDI r0,#1
il67:
  LDI r1,#0
  CMP r0,r1
  JNZ il64
  LDI r0,#0
  JMP il65
il64:
  LDI r0,#1
il65:
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il63
  LDI r0,#0
  JMP il62
il63:
  LDI r0,#1
il63:
  LDI r1,#0
  CMP r0,r1
  JNZ il60
  LDI r0,#0
  JMP il61
il60:
  LDI r0,#1
  NOP
