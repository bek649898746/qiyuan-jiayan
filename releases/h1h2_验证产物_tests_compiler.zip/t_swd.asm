  JMP main_entry
  JMP main_entry
main_entry:
  LDI r0,#5
  LDI r3,#0
STR r0,r3
  LDI r2,#0
LDR r0,r2
  LDI r3,#50
STR r0,r3
  LDI r3,#50
LDR r0,r3
  LDI r1,#1
  CMP r0,r1
  JZ il1
  LDI r3,#50
LDR r0,r3
  LDI r1,#2
  CMP r0,r1
  JZ il2
0
  JMP il3
il1:
  LDI r0,#10
  LDI r3,#0
STR r0,r3
  JMP il0
il2:
  LDI r0,#20
  LDI r3,#0
STR r0,r3
  JMP il0
il3:
  LDI r0,#99
  LDI r3,#0
STR r0,r3
il0:
  LDI r2,#0
LDR r0,r2
  HLT
  HLT
printnum_sub:
  PUSH r0
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  MOV r1, r0
  LDI r2, #100
  LDI r3, #0
pn_hun4:
  CMP r1, r2
  JS pn_ten5
  SUB r1, r2
  LDI r0, #1
  ADD r3, r0
  JMP pn_hun4
pn_ten5:
  MOV r4, r1
  LDI r2, #10
  LDI r1, #0
pn_ten26:
  CMP r4, r2
  JS pn_uni
  SUB r4, r2
  LDI r0, #1
  ADD r1, r0
  JMP pn_ten26
pn_uni:
  PUSH r1
  LDI r0, #0
  CMP r3, r0
  JZ pn_skip_h7
  LDI r0, #48
  ADD r0, r3
  MOV r1, r0
  LDI r0, #0
  SYSCALL
pn_skip_h7:
  POP r1
  PUSH r1
  LDI r0, #0
  CMP r3, r0
  JZ pn_chk_ten8
  JMP pn_prt_ten9
pn_chk_ten8:
  LDI r0, #0
  CMP r1, r0
  JZ pn_skip_t9
pn_prt_ten9:
  LDI r0, #48
  ADD r0, r1
  MOV r1, r0
  LDI r0, #0
  SYSCALL
pn_skip_t9:
  POP r1
  MOV r0, r4
  LDI r1, #48
  ADD r0, r1
  MOV r1, r0
  LDI r0, #0
  SYSCALL
  POP r4
  POP r3
  POP r2
  POP r1
  POP r0
  RET
