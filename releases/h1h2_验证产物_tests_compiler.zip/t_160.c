/* cpu64_v14_self.c ??v14 + ????????+ JSON??? + ?????????
 * ???828 ??? 2026-07-13
 *
 * ???(engine_knowledge/cpu64_vm.md):
 *   A1: ???????????????M+????????C?????
 *   A2: 28??????????5-bit op, ?????????0-31
 *   A3: ENC(5+3+8)??? ??5-bit op + 3-bit rd + 8-bit val
 *   A4: ????????? ??--batch???engine_loop??????JSON???
 *   A5: ???C??? ??int/???????/if/while/???/???
 *
 * ???:
 *   --self-out "src"       ???C????????????stdout
 *   --self-out-file f.c    ??????C????????????stdout
 *   --file f.asm           ??????
 *   --batch <dir> [log.md] ??????????????c?????SON+???+???
 *   (?????                ???:??????+???????
 *
 * ??????(JSON???):
 *   {"tag":"Real","name":"<?????","lo":<lo>,"hi":<hi>}
 *   ???engine_loop scan_interval_lines/parse_json_line???
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdarg.h>
#include <ctype.h>
#define OP_NOP 0
#define OP_MOV 1
#define OP_LDI 2
#define OP_ADD 3
#define OP_SUB 4
#define OP_MUL 5
#define OP_CMP 7
#define OP_JMP 8
#define OP_JZ 9
#define OP_JNZ 10
#define OP_HLT 11
#define OP_PUSH 12
#define OP_POP 13
#define OP_CALL 14
#define OP_RET 15
#define OP_LOAD 16
#define OP_STORE 17
#define OP_INC 23
#define OP_DEC 24
#define OP_LDR 25
#define OP_STR 26
#define OP_SYSCALL 27
#define OP_JS 28
#define OP_JMPW 6
#define OP_JZW 18
#define OP_JNZW 19
#define OP_CALLW 20
#define OP_STRW 21
#define OP_LDRW 22
#define ENC(op,rd,val) ((uint16_t)(((op)&0x1F)<<11)|(((rd)&7)<<8)|((val)&0xFF))
static uint16_t M[65536],R[8],SP;
static int PC,ZF,SF,RUN;
/* ????????*/
static char vm_out[65536];
static int vm_op;
static FILE*vm_logfile;
static void vm_init(void){memset(vm_out,0,sizeof(vm_out));vm_op=0;vm_logfile=NULL;}
static void vm_run(){
 PC=0;ZF=0;SF=0;RUN=1;memset(R,0,sizeof(R));SP=65280;int s=0;
 while(RUN&&PC>=0&&PC<65536&&s<500000){
  uint16_t I=M[PC++];s++;int op=(I>>11)&0x1F,rd=(I>>8)&7,val=I&0xFF,rs=val&7;
  switch(op){
  case OP_NOP:break;case OP_MOV:R[rd]=R[rs];break;case OP_LDI:R[rd]=val;break;case OP_ADD:R[rd]+=R[rs];break;
  case OP_SUB:R[rd]-=R[rs];break;case OP_MUL:R[rd]*=R[rs];break;
  case OP_CMP:ZF=(R[rd]==R[rs]);SF=((int16_t)(R[rd]-R[rs])<0);break;
  case OP_JMP:PC+=(int8_t)val;break;case OP_JZ:if(ZF)PC+=(int8_t)val;break;case OP_JNZ:if(!ZF)PC+=(int8_t)val;break;
  case OP_JMPW:if(PC<65535)PC=M[PC];break;case OP_JZW:if(ZF&&PC<65535)PC=M[PC];break;case OP_JNZW:if(!ZF&&PC<65535)PC=M[PC];break;
  case OP_HLT:RUN=0;break;
  case OP_LOAD:R[rd]=M[SP+(int8_t)val];break;case OP_STORE:M[SP+(int8_t)val]=R[rd];break;
  case OP_CALL:SP--;M[SP]=PC;PC+=(int8_t)val;break;case OP_CALLW:SP--;M[SP]=PC+1;PC=M[PC];break;case OP_RET:PC=M[SP];SP++;break;
  case OP_PUSH:SP--;M[SP]=R[rd];break;case OP_POP:R[rd]=M[SP];SP++;break;
  case OP_JS:if(SF)PC+=(int8_t)val;break;case OP_INC:R[rd]++;break;case OP_DEC:R[rd]--;break;
  case OP_LDR:R[rd]=M[R[rs]];break;case OP_STR:M[R[rs]]=R[rd];break;
  case OP_STRW:if(PC<65535){M[M[PC]]=R[rd];PC++;}break;
  case OP_LDRW:if(PC<65535){R[rd]=M[M[PC]];PC++;}break;
  case OP_SYSCALL:
   if(R[0]==0){ /* putchar */
    char ch=(char)R[1];putchar(ch);fflush(stdout);
    if(vm_op<65535){vm_out[vm_op++]=ch;vm_out[vm_op]=0;}
    if(vm_logfile)fputc(ch,vm_logfile);
   }else if(R[0]==1){int ch=getchar();if(ch==EOF)ch=0;R[1]=ch;
   }else if(R[0]==2){ /* write file: R[1]=char */
    if(vm_logfile&&R[1])fputc((int)R[1],vm_logfile);
   }
   break;
  }
 }
}
#define MAXL 4096
#define MAXLB 64
static char LNS[MAXL][128];static int NL;
static char LN[MAXLB][64];static int LA[MAXLB];static int NB;
static void asm_p1(){
 int a=256;for(int i=0;i<NL;i++){
  for(int j=0;LNS[i][j];j++)if(LNS[i][j]==13)LNS[i][j]=32;
  char*p=LNS[i];while(*p==' '||*p=='\t')p++;
  if(!*p||*p==';')continue;char*c=strchr(p,':');if(c){*c=0;strncpy(LN[NB],p,63);LN[NB][63]=0;LA[NB]=a;NB++;
   char*r=c+1;while(*r==' '||*r=='\t')r++;if(0){strncpy(LNS[i],r,127);i--;}continue;}a++;
 }
}
static int flb(char*s){for(int i=0;i<NB;i++)if(!strcmp(LN[i],s))return i;return-1;}
static int asm_assemble(const char*text){
 NL=0;NB=0;memset(M,0,sizeof(M));char buf[32768];strncpy(buf,text,32767);buf[32767]=0;
 char*tok=strtok(buf,"\n");while(tok&&NL<MAXL){strncpy(LNS[NL],tok,127);LNS[NL][127]=0;NL++;tok=strtok(NULL,"\n");}
 asm_p1();int a=256;
 for(int i=0;i<NL;i++){
  for(char*s=LNS[i];*s;s++)if(*s=='\r')*s=' ';
  char*p=LNS[i];while(*p==' '||*p=='\t')p++;if(!*p||*p==';')continue;if(strchr(p,':'))continue;
  char w[16];int n1=0,n2=0,imm=0;sscanf(p,"%15s r%d",w,&n1);
  char*h=strchr(p,'#');if(h){imm=1;n2=atoi(h+1);}uint16_t e=0;
  if(!strcmp(w,"HLT"))e=ENC(OP_HLT,0,0);else if(!strcmp(w,"NOP"))e=0;
  else if(!strcmp(w,"MOV")||!strcmp(w,"LDI")){if(imm)e=ENC(OP_LDI,n1,n2&0xFF);else{sscanf(p,"%*s r%d, r%d",&n1,&n2);e=ENC(OP_MOV,n1,n2&7);}}
  else if(!strcmp(w,"ADD")){sscanf(p,"%*s r%d, r%d",&n1,&n2);e=ENC(OP_ADD,n1,n2&7);}
  else if(!strcmp(w,"SUB")){sscanf(p,"%*s r%d, r%d",&n1,&n2);e=ENC(OP_SUB,n1,n2&7);}
  else if(!strcmp(w,"MUL")){sscanf(p,"%*s r%d, r%d",&n1,&n2);e=ENC(OP_MUL,n1,n2&7);}
  else if(!strcmp(w,"CMP")){int r2=0;sscanf(p,"%*s r%d, r%d",&n1,&r2);e=ENC(OP_CMP,n1,r2&7);}
  else if(!strcmp(w,"JMP")||!strcmp(w,"JZ")||!strcmp(w,"JNZ")){
   int op=OP_JMP,opw=OP_JMPW;if(!strcmp(w,"JZ")){op=OP_JZ;opw=OP_JZW;}else if(!strcmp(w,"JNZ")){op=OP_JNZ;opw=OP_JNZW;}
   char lb[32];sscanf(p,"%*s %31s",lb);int f=flb(lb),off=(f>=0?LA[f]-(a+1):0);
   if(off>=-128&&off<128){e=ENC(op,0,off&0xFF);}else{M[a]=(opw<<11);M[a+1]=LA[f];a+=2;continue;}}
  else if(!strcmp(w,"JS")){char lb[32];sscanf(p,"%*s %31s",lb);int f=flb(lb),off=(f>=0?LA[f]-(a+1):0);e=ENC(OP_JS,0,off&0xFF);}
  else if(!strcmp(w,"CALL")){char lb[32];sscanf(p,"%*s %31s",lb);int f=flb(lb),off=(f>=0?LA[f]-(a+1):0);if(off>=-127&&off<128){e=ENC(OP_CALL,0,off&0xFF);}else{M[a]=(OP_CALLW<<11);M[a+1]=LA[f];a+=2;continue;}}
  else if(!strcmp(w,"RET"))e=ENC(OP_RET,0,0);
  else if(!strcmp(w,"PUSH"))e=ENC(OP_PUSH,n1,0);else if(!strcmp(w,"POP"))e=ENC(OP_POP,n1,0);
  else if(!strcmp(w,"LOAD"))e=ENC(OP_LOAD,n1,n2&0xFF);else if(!strcmp(w,"STORE"))e=ENC(OP_STORE,n1,n2&0xFF);
  else if(!strcmp(w,"INC"))e=ENC(OP_INC,n1,0);else if(!strcmp(w,"DEC"))e=ENC(OP_DEC,n1,0);
  else if(!strcmp(w,"LDR")){sscanf(p,"%*s r%d%*[, ]r%d",&n1,&n2);e=ENC(OP_LDR,n1&7,n2&7);}
  else if(!strcmp(w,"STR")){sscanf(p,"%*s r%d%*[, ]r%d",&n1,&n2);e=ENC(OP_STR,n1&7,n2&7);}
  else if(!strcmp(w,"STRW")){int v;sscanf(p,"%*s r%d%*[, ]%*[#]%d",&n1,&v);M[a]=(OP_STRW<<11)|((n1&7)<<8);M[a+1]=v;a+=2;continue;}
  else if(!strcmp(w,"LDRW")){int v;sscanf(p,"%*s r%d%*[, ]%*[#]%d",&n1,&v);M[a]=(OP_LDRW<<11)|((n1&7)<<8);M[a+1]=v;a+=2;continue;}
  else if(!strcmp(w,"SYSCALL"))e=ENC(OP_SYSCALL,0,0);
  else continue;M[a++]=e;}return a;
}
/* ????????????????????*/
#define SB_S 128
static int sb_sc,sb_sb,sb_ilab;
static char sb_sn[SB_S][32];static int sb_so[SB_S];
static int sb_qscmp(char*a,char*b){while(*a&&*b&&*a==*b){a++;b++;}return*a-*b;}
static void sb_qscpy(char*d,char*s){while(*s)*d++=*s++;*d=0;}
static int sb_vs(char*n){for(int i=0;i<sb_sc;i++)if(!sb_qscmp(sb_sn[i],n))return sb_so[i];
 if(sb_sc>=SB_S)return 0;sb_qscpy(sb_sn[sb_sc],n);sb_so[sb_sc]=sb_sb;sb_sb+=4;return sb_so[sb_sc++];}
static int sb_vf(char*n){for(int i=0;i<sb_sc;i++)if(!sb_qscmp(sb_sn[i],n))return sb_so[i];return -1;}
#define SB_A 65536
static char sb_ao[SB_A];static int sb_ap;
static void sb_putc(int c){if(sb_ap<SB_A-1)sb_ao[sb_ap++]=c;sb_ao[sb_ap]=0;}
static void sb_puts(char*s){while(*s)sb_putc(*s++);}
static void sb_putn(int v){char b[16];int i=14;b[15]=0;
 while(v>0&&i>0){b[--i]=48+(v%10);v/=10;}
 if(i==14){sb_putc(48);return;}sb_puts(b+i);}
/* === #define preprocessor (Route 5 Phase 1) === */
#define PP_MAX 64
#define PP_BUF 32768
static char pp_name[PP_MAX][32];
