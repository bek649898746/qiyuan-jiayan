int main(){int a;a=17%5;return a;}
