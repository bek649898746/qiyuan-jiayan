  LDI r0,#42
  HLT