  JMP main_entry
  JMP main_entry
vm_init:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  LDI r0,#0
  PUSH r0
  LDI r0,#0
  PUSH r0
  LDI r0,#0
  PUSH r0
  LDI r0,#0
  PUSH r0
  POP r0
  POP r0
  POP r0
  POP r0
  LDI r0,#0
  LDI r3,#0
STR r0,r3
  LDI r0,#0
  LDI r3,#4
STR r0,r3
fn_exit0:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
main_entry:
  LDI r0,#0
  HLT
  HLT
printnum_sub:
  PUSH r0
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  MOV r1, r0
  LDI r2, #100
  LDI r3, #0
pn_hun1:
  CMP r1, r2
  JS pn_ten2
  SUB r1, r2
  LDI r0, #1
  ADD r3, r0
  JMP pn_hun1
pn_ten2:
  MOV r4, r1
  LDI r2, #10
  LDI r1, #0
pn_ten23:
  CMP r4, r2
  JS pn_uni
  SUB r4, r2
  LDI r0, #1
  ADD r1, r0
  JMP pn_ten23
pn_uni:
  PUSH r1
  LDI r0, #0
  CMP r3, r0
  JZ pn_skip_h4
  LDI r0, #48
  ADD r0, r3
  MOV r1, r0
  LDI r0, #0
  SYSCALL
pn_skip_h4:
  POP r1
  PUSH r1
  LDI r0, #0
  CMP r3, r0
  JZ pn_chk_ten5
  JMP pn_prt_ten6
pn_chk_ten5:
  LDI r0, #0
  CMP r1, r0
  JZ pn_skip_t6
pn_prt_ten6:
  LDI r0, #48
  ADD r0, r1
  MOV r1, r0
  LDI r0, #0
  SYSCALL
pn_skip_t6:
  POP r1
  MOV r0, r4
  LDI r1, #48
  ADD r0, r1
  MOV r1, r0
  LDI r0, #0
  SYSCALL
  POP r4
  POP r3
  POP r2
  POP r1
  POP r0
  RET
