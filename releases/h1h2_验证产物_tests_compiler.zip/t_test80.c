/* cpu64_v14_self.c ??v14 + ????????+ JSON??? + ?????????
 * ???828 ??? 2026-07-13
 *
 * ???(engine_knowledge/cpu64_vm.md):
 *   A1: ???????????????M+????????C?????
 *   A2: 28??????????5-bit op, ?????????0-31
 *   A3: ENC(5+3+8)??? ??5-bit op + 3-bit rd + 8-bit val
 *   A4: ????????? ??--batch???engine_loop??????JSON???
 *   A5: ???C??? ??int/???????/if/while/???/???
 *
 * ???:
 *   --self-out "src"       ???C????????????stdout
 *   --self-out-file f.c    ??????C????????????stdout
 *   --file f.asm           ??????
 *   --batch <dir> [log.md] ??????????????c?????SON+???+???
 *   (?????                ???:??????+???????
 *
 * ??????(JSON???):
 *   {"tag":"Real","name":"<?????","lo":<lo>,"hi":<hi>}
 *   ???engine_loop scan_interval_lines/parse_json_line???
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdarg.h>
#include <ctype.h>
#define OP_NOP 0
#define OP_MOV 1
#define OP_LDI 2
#define OP_ADD 3
#define OP_SUB 4
#define OP_MUL 5
#define OP_CMP 7
#define OP_JMP 8
#define OP_JZ 9
#define OP_JNZ 10
#define OP_HLT 11
#define OP_PUSH 12
#define OP_POP 13
#define OP_CALL 14
#define OP_RET 15
#define OP_LOAD 16
#define OP_STORE 17
#define OP_INC 23
#define OP_DEC 24
#define OP_LDR 25
#define OP_STR 26
#define OP_SYSCALL 27
#define OP_JS 28
#define OP_JMPW 6
#define OP_JZW 18
#define OP_JNZW 19
#define OP_CALLW 20
#define OP_STRW 21
#define OP_LDRW 22
#define ENC(op,rd,val) ((uint16_t)(((op)&0x1F)<<11)|(((rd)&7)<<8)|((val)&0xFF))
static uint16_t M[65536],R[8],SP;
static int PC,ZF,SF,RUN;
/* ????????*/
static char vm_out[65536];
static int vm_op;
static FILE*vm_logfile;
int test_fn(){return 1;}static void vm_init(void){memset(vm_out,0,sizeof(vm_out));vm_op=0;vm_logfile=NULL;}
static void vm_run(){
 PC=0;ZF=0;SF=0;RUN=1;memset(R,0,sizeof(R));SP=65280;int s=0;
 while(RUN&&PC>=0&&PC<65536&&s<500000){
  uint16_t I=M[PC++];s++;int op=(I>>11)&0x1F,rd=(I>>8)&7,val=I&0xFF,rs=val&7;
  switch(op){
  case OP_NOP:break;case OP_MOV:R[rd]=R[rs];break;case OP_LDI:R[rd]=val;break;case OP_ADD:R[rd]+=R[rs];break;
  case OP_SUB:R[rd]-=R[rs];break;case OP_MUL:R[rd]*=R[rs];break;
  case OP_CMP:ZF=(R[rd]==R[rs]);SF=((int16_t)(R[rd]-R[rs])<0);break;
  case OP_JMP:PC+=(int8_t)val;break;case OP_JZ:if(ZF)PC+=(int8_t)val;break;case OP_JNZ:if(!ZF)PC+=(int8_t)val;break;
  case OP_JMPW:if(PC<65535)PC=M[PC];break;case OP_JZW:if(ZF&&PC<65535)PC=M[PC];break;case OP_JNZW:if(!ZF&&PC<65535)PC=M[PC];break;
  case OP_HLT:RUN=0;break;
  case OP_LOAD:R[rd]=M[SP+(int8_t)val];break;case OP_STORE:M[SP+(int8_t)val]=R[rd];break;
  case OP_CALL:SP--;M[SP]=PC;PC+=(int8_t)val;break;case OP_CALLW:SP--;M[SP]=PC+1;PC=M[PC];break;case OP_RET:PC=M[SP];SP++;break;
  case OP_PUSH:SP--;M[SP]=R[rd];break;case OP_POP:R[rd]=M[SP];SP++;break;
  case OP_JS:if(SF)PC+=(int8_t)val;break;case OP_INC:R[rd]++;break;case OP_DEC:R[rd]--;break;
  case OP_LDR:R[rd]=M[R[rs]];break;case OP_STR:M[R[rs]]=R[rd];break;
