int main(void){
 putstr("DIRECT");
 return 0;
}
