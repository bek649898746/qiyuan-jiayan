  case OP_NOP:break;case OP_MOV:R[rd]=R[rs];break;case OP_LDI:R[rd]=val;break;case OP_ADD:R[rd]+=R[rs];break;
  case OP_SUB:R[rd]-=R[rs];break;case OP_MUL:R[rd]*=R[rs];break;
  case OP_CMP:ZF=(R[rd]==R[rs]);SF=((int16_t)(R[rd]-R[rs])<0);break;
  case OP_JMP:PC+=(int8_t)val;break;case OP_JZ:if(ZF)PC+=(int8_t)val;break;case OP_JNZ:if(!ZF)PC+=(int8_t)val;break;
  case OP_JMPW:if(PC<65535)PC=M[PC];break;case OP_JZW:if(ZF&&PC<65535)PC=M[PC];break;case OP_JNZW:if(!ZF&&PC<65535)PC=M[PC];break;
  case OP_HLT:RUN=0;break;
  case OP_LOAD:R[rd]=M[SP+(int8_t)val];break;case OP_STORE:M[SP+(int8_t)val]=R[rd];break;
  case OP_CALL:SP--;M[SP]=PC;PC+=(int8_t)val;break;case OP_CALLW:SP--;M[SP]=PC+1;PC=M[PC];break;case OP_RET:PC=M[SP];SP++;break;
  case OP_PUSH:SP--;M[SP]=R[rd];break;case OP_POP:R[rd]=M[SP];SP++;break;
  case OP_JS:if(SF)PC+=(int8_t)val;break;case OP_INC:R[rd]++;break;case OP_DEC:R[rd]--;break;
  case OP_LDR:R[rd]=M[R[rs]];break;case OP_STR:M[R[rs]]=R[rd];break;
  case OP_STRW:if(PC<65535){M[M[PC]]=R[rd];PC++;}break;
  case OP_LDRW:if(PC<65535){R[rd]=M[M[PC]];PC++;}break;
  case OP_SYSCALL:
   if(R[0]==0){ /* putchar */
    char ch=(char)R[1];putchar(ch);fflush(stdout);
    if(vm_op<65535){vm_out[vm_op++]=ch;vm_out[vm_op]=0;}
    if(vm_logfile)fputc(ch,vm_logfile);
   }else if(R[0]==1){int ch=getchar();if(ch==EOF)ch=0;R[1]=ch;
   }else if(R[0]==2){ /* write file: R[1]=char */
    if(vm_logfile&&R[1])fputc((int)R[1],vm_logfile);
   }
   break;
  }
 }
}
#define MAXL 4096
#define MAXLB 64
static char LNS[MAXL][128];static int NL;
static char LN[MAXLB][64];static int LA[MAXLB];static int NB;
static void asm_p1(){
