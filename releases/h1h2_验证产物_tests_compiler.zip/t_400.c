/* cpu64_v14_self.c ??v14 + ????????+ JSON??? + ?????????
 * ???828 ??? 2026-07-13
 *
 * ???(engine_knowledge/cpu64_vm.md):
 *   A1: ???????????????M+????????C?????
 *   A2: 28??????????5-bit op, ?????????0-31
 *   A3: ENC(5+3+8)??? ??5-bit op + 3-bit rd + 8-bit val
 *   A4: ????????? ??--batch???engine_loop??????JSON???
 *   A5: ???C??? ??int/???????/if/while/???/???
 *
 * ???:
 *   --self-out "src"       ???C????????????stdout
 *   --self-out-file f.c    ??????C????????????stdout
 *   --file f.asm           ??????
 *   --batch <dir> [log.md] ??????????????c?????SON+???+???
 *   (?????                ???:??????+???????
 *
 * ??????(JSON???):
 *   {"tag":"Real","name":"<?????","lo":<lo>,"hi":<hi>}
 *   ???engine_loop scan_interval_lines/parse_json_line???
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdarg.h>
#include <ctype.h>
#define OP_NOP 0
#define OP_MOV 1
#define OP_LDI 2
#define OP_ADD 3
#define OP_SUB 4
#define OP_MUL 5
#define OP_CMP 7
#define OP_JMP 8
#define OP_JZ 9
#define OP_JNZ 10
#define OP_HLT 11
#define OP_PUSH 12
#define OP_POP 13
#define OP_CALL 14
#define OP_RET 15
#define OP_LOAD 16
#define OP_STORE 17
#define OP_INC 23
#define OP_DEC 24
#define OP_LDR 25
#define OP_STR 26
#define OP_SYSCALL 27
#define OP_JS 28
#define OP_JMPW 6
#define OP_JZW 18
#define OP_JNZW 19
#define OP_CALLW 20
#define OP_STRW 21
#define OP_LDRW 22
#define ENC(op,rd,val) ((uint16_t)(((op)&0x1F)<<11)|(((rd)&7)<<8)|((val)&0xFF))
static uint16_t M[65536],R[8],SP;
static int PC,ZF,SF,RUN;
/* ????????*/
static char vm_out[65536];
static int vm_op;
static FILE*vm_logfile;
static void vm_init(void){memset(vm_out,0,sizeof(vm_out));vm_op=0;vm_logfile=NULL;}
static void vm_run(){
 PC=0;ZF=0;SF=0;RUN=1;memset(R,0,sizeof(R));SP=65280;int s=0;
 while(RUN&&PC>=0&&PC<65536&&s<500000){
  uint16_t I=M[PC++];s++;int op=(I>>11)&0x1F,rd=(I>>8)&7,val=I&0xFF,rs=val&7;
  switch(op){
  case OP_NOP:break;case OP_MOV:R[rd]=R[rs];break;case OP_LDI:R[rd]=val;break;case OP_ADD:R[rd]+=R[rs];break;
  case OP_SUB:R[rd]-=R[rs];break;case OP_MUL:R[rd]*=R[rs];break;
  case OP_CMP:ZF=(R[rd]==R[rs]);SF=((int16_t)(R[rd]-R[rs])<0);break;
  case OP_JMP:PC+=(int8_t)val;break;case OP_JZ:if(ZF)PC+=(int8_t)val;break;case OP_JNZ:if(!ZF)PC+=(int8_t)val;break;
  case OP_JMPW:if(PC<65535)PC=M[PC];break;case OP_JZW:if(ZF&&PC<65535)PC=M[PC];break;case OP_JNZW:if(!ZF&&PC<65535)PC=M[PC];break;
  case OP_HLT:RUN=0;break;
  case OP_LOAD:R[rd]=M[SP+(int8_t)val];break;case OP_STORE:M[SP+(int8_t)val]=R[rd];break;
  case OP_CALL:SP--;M[SP]=PC;PC+=(int8_t)val;break;case OP_CALLW:SP--;M[SP]=PC+1;PC=M[PC];break;case OP_RET:PC=M[SP];SP++;break;
  case OP_PUSH:SP--;M[SP]=R[rd];break;case OP_POP:R[rd]=M[SP];SP++;break;
  case OP_JS:if(SF)PC+=(int8_t)val;break;case OP_INC:R[rd]++;break;case OP_DEC:R[rd]--;break;
  case OP_LDR:R[rd]=M[R[rs]];break;case OP_STR:M[R[rs]]=R[rd];break;
  case OP_STRW:if(PC<65535){M[M[PC]]=R[rd];PC++;}break;
  case OP_LDRW:if(PC<65535){R[rd]=M[M[PC]];PC++;}break;
  case OP_SYSCALL:
   if(R[0]==0){ /* putchar */
    char ch=(char)R[1];putchar(ch);fflush(stdout);
    if(vm_op<65535){vm_out[vm_op++]=ch;vm_out[vm_op]=0;}
    if(vm_logfile)fputc(ch,vm_logfile);
   }else if(R[0]==1){int ch=getchar();if(ch==EOF)ch=0;R[1]=ch;
   }else if(R[0]==2){ /* write file: R[1]=char */
    if(vm_logfile&&R[1])fputc((int)R[1],vm_logfile);
   }
   break;
  }
 }
}
#define MAXL 4096
#define MAXLB 64
static char LNS[MAXL][128];static int NL;
static char LN[MAXLB][64];static int LA[MAXLB];static int NB;
static void asm_p1(){
 int a=256;for(int i=0;i<NL;i++){
  for(int j=0;LNS[i][j];j++)if(LNS[i][j]==13)LNS[i][j]=32;
  char*p=LNS[i];while(*p==' '||*p=='\t')p++;
  if(!*p||*p==';')continue;char*c=strchr(p,':');if(c){*c=0;strncpy(LN[NB],p,63);LN[NB][63]=0;LA[NB]=a;NB++;
   char*r=c+1;while(*r==' '||*r=='\t')r++;if(0){strncpy(LNS[i],r,127);i--;}continue;}a++;
 }
}
static int flb(char*s){for(int i=0;i<NB;i++)if(!strcmp(LN[i],s))return i;return-1;}
static int asm_assemble(const char*text){
 NL=0;NB=0;memset(M,0,sizeof(M));char buf[32768];strncpy(buf,text,32767);buf[32767]=0;
 char*tok=strtok(buf,"\n");while(tok&&NL<MAXL){strncpy(LNS[NL],tok,127);LNS[NL][127]=0;NL++;tok=strtok(NULL,"\n");}
 asm_p1();int a=256;
 for(int i=0;i<NL;i++){
  for(char*s=LNS[i];*s;s++)if(*s=='\r')*s=' ';
  char*p=LNS[i];while(*p==' '||*p=='\t')p++;if(!*p||*p==';')continue;if(strchr(p,':'))continue;
  char w[16];int n1=0,n2=0,imm=0;sscanf(p,"%15s r%d",w,&n1);
  char*h=strchr(p,'#');if(h){imm=1;n2=atoi(h+1);}uint16_t e=0;
  if(!strcmp(w,"HLT"))e=ENC(OP_HLT,0,0);else if(!strcmp(w,"NOP"))e=0;
  else if(!strcmp(w,"MOV")||!strcmp(w,"LDI")){if(imm)e=ENC(OP_LDI,n1,n2&0xFF);else{sscanf(p,"%*s r%d, r%d",&n1,&n2);e=ENC(OP_MOV,n1,n2&7);}}
  else if(!strcmp(w,"ADD")){sscanf(p,"%*s r%d, r%d",&n1,&n2);e=ENC(OP_ADD,n1,n2&7);}
  else if(!strcmp(w,"SUB")){sscanf(p,"%*s r%d, r%d",&n1,&n2);e=ENC(OP_SUB,n1,n2&7);}
  else if(!strcmp(w,"MUL")){sscanf(p,"%*s r%d, r%d",&n1,&n2);e=ENC(OP_MUL,n1,n2&7);}
  else if(!strcmp(w,"CMP")){int r2=0;sscanf(p,"%*s r%d, r%d",&n1,&r2);e=ENC(OP_CMP,n1,r2&7);}
  else if(!strcmp(w,"JMP")||!strcmp(w,"JZ")||!strcmp(w,"JNZ")){
   int op=OP_JMP,opw=OP_JMPW;if(!strcmp(w,"JZ")){op=OP_JZ;opw=OP_JZW;}else if(!strcmp(w,"JNZ")){op=OP_JNZ;opw=OP_JNZW;}
   char lb[32];sscanf(p,"%*s %31s",lb);int f=flb(lb),off=(f>=0?LA[f]-(a+1):0);
   if(off>=-128&&off<128){e=ENC(op,0,off&0xFF);}else{M[a]=(opw<<11);M[a+1]=LA[f];a+=2;continue;}}
  else if(!strcmp(w,"JS")){char lb[32];sscanf(p,"%*s %31s",lb);int f=flb(lb),off=(f>=0?LA[f]-(a+1):0);e=ENC(OP_JS,0,off&0xFF);}
  else if(!strcmp(w,"CALL")){char lb[32];sscanf(p,"%*s %31s",lb);int f=flb(lb),off=(f>=0?LA[f]-(a+1):0);if(off>=-127&&off<128){e=ENC(OP_CALL,0,off&0xFF);}else{M[a]=(OP_CALLW<<11);M[a+1]=LA[f];a+=2;continue;}}
  else if(!strcmp(w,"RET"))e=ENC(OP_RET,0,0);
  else if(!strcmp(w,"PUSH"))e=ENC(OP_PUSH,n1,0);else if(!strcmp(w,"POP"))e=ENC(OP_POP,n1,0);
  else if(!strcmp(w,"LOAD"))e=ENC(OP_LOAD,n1,n2&0xFF);else if(!strcmp(w,"STORE"))e=ENC(OP_STORE,n1,n2&0xFF);
  else if(!strcmp(w,"INC"))e=ENC(OP_INC,n1,0);else if(!strcmp(w,"DEC"))e=ENC(OP_DEC,n1,0);
  else if(!strcmp(w,"LDR")){sscanf(p,"%*s r%d%*[, ]r%d",&n1,&n2);e=ENC(OP_LDR,n1&7,n2&7);}
  else if(!strcmp(w,"STR")){sscanf(p,"%*s r%d%*[, ]r%d",&n1,&n2);e=ENC(OP_STR,n1&7,n2&7);}
  else if(!strcmp(w,"STRW")){int v;sscanf(p,"%*s r%d%*[, ]%*[#]%d",&n1,&v);M[a]=(OP_STRW<<11)|((n1&7)<<8);M[a+1]=v;a+=2;continue;}
  else if(!strcmp(w,"LDRW")){int v;sscanf(p,"%*s r%d%*[, ]%*[#]%d",&n1,&v);M[a]=(OP_LDRW<<11)|((n1&7)<<8);M[a+1]=v;a+=2;continue;}
  else if(!strcmp(w,"SYSCALL"))e=ENC(OP_SYSCALL,0,0);
  else continue;M[a++]=e;}return a;
}
/* ????????????????????*/
#define SB_S 128
static int sb_sc,sb_sb,sb_ilab;
static char sb_sn[SB_S][32];static int sb_so[SB_S];
static int sb_qscmp(char*a,char*b){while(*a&&*b&&*a==*b){a++;b++;}return*a-*b;}
static void sb_qscpy(char*d,char*s){while(*s)*d++=*s++;*d=0;}
static int sb_vs(char*n){for(int i=0;i<sb_sc;i++)if(!sb_qscmp(sb_sn[i],n))return sb_so[i];
 if(sb_sc>=SB_S)return 0;sb_qscpy(sb_sn[sb_sc],n);sb_so[sb_sc]=sb_sb;sb_sb+=4;return sb_so[sb_sc++];}
static int sb_vf(char*n){for(int i=0;i<sb_sc;i++)if(!sb_qscmp(sb_sn[i],n))return sb_so[i];return -1;}
#define SB_A 65536
static char sb_ao[SB_A];static int sb_ap;
static void sb_putc(int c){if(sb_ap<SB_A-1)sb_ao[sb_ap++]=c;sb_ao[sb_ap]=0;}
static void sb_puts(char*s){while(*s)sb_putc(*s++);}
static void sb_putn(int v){char b[16];int i=14;b[15]=0;
 while(v>0&&i>0){b[--i]=48+(v%10);v/=10;}
 if(i==14){sb_putc(48);return;}sb_puts(b+i);}
/* === #define preprocessor (Route 5 Phase 1) === */
#define PP_MAX 64
#define PP_BUF 32768
static char pp_name[PP_MAX][32];
static char pp_val[PP_MAX][32];
static int pp_count;
static void sb_preprocess(char*src,char*dst,int dmax){
 pp_count=0;int i=0,di=0;
 while(src[i]&&di<dmax-1){
  char c=src[i];
  /* #define detection */
  if(c=='#'&&src[i+1]=='d'&&src[i+2]=='e'&&src[i+3]=='f'&&src[i+4]=='i'&&src[i+5]=='n'&&src[i+6]=='e'){
   i+=7;while(src[i]==' '||src[i]==9)i++;
   int ni=0;while(src[i]&&src[i]!=' '&&src[i]!=9&&src[i]!=10&&src[i]!=13&&ni<31)pp_name[pp_count][ni++]=src[i++];
   pp_name[pp_count][ni]=0;
   /* skip function-like macros (contain parentheses after name) */
   int is_func_macro=0;int ti=i;
   while(src[ti]==' '||src[ti]==9)ti++;
   if(src[ti]=='(')is_func_macro=1;
   while(src[i]&&src[i]!=10&&src[i]!=13)i++;
   if(is_func_macro){while(src[i]==10||src[i]==13)i++;continue;}
   i=ti;
   int vi=0;while(src[i]&&src[i]!=10&&src[i]!=13&&vi<31)pp_val[pp_count][vi++]=src[i++];
   pp_val[pp_count][vi]=0;
   if(pp_count<PP_MAX-1)pp_count++;
   while(src[i]==10||src[i]==13)i++;continue;
  }
  /* #include detection ? skip entire line */
  if(c=='#'&&src[i+1]=='i'&&src[i+2]=='n'&&src[i+3]=='c'){
   while(src[i]&&src[i]!=10)i++;
   while(src[i]==10||src[i]==13)i++;continue;
  }
  /* identifier -> macro expansion check */
  if((c>='a'&&c<='z')||(c>='A'&&c<='Z')||c=='_'){
   int start=i;
   while((src[i]>='a'&&src[i]<='z')||(src[i]>='A'&&src[i]<='Z')||(src[i]>='0'&&src[i]<='9')||src[i]=='_')i++;
   int len=i-start,matched=-1;
   for(int pi=0;pi<pp_count;pi++){
    int plen=0;while(pp_name[pi][plen])plen++;
    if(len!=plen)continue;int eq=1;
    for(int j=0;j<len;j++)if(src[start+j]!=pp_name[pi][j]){eq=0;break;}
    if(eq){matched=pi;break;}
   }
   if(matched>=0){
    int vj=0;while(pp_val[matched][vj]&&di<dmax-2)dst[di++]=pp_val[matched][vj++];
   }else{
    if(di<dmax-1)dst[di++]=c;
    for(int j=start+1;j<i&&di<dmax-1;j++)dst[di++]=src[j];
   }
   continue;
  }
  dst[di++]=c;i++;
 }
 dst[di]=0;
}
/* === array symbol table === */
#define ARR_MAX 32
static char arr_name[ARR_MAX][32];
static int arr_base[ARR_MAX];
static int arr_len[ARR_MAX];
static int arr_count;
#define SB_TS 512
static int sb_tt[SB_TS],sb_tv[SB_TS];static char sb_tn[SB_TS][32];static int sb_ti,sb_tk;
#define TK_EOF 0
#define TK_INT 1
#define TK_VOID 100
#define TK_CHAR 101
#define TK_STATIC 102
#define TK_FOR 103
#define TK_SWITCH 104
#define TK_CASE 105
#define TK_DEFAULT 106
#define TK_BREAK 107
#define TK_CONST 108
#define TK_CONTINUE 109
#define TK_RET 2
#define TK_IF 3
#define TK_EL 4
#define TK_WH 5
#define TK_ID 6
#define TK_NUM 7
#define TK_LP 8
#define TK_RP 9
#define TK_LB 10
#define TK_RB 11
#define TK_SEMI 12
#define TK_PLUS 13
#define TK_MINUS 14
#define TK_STAR 15
#define TK_ASSIGN 16
#define TK_LT 17
#define TK_GT 18
#define TK_EQ 23
#define TK_NE 24
#define TK_STR 19
#define TK_COMMA 20
#define TK_LBRACKET 21
#define TK_RBRACKET 22
#define TK_COLON 23
#define TK_EQ 24
#define TK_NE 25
static int sb_qisd(char c){return c>='0'&&c<='9'?1:0;}
static int sb_qisa(char c){return((c>='a'&&c<='z')||(c>='A'&&c<='Z'))?1:0;}
static int sb_qian(char c){return(sb_qisd(c)||sb_qisa(c))?1:0;}

static void sb_lex(char*s){
 int i=0;sb_ti=0;
 /* skip UTF-8 BOM */
 if((unsigned char)s[0]==0xEF&&(unsigned char)s[1]==0xBB&&(unsigned char)s[2]==0xBF)i=3;
 while(s[i]&&sb_ti<SB_TS){
  while(s[i]==' '||s[i]==10||s[i]==9||s[i]==13)i++;
  if(!s[i])break;char c=s[i];
  if(c=='{'){sb_tt[sb_ti]=TK_LB;i++;}
  else if(c=='}'){sb_tt[sb_ti]=TK_RB;i++;}
  else if(c=='('){sb_tt[sb_ti]=TK_LP;i++;}
  else if(c==')'){sb_tt[sb_ti]=TK_RP;i++;}
  else if(c==';'){sb_tt[sb_ti]=TK_SEMI;i++;}
  else if(c==':'){sb_tt[sb_ti]=TK_COLON;i++;}
  else if(c=='+'){sb_tt[sb_ti]=TK_PLUS;i++;}
  else if(c=='-'){sb_tt[sb_ti]=TK_MINUS;i++;}
  else if(c=='*'){sb_tt[sb_ti]=TK_STAR;i++;}
  else if(c=='='&&s[i+1]=='='){sb_tt[sb_ti]=TK_EQ;i+=2;}
  else if(c=='!'&&s[i+1]=='='){sb_tt[sb_ti]=TK_NE;i+=2;}
  else if(c=='='){sb_tt[sb_ti]=TK_ASSIGN;i++;}
  else if(c==','){sb_tt[sb_ti]=TK_COMMA;i++;}
  else if(c=='['){sb_tt[sb_ti]=TK_LBRACKET;i++;}
  else if(c==']'){sb_tt[sb_ti]=TK_RBRACKET;i++;}
  else if(c=='"'){
   sb_tt[sb_ti]=TK_STR;i++;int si=0;
   while(s[i]&&s[i]!='"'&&si<31){sb_tn[sb_ti][si++]=s[i++];}sb_tn[sb_ti][si]=0;if(s[i]=='"')i++;}
  else if(c=='/'){
   if(s[i+1]=='/'){i+=2;while(s[i]&&s[i]!=10)i++;continue;}
   else if(s[i+1]=='*'){i+=2;while(s[i]&&!(s[i]=='*'&&s[i+1]=='/'))i++;if(s[i])i+=2;continue;}
   else i++;}
  else if(c=='<'){sb_tt[sb_ti]=TK_LT;i++;}
  else if(c=='>'){sb_tt[sb_ti]=TK_GT;i++;}
  else if(sb_qisd(c)){sb_tt[sb_ti]=TK_NUM;sb_tv[sb_ti]=0;
   while(sb_qisd(s[i])){sb_tv[sb_ti]=sb_tv[sb_ti]*10+(s[i++]-48);}}
  else if(sb_qisa(c)||c=='_'){int j=0;
   while(sb_qian(s[i])||s[i]=='_'){sb_tn[sb_ti][j++]=s[i++];}sb_tn[sb_ti][j]=0;
   if(!sb_qscmp(sb_tn[sb_ti],"int"))sb_tt[sb_ti]=TK_INT;
   else if(!sb_qscmp(sb_tn[sb_ti],"void"))sb_tt[sb_ti]=TK_VOID;
   else if(!sb_qscmp(sb_tn[sb_ti],"char"))sb_tt[sb_ti]=TK_CHAR;
   else if(!sb_qscmp(sb_tn[sb_ti],"static"))sb_tt[sb_ti]=TK_STATIC;
   else if(!sb_qscmp(sb_tn[sb_ti],"for"))sb_tt[sb_ti]=TK_FOR;
   else if(!sb_qscmp(sb_tn[sb_ti],"return"))sb_tt[sb_ti]=TK_RET;
   else if(!sb_qscmp(sb_tn[sb_ti],"while"))sb_tt[sb_ti]=TK_WH;
   else if(!sb_qscmp(sb_tn[sb_ti],"if"))sb_tt[sb_ti]=TK_IF;
   else if(!sb_qscmp(sb_tn[sb_ti],"else"))sb_tt[sb_ti]=TK_EL;
   else if(!sb_qscmp(sb_tn[sb_ti],"for"))sb_tt[sb_ti]=TK_FOR;
   else if(!sb_qscmp(sb_tn[sb_ti],"switch"))sb_tt[sb_ti]=TK_SWITCH;
   else if(!sb_qscmp(sb_tn[sb_ti],"case"))sb_tt[sb_ti]=TK_CASE;
   else if(!sb_qscmp(sb_tn[sb_ti],"default"))sb_tt[sb_ti]=TK_DEFAULT;
   else if(!sb_qscmp(sb_tn[sb_ti],"break"))sb_tt[sb_ti]=TK_BREAK;
   else if(!sb_qscmp(sb_tn[sb_ti],"const"))sb_tt[sb_ti]=TK_CONST;
   else if(!sb_qscmp(sb_tn[sb_ti],"continue"))sb_tt[sb_ti]=TK_CONTINUE;
   else sb_tt[sb_ti]=TK_ID;}
  else i++;
  if(sb_ti<SB_TS)sb_ti++;
 }
 sb_tt[sb_ti]=TK_EOF;
}
static void sb_emit_str_lit(const char*s){
 while(*s){int ch=(unsigned char)*s++;
  sb_puts("  LDI r1,#");sb_putn(ch);sb_puts("\n  LDI r0,#0\n  SYSCALL\n");}
}
/* ?????rintnum: CALL????????*/
/* ????? r0?? ??????+???+??? */
/* ????? r0=???, r1=???, r2=10/100, r3=???, r4=??? */
static int sb_printnum_lab_base=-1;
static int sb_in_main;
static int sb_fn_exit_lab;
/* ???????????*/
static int sbf_has(const char*nm);
/* ????? _arg0=128, _arg1=132, _arg2=136, _arg3=140 */
static void sb_reg_args(void){
 for(int i=0;i<4;i++){
  sb_qscpy(sb_sn[sb_sc],"_arg");
  int len=4;sb_sn[sb_sc][len]=48+i;sb_sn[sb_sc][len+1]=0;
  sb_so[sb_sc]=128+i*4;sb_sc++;
 }
}
static void sb_emit_printnum_sub(void){
 if(sb_printnum_lab_base>=0)return;
 sb_printnum_lab_base=sb_ilab;
 int l0=sb_ilab++;int l1=sb_ilab++;int l2=sb_ilab++;
 /* push; ????? r1/100->r3????? ???->r1 */
 sb_puts("printnum_sub:\n  PUSH r0\n  PUSH r1\n  PUSH r2\n  PUSH r3\n  PUSH r4\n  MOV r1, r0\n");
 sb_puts("  LDI r2, #100\n  LDI r3, #0\npn_hun");sb_putn(l0);sb_puts(":\n  CMP r1, r2\n");
 sb_puts("  JS pn_ten");sb_putn(l1);sb_puts("\n  SUB r1, r2\n  LDI r0, #1\n  ADD r3, r0\n  JMP pn_hun");sb_putn(l0);
 /* r3=???, r1=???(0-99); ????? ???/10 */
 sb_puts("\npn_ten");sb_putn(l1);sb_puts(":\n  MOV r4, r1\n  LDI r2, #10\n  LDI r1, #0\npn_ten2");sb_putn(l2);
 sb_puts(":\n  CMP r4, r2\n  JS pn_uni\n  SUB r4, r2\n  LDI r0, #1\n  ADD r1, r0\n  JMP pn_ten2");sb_putn(l2);
 /* r4=???, r1=???, r3=???; ??????: ???(???0), ???(?????????????, ??? */
 int skip_h=sb_ilab++;
 sb_puts("\npn_uni:\n  PUSH r1\n");
 sb_puts("  LDI r0, #0\n  CMP r3, r0\n  JZ pn_skip_h");sb_putn(skip_h);sb_puts("\n");
 sb_puts("  LDI r0, #48\n  ADD r0, r3\n  MOV r1, r0\n  LDI r0, #0\n  SYSCALL\n");
 sb_puts("pn_skip_h");sb_putn(skip_h);sb_puts(":\n");
 sb_puts("  POP r1\n  PUSH r1\n");
 /* ???: ???>0????????, ???=0?????0?????? */
 int skip_t0=sb_ilab++;int skip_t=sb_ilab++;
 sb_puts("  LDI r0, #0\n  CMP r3, r0\n  JZ pn_chk_ten");sb_putn(skip_t0);sb_puts("\n");
 sb_puts("  JMP pn_prt_ten");sb_putn(skip_t);sb_puts("\npn_chk_ten");sb_putn(skip_t0);sb_puts(":\n");
 sb_puts("  LDI r0, #0\n  CMP r1, r0\n  JZ pn_skip_t");sb_putn(skip_t);sb_puts("\n");
 sb_puts("pn_prt_ten");sb_putn(skip_t);sb_puts(":\n");
 sb_puts("  LDI r0, #48\n  ADD r0, r1\n  MOV r1, r0\n  LDI r0, #0\n  SYSCALL\n");
 sb_puts("pn_skip_t");sb_putn(skip_t);sb_puts(":\n");
 sb_puts("  POP r1\n  MOV r0, r4\n  LDI r1, #48\n  ADD r0, r1\n  MOV r1, r0\n  LDI r0, #0\n  SYSCALL\n");
 sb_puts("  POP r4\n  POP r3\n  POP r2\n  POP r1\n  POP r0\n  RET\n");
}
static void sb_emit_printnum_call(void){
 sb_puts("  CALL printnum_sub\n");
}
static void sb_cexpr(void);
static void sb_cstmt(void);
static void sb_cexpr(void){
 int a=sb_tt[sb_tk];
 if(a==TK_NUM){sb_puts("  LDI r0,#");sb_putn(sb_tv[sb_tk]);sb_puts("\n");sb_tk++;}
 else if(a==TK_ID){
  if(sb_tt[sb_tk+1]==TK_LP&&sbf_has(sb_tn[sb_tk])){
   char fn[32];int fi=0;while(sb_tn[sb_tk][fi]){fn[fi]=sb_tn[sb_tk][fi];fi++;}fn[fi]=0;sb_tk++;
   if(sb_tt[sb_tk]==TK_LP)sb_tk++;
   /* ???: ???M[128],M[132]... */
   int argc=0;
   while(sb_tt[sb_tk]!=TK_RP&&sb_tt[sb_tk]!=TK_EOF){
    if(sb_tt[sb_tk]==TK_COMMA)sb_tk++;
    sb_cexpr();sb_puts("  LDI r3,#");sb_putn(128+argc*4);sb_puts("\nSTR r0,r3\n");
    argc++;if(argc>=4)break;
   }
   if(sb_tt[sb_tk]==TK_RP)sb_tk++;
   sb_puts("  CALL ");sb_puts(fn);sb_puts("\n");
  }else{
   /* array read: name[...] */
   int arr_idx=-1;
   for(int ai=0;ai<arr_count;ai++)if(!sb_qscmp(sb_tn[sb_tk],arr_name[ai])){arr_idx=ai;break;}
   if(arr_idx>=0&&sb_tt[sb_tk+1]==TK_LBRACKET){
    sb_tk++;sb_tk++;sb_cexpr();if(sb_tt[sb_tk]==TK_RBRACKET)sb_tk++;
    sb_puts("  ADD r0,r0\n  ADD r0,r0\n");
    sb_puts("  LDI r1,#");sb_putn(arr_base[arr_idx]);sb_puts("\n  ADD r1,r0\n");
    sb_puts("  LDR r0,r1\n");
   }else{
    int ad=sb_vf(sb_tn[sb_tk]);
    if(ad>=0){sb_puts("  LDI r2,#");sb_putn(ad);sb_puts("\nLDR r0,r2\n");}
