  JMP main_entry
  JMP main_entry
main_entry:
  LDI r0,#0
  LDI r3,#0
STR r0,r3
  LDI r0,#0
  LDI r3,#4
STR r0,r3
  LDI r2,#0
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r0,#0
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il2
  LDI r0,#1
  JS il3
il2:
  LDI r0,#0
il3:
  LDI r1,#0
  CMP r0,r1
  JNZ il4
  LDI r2,#0
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r0,#0
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il6
  JS il6
  LDI r0,#1
  JMP il7
il6:
  LDI r0,#0
il7:
  LDI r1,#0
  CMP r0,r1
  JNZ il8
  LDI r2,#0
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r0,#0
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il10
  LDI r0,#0
  JMP il9
il10:
  LDI r0,#1
il10:
  LDI r1,#0
  CMP r0,r1
  JNZ il8
  LDI r0,#0
  JMP il11
il8:
  LDI r0,#1
il11:
  LDI r1,#0
  CMP r0,r1
  JNZ il4
  LDI r0,#0
  JMP il5
il4:
  LDI r0,#1
il5:
  LDI r1,#0
  CMP r0,r1
  JZ il0
  LDI r0,#1
  LDI r3,#4
STR r0,r3
  JMP il1
il0:
il1:
  LDI r2,#4
LDR r0,r2
  HLT
