int g;
int main(){int a;a=g;return a;}
