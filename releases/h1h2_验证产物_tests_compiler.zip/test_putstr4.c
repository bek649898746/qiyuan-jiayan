char buf[64];int bp;
void oc(int c){if(bp<63)buf[bp]=c;bp++;buf[bp]=0;}
void os(char*s){while(*s){oc(*s);s+=4;}}
int main(void){
 bp=0;
 os("HELLO");
 putstr(buf);
 return 0;
}
