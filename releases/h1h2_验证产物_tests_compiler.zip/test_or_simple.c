int main(){int a;a=1;if(a||0){return 1;}return 0;}
