  LDI r0,#5
  LDI r1,#10
  CMP r0,r1
  LDI r0,#1
  JS yes
  LDI r0,#0
yes: HLT
