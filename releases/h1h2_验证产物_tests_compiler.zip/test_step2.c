char src[512];char dbuf[256];int di;
int tt[128];int tc;
void doc(int c){if(di<255)dbuf[di]=c;di++;dbuf[di]=0;}
void scp(char*d,char*s){int i=0;while(s[i*4]){d[i*4]=s[i*4];i++;}d[i*4]=0;}
void lex(char*s){
 int i=0;tc=0;
 while(1){if(!s[i*4])break;tt[tc]=1;tc++;if(tc>=120)break;i++;}
 tt[tc]=0;
}
int main(void){
 scp(src,"int");
 lex(src);
 di=0;tc=1;doc(120);  /* output 'x' as marker that we got here */
 putstr(dbuf);
 return 0;
}
