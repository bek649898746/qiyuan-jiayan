  JMP main_entry
main_entry:
  LDI r0,#42
  LDI r3,#0
  STR r0,r3
  LDI r3,#0
  LDR r0,r3
  HLT
  HLT
