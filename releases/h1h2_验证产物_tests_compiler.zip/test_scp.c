char src[64];char out[64];int op;
void oc(int c){if(op<63)out[op]=c;op++;out[op]=0;}
void scp(char*d,char*s){int i=0;while(s[i*4]){d[i*4]=s[i*4];i++;}d[i*4]=0;}
int main(void){
 scp(src,"AB");
 op=0;oc(src[0]);oc(src[1]);
 putstr(out);
 return 0;
}
