char buf[64];int bp;
void oc(int c){if(bp<63)buf[bp]=c;bp++;buf[bp]=0;}
void scp(char*d,char*s){int i=0;while(s[i*4]){d[i*4]=s[i*4];i++;}d[i*4]=0;}
char src[64];
int main(void){
 scp(src,"ABC");bp=0;oc(src[0]);oc(src[1]);oc(src[2]);putstr(buf);
 return 0;
}
