  JMP main_entry
  JMP main_entry
main_entry:
  LDI r0,#0
  LDI r3,#0
STR r0,r3
  LDI r0,#0
  LDI r3,#4
STR r0,r3
il0:
  LDI r2,#4
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r0,#10
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il2
  LDI r0,#1
  JS il3
il2:
  LDI r0,#0
il3:
  LDI r1,#0
  CMP r0,r1
  JZ il1
  LDI r2,#0
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r2,#4
LDR r0,r2
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDI r3,#0
STR r0,r3
  LDI r2,#4
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r0,#1
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDI r3,#4
STR r0,r3
  JMP il0
il1:
  LDI r2,#0
LDR r0,r2
  HLT
