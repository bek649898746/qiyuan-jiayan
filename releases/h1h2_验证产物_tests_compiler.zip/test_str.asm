  LDI r0,#42
  LDI r3,#100
  STR r0,r3
  LDI r0,#0
  LDR r0,r3
  HLT
