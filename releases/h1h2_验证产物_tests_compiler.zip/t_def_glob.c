#define MAXL 4096
#define MAXLB 64
static char LNS[MAXL][128];
static int NL;
static char LN[MAXLB][64];
static int LA[MAXLB];
static int NB;
void asm_p1(){
 int a=256;
 int i=0;
 while(i<10){
  i=i+1;
 }
}
int main(){asm_p1();return 0;}