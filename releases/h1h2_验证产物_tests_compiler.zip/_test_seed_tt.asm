  JMP main_entry
  JMP main_entry
isdig:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  LDI r2,#128
LDR r0,r2
  PUSH r0
  LDI r0,#47
  LDI r1,#0
  CMP r0,r1
  JZ il5
  LDI r2,#128
LDR r0,r2
  PUSH r0
  LDI r0,#58
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il6
  LDI r0,#1
  JS il7
il6:
  LDI r0,#0
il7:
  LDI r1,#0
  CMP r0,r1
  JZ il5
  LDI r0,#1
il5:
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il3
  JS il3
  LDI r0,#1
  JMP il4
il3:
  LDI r0,#0
il4:
  LDI r1,#0
  CMP r0,r1
  JZ il1
  JMP il2
il1:
il2:
  LDI r0,#1
  JMP fn_exit0
  LDI r0,#0
  JMP fn_exit0
fn_exit0:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
isidc:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  LDI r2,#128
LDR r0,r2
  PUSH r0
  LDI r0,#96
  LDI r1,#0
  CMP r0,r1
  JZ il13
  LDI r2,#128
LDR r0,r2
  PUSH r0
  LDI r0,#123
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il14
  LDI r0,#1
  JS il15
il14:
  LDI r0,#0
il15:
  LDI r1,#0
  CMP r0,r1
  JZ il13
  LDI r0,#1
il13:
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il11
  JS il11
  LDI r0,#1
  JMP il12
il11:
  LDI r0,#0
il12:
  LDI r1,#0
  CMP r0,r1
  JNZ il16
  LDI r2,#128
LDR r0,r2
  PUSH r0
  LDI r0,#64
  LDI r1,#0
  CMP r0,r1
  JZ il20
  LDI r2,#128
LDR r0,r2
  PUSH r0
  LDI r0,#91
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il21
  LDI r0,#1
  JS il22
il21:
  LDI r0,#0
il22:
  LDI r1,#0
  CMP r0,r1
  JZ il20
  LDI r0,#1
il20:
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il18
  JS il18
  LDI r0,#1
  JMP il19
il18:
  LDI r0,#0
il19:
  LDI r1,#0
  CMP r0,r1
  JNZ il23
  LDI r2,#128
LDR r0,r2
  PUSH r0
  LDI r0,#95
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il25
  LDI r0,#0
  JMP il26
il25:
  LDI r0,#1
il26:
  LDI r1,#0
  CMP r0,r1
  JNZ il23
  LDI r0,#0
  JMP il24
il23:
  LDI r0,#1
il24:
  LDI r1,#0
  CMP r0,r1
  JNZ il16
  LDI r0,#0
  JMP il17
il16:
  LDI r0,#1
il17:
  LDI r1,#0
  CMP r0,r1
  JZ il9
  JMP il10
il9:
il10:
  LDI r0,#1
  JMP fn_exit8
  LDI r0,#0
  JMP fn_exit8
fn_exit8:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
isan:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  LDI r2,#128
LDR r0,r2
  LDI r3,#40
STR r0,r3
  LDRW r0,#128
  STRW r0,#80
  LDRW r0,#132
  STRW r0,#84
  LDRW r0,#136
  STRW r0,#88
  LDRW r0,#140
  STRW r0,#92
  LDI r3,#40
LDR r0,r3
  LDI r3,#128
STR r0,r3
  CALL isdig
  LDRW r0,#80
  STRW r0,#128
  LDRW r0,#84
  STRW r0,#132
  LDRW r0,#88
  STRW r0,#136
  LDRW r0,#92
  STRW r0,#140
  LDI r1,#0
  CMP r0,r1
  JNZ il30
  LDI r2,#128
LDR r0,r2
  LDI r3,#40
STR r0,r3
  LDRW r0,#128
  STRW r0,#80
  LDRW r0,#132
  STRW r0,#84
  LDRW r0,#136
  STRW r0,#88
  LDRW r0,#140
  STRW r0,#92
  LDI r3,#40
LDR r0,r3
  LDI r3,#128
STR r0,r3
  CALL isidc
  LDRW r0,#80
  STRW r0,#128
  LDRW r0,#84
  STRW r0,#132
  LDRW r0,#88
  STRW r0,#136
  LDRW r0,#92
  STRW r0,#140
  LDI r1,#0
  CMP r0,r1
  JNZ il30
  LDI r0,#0
  JMP il31
il30:
  LDI r0,#1
il31:
  LDI r1,#0
  CMP r0,r1
  JZ il28
  JMP il29
il28:
il29:
  LDI r0,#1
  JMP fn_exit27
  LDI r0,#0
  JMP fn_exit27
fn_exit27:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
seq:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
il33:
  LDI r2,#128
LDR r0,r2
  LDI r3,#68
STR r0,r3
  LDRW r0,#34828
  LDI r3,#64
STR r0,r3
  LDI r3,#68
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  LDI r1,#0
  CMP r0,r1
  JZ il35
  LDI r2,#132
LDR r0,r2
  LDI r3,#68
STR r0,r3
  LDRW r0,#34828
  LDI r3,#64
STR r0,r3
  LDI r3,#68
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  LDI r1,#0
  CMP r0,r1
  JZ il36
  LDI r2,#128
LDR r0,r2
  LDI r3,#68
STR r0,r3
  LDRW r0,#34828
  LDI r3,#64
STR r0,r3
  LDI r3,#68
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  PUSH r0
  LDI r2,#132
LDR r0,r2
  LDI r3,#68
STR r0,r3
  LDRW r0,#34828
  LDI r3,#64
STR r0,r3
  LDI r3,#68
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il37
  LDI r0,#0
  JMP il38
il37:
  LDI r0,#1
il38:
  LDI r1,#0
  CMP r0,r1
  JZ il36
  LDI r0,#1
il36:
  LDI r1,#0
  CMP r0,r1
  JZ il35
  LDI r0,#1
il35:
  LDI r1,#0
  CMP r0,r1
  JZ il34
  JMP il33
il34:
  LDI r2,#128
LDR r0,r2
  LDI r3,#68
STR r0,r3
  LDRW r0,#34828
  LDI r3,#64
STR r0,r3
  LDI r3,#68
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  PUSH r0
  LDI r2,#132
LDR r0,r2
  LDI r3,#68
STR r0,r3
  LDRW r0,#34828
  LDI r3,#64
STR r0,r3
  LDI r3,#68
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il41
  LDI r0,#0
  JMP il42
il41:
  LDI r0,#1
il42:
  LDI r1,#0
  CMP r0,r1
  JZ il39
  JMP il40
il39:
il40:
  LDI r0,#1
  JMP fn_exit32
  LDI r0,#0
  JMP fn_exit32
fn_exit32:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
oc:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  LDRW r0,#34824
  PUSH r0
  LDI r0,#4095
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il46
  LDI r0,#1
  JS il47
il46:
  LDI r0,#0
il47:
  LDI r1,#0
  CMP r0,r1
  JZ il44
  JMP il45
il44:
il45:
  LDRW r0,#34824
  ADD r0,r0
  ADD r0,r0
  LDI r1,#8
  LDI r4,#72
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  PUSH r1
  LDI r2,#128
LDR r0,r2
  POP r1
  STR r0,r1
  LDRW r0,#34824
  INC r0
  STRW r0,#34824
  LDRW r0,#34824
  ADD r0,r0
  ADD r0,r0
  LDI r1,#8
  LDI r4,#72
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  PUSH r1
  LDI r0,#0
  POP r1
  STR r0,r1
fn_exit43:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
os:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
il49:
  LDI r2,#128
LDR r0,r2
  LDI r3,#68
STR r0,r3
  LDRW r0,#34832
  PUSH r0
  LDI r0,#4
  MOV r1,r0
  POP r0
  MUL r0,r1
  LDI r3,#64
STR r0,r3
  LDI r3,#68
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  LDI r1,#0
  CMP r0,r1
  JZ il50
  LDI r2,#128
LDR r0,r2
  LDI r3,#68
STR r0,r3
  LDRW r0,#34832
  PUSH r0
  LDI r0,#4
  MOV r1,r0
  POP r0
  MUL r0,r1
  LDI r3,#64
STR r0,r3
  LDI r3,#68
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  LDI r3,#40
STR r0,r3
  LDRW r0,#128
  STRW r0,#80
  LDRW r0,#132
  STRW r0,#84
  LDRW r0,#136
  STRW r0,#88
  LDRW r0,#140
  STRW r0,#92
  LDI r3,#40
LDR r0,r3
  LDI r3,#128
STR r0,r3
  CALL oc
  LDRW r0,#80
  STRW r0,#128
  LDRW r0,#84
  STRW r0,#132
  LDRW r0,#88
  STRW r0,#136
  LDRW r0,#92
  STRW r0,#140
  LDRW r0,#34832
  INC r0
  STRW r0,#34832
  JMP il49
il50:
fn_exit48:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
on:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  LDI r0,#14
  ADD r0,r0
  ADD r0,r0
  LDI r1,#20
  LDI r4,#136
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  PUSH r1
  LDI r0,#0
  POP r1
  STR r0,r1
  LDI r0,#15
  ADD r0,r0
  ADD r0,r0
  LDI r1,#20
  LDI r4,#136
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  PUSH r1
  LDI r0,#0
  POP r1
  STR r0,r1
il52:
  LDI r2,#128
LDR r0,r2
  PUSH r0
  LDI r0,#0
  LDI r1,#0
  CMP r0,r1
  JZ il56
  LDRW r0,#34900
  PUSH r0
  LDI r0,#0
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il57
  JS il57
  LDI r0,#1
  JMP il58
il57:
  LDI r0,#0
il58:
  LDI r1,#0
  CMP r0,r1
  JZ il56
  LDI r0,#1
il56:
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il54
  JS il54
  LDI r0,#1
  JMP il55
il54:
  LDI r0,#0
il55:
  LDI r1,#0
  CMP r0,r1
  JZ il53
  LDI r2,#128
LDR r0,r2
  PUSH r0
  LDI r0,#10
  MOV r1,r0
  POP r0
  DIV r0,r1
  LDI r3,#128
STR r0,r3
  JMP il52
il53:
  LDRW r0,#34900
  PUSH r0
  LDI r0,#14
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il61
  LDI r0,#0
  JMP il62
il61:
  LDI r0,#1
il62:
  LDI r1,#0
  CMP r0,r1
  JZ il59
  LDI r0,#48
  LDI r3,#40
STR r0,r3
  LDRW r0,#128
  STRW r0,#80
  LDRW r0,#132
  STRW r0,#84
  LDRW r0,#136
  STRW r0,#88
  LDRW r0,#140
  STRW r0,#92
  LDI r3,#40
LDR r0,r3
  LDI r3,#128
STR r0,r3
  CALL oc
  LDRW r0,#80
  STRW r0,#128
  LDRW r0,#84
  STRW r0,#132
  LDRW r0,#88
  STRW r0,#136
  LDRW r0,#92
  STRW r0,#140
  JMP fn_exit51
  JMP il60
il59:
il60:
il63:
  LDRW r0,#34900
  ADD r0,r0
  ADD r0,r0
  LDI r1,#20
  LDI r4,#136
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  LDR r0,r1
  LDI r1,#0
  CMP r0,r1
  JZ il64
  LDRW r0,#34900
  ADD r0,r0
  ADD r0,r0
  LDI r1,#20
  LDI r4,#136
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  LDR r0,r1
  LDI r3,#40
STR r0,r3
  LDRW r0,#128
  STRW r0,#80
  LDRW r0,#132
  STRW r0,#84
  LDRW r0,#136
  STRW r0,#88
  LDRW r0,#140
  STRW r0,#92
  LDI r3,#40
LDR r0,r3
  LDI r3,#128
STR r0,r3
  CALL oc
  LDRW r0,#80
  STRW r0,#128
  LDRW r0,#84
  STRW r0,#132
  LDRW r0,#88
  STRW r0,#136
  LDRW r0,#92
  STRW r0,#140
  LDRW r0,#34900
  INC r0
  STRW r0,#34900
  JMP il63
il64:
fn_exit51:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
lex:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  LDI r0,#0
  STRW r0,#34908
  LDI r0,#0
  STRW r0,#17408
il66:
  LDRW r0,#34908
  ADD r0,r0
  ADD r0,r0
  LDI r1,#8
  LDI r4,#68
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  LDR r0,r1
  LDI r1,#0
  CMP r0,r1
  JZ il68
  LDRW r0,#17408
  PUSH r0
  LDI r0,#128
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il69
  LDI r0,#1
  JS il70
il69:
  LDI r0,#0
il70:
  LDI r1,#0
  CMP r0,r1
  JZ il68
  LDI r0,#1
il68:
  LDI r1,#0
  CMP r0,r1
  JZ il67
il71:
  LDI r0,#1
  LDI r1,#0
  CMP r0,r1
  JZ il72
  LDRW r0,#34908
  ADD r0,r0
  ADD r0,r0
  LDI r1,#8
  LDI r4,#68
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  LDR r0,r1
  PUSH r0
  LDI r0,#32
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il75
  LDI r0,#0
  JMP il76
il75:
  LDI r0,#1
il76:
  LDI r1,#0
  CMP r0,r1
  JZ il73
  LDRW r0,#34908
  INC r0
  STRW r0,#34908
  JMP il71
  JMP il74
il73:
il74:
  LDRW r0,#34908
  ADD r0,r0
  ADD r0,r0
  LDI r1,#8
  LDI r4,#68
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  LDR r0,r1
  PUSH r0
  LDI r0,#10
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il79
  LDI r0,#0
  JMP il80
il79:
  LDI r0,#1
il80:
  LDI r1,#0
  CMP r0,r1
  JZ il77
  LDRW r0,#34908
  INC r0
  STRW r0,#34908
  JMP il71
  JMP il78
il77:
il78:
  LDRW r0,#34908
  ADD r0,r0
  ADD r0,r0
  LDI r1,#8
  LDI r4,#68
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  LDR r0,r1
  PUSH r0
  LDI r0,#9
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il83
  LDI r0,#0
  JMP il84
il83:
  LDI r0,#1
il84:
  LDI r1,#0
  CMP r0,r1
  JZ il81
  LDRW r0,#34908
  INC r0
  STRW r0,#34908
  JMP il71
  JMP il82
il81:
il82:
  LDRW r0,#34908
  ADD r0,r0
  ADD r0,r0
  LDI r1,#8
  LDI r4,#68
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  LDR r0,r1
  PUSH r0
  LDI r0,#13
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il87
  LDI r0,#0
  JMP il88
il87:
  LDI r0,#1
il88:
  LDI r1,#0
  CMP r0,r1
  JZ il85
  LDRW r0,#34908
  INC r0
  STRW r0,#34908
  JMP il71
  JMP il86
il85:
il86:
  JMP il72
  JMP il71
il72:
  LDRW r0,#34908
  ADD r0,r0
  ADD r0,r0
  LDI r1,#8
  LDI r4,#68
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  LDR r0,r1
  PUSH r0
  LDI r0,#0
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il91
  LDI r0,#0
  JMP il92
il91:
  LDI r0,#1
il92:
  LDI r1,#0
  CMP r0,r1
  JZ il89
  LDI r0,#128
  STRW r0,#17408
  JMP il66
  JMP il90
il89:
il90:
  LDRW r0,#34908
  LDRW r0,#34912
  PUSH r0
  LDI r0,#40
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il95
  LDI r0,#0
  JMP il96
il95:
  LDI r0,#1
il96:
  LDI r1,#0
  CMP r0,r1
  JZ il93
  LDRW r0,#17408
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  PUSH r1
  LDI r0,#8
  POP r1
  STR r0,r1
  LDRW r0,#34908
  INC r0
  STRW r0,#34908
  JMP il94
il93:
il94:
  LDRW r0,#34912
  PUSH r0
  LDI r0,#41
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il99
  LDI r0,#0
  JMP il100
il99:
  LDI r0,#1
il100:
  LDI r1,#0
  CMP r0,r1
  JZ il97
  LDRW r0,#17408
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  PUSH r1
  LDI r0,#9
  POP r1
  STR r0,r1
  LDRW r0,#34908
  INC r0
  STRW r0,#34908
  JMP il98
il97:
il98:
  LDRW r0,#34912
  PUSH r0
  LDI r0,#123
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il103
  LDI r0,#0
  JMP il104
il103:
  LDI r0,#1
il104:
  LDI r1,#0
  CMP r0,r1
  JZ il101
  LDRW r0,#17408
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  PUSH r1
  LDI r0,#10
  POP r1
  STR r0,r1
  LDRW r0,#34908
  INC r0
  STRW r0,#34908
  JMP il102
il101:
il102:
  LDRW r0,#34912
  PUSH r0
  LDI r0,#125
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il107
  LDI r0,#0
  JMP il108
il107:
  LDI r0,#1
il108:
  LDI r1,#0
  CMP r0,r1
  JZ il105
  LDRW r0,#17408
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  PUSH r1
  LDI r0,#11
  POP r1
  STR r0,r1
  LDRW r0,#34908
  INC r0
  STRW r0,#34908
  JMP il106
il105:
il106:
  LDRW r0,#34912
  PUSH r0
  LDI r0,#59
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il111
  LDI r0,#0
  JMP il112
il111:
  LDI r0,#1
il112:
  LDI r1,#0
  CMP r0,r1
  JZ il109
  LDRW r0,#17408
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  PUSH r1
  LDI r0,#12
  POP r1
  STR r0,r1
  LDRW r0,#34908
  INC r0
  STRW r0,#34908
  JMP il110
il109:
il110:
  LDRW r0,#34912
  PUSH r0
  LDI r0,#61
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il115
  LDI r0,#0
  JMP il116
il115:
  LDI r0,#1
il116:
  LDI r1,#0
  CMP r0,r1
  JZ il113
  LDRW r0,#17408
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  PUSH r1
  LDI r0,#13
  POP r1
  STR r0,r1
  LDRW r0,#34908
  INC r0
  STRW r0,#34908
  JMP il114
il113:
il114:
  LDRW r0,#34912
  PUSH r0
  LDI r0,#43
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il119
  LDI r0,#0
  JMP il120
il119:
  LDI r0,#1
il120:
  LDI r1,#0
  CMP r0,r1
  JZ il117
  LDRW r0,#17408
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  PUSH r1
  LDI r0,#14
  POP r1
  STR r0,r1
  LDRW r0,#34908
  INC r0
  STRW r0,#34908
  JMP il118
il117:
il118:
  LDRW r0,#34912
  PUSH r0
  LDI r0,#45
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il123
  LDI r0,#0
  JMP il124
il123:
  LDI r0,#1
il124:
  LDI r1,#0
  CMP r0,r1
  JZ il121
  LDRW r0,#17408
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  PUSH r1
  LDI r0,#15
  POP r1
  STR r0,r1
  LDRW r0,#34908
  INC r0
  STRW r0,#34908
  JMP il122
il121:
il122:
  LDRW r0,#34912
  PUSH r0
  LDI r0,#42
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il127
  LDI r0,#0
  JMP il128
il127:
  LDI r0,#1
il128:
  LDI r1,#0
  CMP r0,r1
  JZ il125
  LDRW r0,#17408
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  PUSH r1
  LDI r0,#16
  POP r1
  STR r0,r1
  LDRW r0,#34908
  INC r0
  STRW r0,#34908
  JMP il126
il125:
il126:
  LDRW r0,#34912
  LDI r3,#40
STR r0,r3
  LDRW r0,#128
  STRW r0,#80
  LDRW r0,#132
  STRW r0,#84
  LDRW r0,#136
  STRW r0,#88
  LDRW r0,#140
  STRW r0,#92
  LDI r3,#40
LDR r0,r3
  LDI r3,#128
STR r0,r3
  CALL isdig
  LDRW r0,#80
  STRW r0,#128
  LDRW r0,#84
  STRW r0,#132
  LDRW r0,#88
  STRW r0,#136
  LDRW r0,#92
  STRW r0,#140
  LDI r1,#0
  CMP r0,r1
  JZ il129
  LDRW r0,#17408
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  PUSH r1
  LDI r0,#7
  POP r1
  STR r0,r1
  LDRW r0,#17408
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  LDI r4,#2
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  PUSH r1
  LDI r0,#0
  POP r1
  STR r0,r1
il131:
  LDRW r0,#34908
  ADD r0,r0
  ADD r0,r0
  LDI r1,#8
  LDI r4,#68
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  LDR r0,r1
  LDI r3,#40
STR r0,r3
  LDRW r0,#128
  STRW r0,#80
  LDRW r0,#132
  STRW r0,#84
  LDRW r0,#136
  STRW r0,#88
  LDRW r0,#140
  STRW r0,#92
  LDI r3,#40
LDR r0,r3
  LDI r3,#128
STR r0,r3
  CALL isdig
  LDRW r0,#80
  STRW r0,#128
  LDRW r0,#84
  STRW r0,#132
  LDRW r0,#88
  STRW r0,#136
  LDRW r0,#92
  STRW r0,#140
  LDI r1,#0
  CMP r0,r1
  JZ il132
  LDRW r0,#17408
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  LDI r4,#2
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  PUSH r1
  LDRW r0,#17408
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  LDI r4,#2
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  LDR r0,r1
  PUSH r0
  LDI r0,#10
  PUSH r0
  LDRW r0,#34908
  ADD r0,r0
  ADD r0,r0
  LDI r1,#8
  LDI r4,#68
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  LDR r0,r1
  PUSH r0
  LDI r0,#48
  MOV r1,r0
  POP r0
  SUB r0,r1
  MOV r1,r0
  POP r0
  ADD r0,r1
  MOV r1,r0
  POP r0
  MUL r0,r1
  POP r1
  STR r0,r1
  LDRW r0,#34908
  INC r0
  STRW r0,#34908
  JMP il131
il132:
  JMP il130
il129:
il130:
  LDRW r0,#34912
  LDI r3,#40
STR r0,r3
  LDRW r0,#128
  STRW r0,#80
  LDRW r0,#132
  STRW r0,#84
  LDRW r0,#136
  STRW r0,#88
  LDRW r0,#140
  STRW r0,#92
  LDI r3,#40
LDR r0,r3
  LDI r3,#128
STR r0,r3
  CALL isidc
  LDRW r0,#80
  STRW r0,#128
  LDRW r0,#84
  STRW r0,#132
  LDRW r0,#88
  STRW r0,#136
  LDRW r0,#92
  STRW r0,#140
  LDI r1,#0
  CMP r0,r1
  JZ il133
  LDI r0,#0
  STRW r0,#34916
il135:
  LDRW r0,#34908
  ADD r0,r0
  ADD r0,r0
  LDI r1,#8
  LDI r4,#68
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  LDR r0,r1
  LDI r3,#40
STR r0,r3
  LDRW r0,#128
  STRW r0,#80
  LDRW r0,#132
  STRW r0,#84
  LDRW r0,#136
  STRW r0,#88
  LDRW r0,#140
  STRW r0,#92
  LDI r3,#40
LDR r0,r3
  LDI r3,#128
STR r0,r3
  CALL isan
  LDRW r0,#80
  STRW r0,#128
  LDRW r0,#84
  STRW r0,#132
  LDRW r0,#88
  STRW r0,#136
  LDRW r0,#92
  STRW r0,#140
  LDI r1,#0
  CMP r0,r1
  JNZ il137
  LDRW r0,#34908
  ADD r0,r0
  ADD r0,r0
  LDI r1,#8
  LDI r4,#68
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  LDR r0,r1
  PUSH r0
  LDI r0,#95
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il139
  LDI r0,#0
  JMP il140
il139:
  LDI r0,#1
il140:
  LDI r1,#0
  CMP r0,r1
  JNZ il137
  LDI r0,#0
  JMP il138
il137:
  LDI r0,#1
il138:
  LDI r1,#0
  CMP r0,r1
  JZ il136
  LDRW r0,#34916
  PUSH r0
  LDI r0,#31
  MOV r1,r0
  POP r0
  CMP r0,r1
  JZ il143
  LDI r0,#1
  JS il144
il143:
  LDI r0,#0
il144:
  LDI r1,#0
  CMP r0,r1
  JZ il141
  LDRW r0,#17408
  ADD r0,r0
  ADD r0,r0
  ADD r0,r0
  ADD r0,r0
  ADD r0,r0
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  LDI r4,#4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  LDI r3,#60
STR r1,r3
  LDRW r0,#34916
  ADD r0,r0
  ADD r0,r0
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  PUSH r0
  LDRW r0,#34908
  ADD r0,r0
  ADD r0,r0
  LDI r1,#8
  LDI r4,#68
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  LDR r0,r1
  POP r1
  STR r0,r1
  LDRW r0,#34916
  INC r0
  STRW r0,#34916
  JMP il142
il141:
il142:
  LDRW r0,#34908
  INC r0
  STRW r0,#34908
  JMP il135
il136:
  LDRW r0,#17408
  ADD r0,r0
  ADD r0,r0
  ADD r0,r0
  ADD r0,r0
  ADD r0,r0
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  LDI r4,#4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  LDI r3,#60
STR r1,r3
  LDRW r0,#34916
  ADD r0,r0
  ADD r0,r0
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  PUSH r0
  LDI r0,#0
  POP r1
  STR r0,r1
  LDRW r0,#17408
  ADD r0,r0
  ADD r0,r0
  ADD r0,r0
  ADD r0,r0
  ADD r0,r0
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  LDI r4,#4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  MOV r0,r1
  LDI r3,#40
STR r0,r3
  LDI r0,#105
  STRW r0,#34920
  LDI r0,#110
  STRW r0,#34924
  LDI r0,#116
  STRW r0,#34928
  LDI r0,#0
  STRW r0,#34932
  LDI r0,#104
  LDI r4,#136
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r0,r4
  LDI r3,#44
STR r0,r3
  LDRW r0,#128
  STRW r0,#80
  LDRW r0,#132
  STRW r0,#84
  LDRW r0,#136
  STRW r0,#88
  LDRW r0,#140
  STRW r0,#92
  LDI r3,#40
LDR r0,r3
  LDI r3,#128
STR r0,r3
  LDI r3,#44
LDR r0,r3
  LDI r3,#132
STR r0,r3
  CALL seq
  LDRW r0,#80
  STRW r0,#128
  LDRW r0,#84
  STRW r0,#132
  LDRW r0,#88
  STRW r0,#136
  LDRW r0,#92
  STRW r0,#140
  LDI r1,#0
  CMP r0,r1
  JZ il145
  JMP il146
il145:
il146:
  LDRW r0,#17408
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  PUSH r1
  LDI r0,#1
  POP r1
  STR r0,r1
  LDRW r0,#17408
  ADD r0,r0
  ADD r0,r0
  ADD r0,r0
  ADD r0,r0
  ADD r0,r0
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  LDI r4,#4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  MOV r0,r1
  LDI r3,#40
STR r0,r3
  LDI r0,#114
  STRW r0,#34936
  LDI r0,#101
  STRW r0,#34940
  LDI r0,#116
  STRW r0,#34944
  LDI r0,#117
  STRW r0,#34948
  LDI r0,#114
  STRW r0,#34952
  LDI r0,#110
  STRW r0,#34956
  LDI r0,#0
  STRW r0,#34960
  LDI r0,#120
  LDI r4,#136
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r0,r4
  LDI r3,#44
STR r0,r3
  LDRW r0,#128
  STRW r0,#80
  LDRW r0,#132
  STRW r0,#84
  LDRW r0,#136
  STRW r0,#88
  LDRW r0,#140
  STRW r0,#92
  LDI r3,#40
LDR r0,r3
  LDI r3,#128
STR r0,r3
  LDI r3,#44
LDR r0,r3
  LDI r3,#132
STR r0,r3
  CALL seq
  LDRW r0,#80
  STRW r0,#128
  LDRW r0,#84
  STRW r0,#132
  LDRW r0,#88
  STRW r0,#136
  LDRW r0,#92
  STRW r0,#140
  LDI r1,#0
  CMP r0,r1
  JZ il147
  JMP il148
il147:
il148:
  LDRW r0,#17408
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  PUSH r1
  LDI r0,#2
  POP r1
  STR r0,r1
  LDRW r0,#17408
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  PUSH r1
  LDI r0,#6
  POP r1
  STR r0,r1
  JMP il134
il133:
il134:
  LDRW r0,#34908
  INC r0
  STRW r0,#34908
  LDRW r0,#17408
  INC r0
  STRW r0,#17408
  JMP il66
il67:
  LDRW r0,#17408
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  PUSH r1
  LDI r0,#0
  POP r1
  STR r0,r1
fn_exit65:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
scp_src:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  LDI r0,#0
  STRW r0,#34964
il150:
  LDI r2,#128
LDR r0,r2
  LDI r3,#68
STR r0,r3
  LDRW r0,#34964
  PUSH r0
  LDI r0,#4
  MOV r1,r0
  POP r0
  MUL r0,r1
  LDI r3,#64
STR r0,r3
  LDI r3,#68
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  LDI r1,#0
  CMP r0,r1
  JZ il151
  LDRW r0,#34964
  ADD r0,r0
  ADD r0,r0
  LDI r1,#8
  LDI r4,#68
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  PUSH r1
  LDI r2,#128
LDR r0,r2
  LDI r3,#68
STR r0,r3
  LDRW r0,#34964
  PUSH r0
  LDI r0,#4
  MOV r1,r0
  POP r0
  MUL r0,r1
  LDI r3,#64
STR r0,r3
  LDI r3,#68
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  ADD r0,r1
  LDR r0,r0
  POP r1
  STR r0,r1
  LDRW r0,#34964
  INC r0
  STRW r0,#34964
  JMP il150
il151:
  LDRW r0,#34964
  ADD r0,r0
  ADD r0,r0
  LDI r1,#8
  LDI r4,#68
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r1,r4
  ADD r1,r0
  PUSH r1
  LDI r0,#0
  POP r1
  STR r0,r1
fn_exit149:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
main_entry:
  LDI r0,#105
  STRW r0,#34968
  LDI r0,#110
  STRW r0,#34972
  LDI r0,#116
  STRW r0,#34976
  LDI r0,#32
  STRW r0,#34980
  LDI r0,#109
  STRW r0,#34984
  LDI r0,#97
  STRW r0,#34988
  LDI r0,#105
  STRW r0,#34992
  LDI r0,#110
  STRW r0,#34996
  LDI r0,#40
  STRW r0,#35000
  LDI r0,#118
  STRW r0,#35004
  LDI r0,#111
  STRW r0,#35008
  LDI r0,#105
  STRW r0,#35012
  LDI r0,#100
  STRW r0,#35016
  LDI r0,#41
  STRW r0,#35020
  LDI r0,#123
  STRW r0,#35024
  LDI r0,#105
  STRW r0,#35028
  LDI r0,#110
  STRW r0,#35032
  LDI r0,#116
  STRW r0,#35036
  LDI r0,#32
  STRW r0,#35040
  LDI r0,#97
  STRW r0,#35044
  LDI r0,#59
  STRW r0,#35048
  LDI r0,#97
  STRW r0,#35052
  LDI r0,#61
  STRW r0,#35056
  LDI r0,#52
  STRW r0,#35060
  LDI r0,#50
  STRW r0,#35064
  LDI r0,#59
  STRW r0,#35068
  LDI r0,#114
  STRW r0,#35072
  LDI r0,#101
  STRW r0,#35076
  LDI r0,#116
  STRW r0,#35080
  LDI r0,#117
  STRW r0,#35084
  LDI r0,#114
  STRW r0,#35088
  LDI r0,#110
  STRW r0,#35092
  LDI r0,#32
  STRW r0,#35096
  LDI r0,#97
  STRW r0,#35100
  LDI r0,#59
  STRW r0,#35104
  LDI r0,#125
  STRW r0,#35108
  LDI r0,#0
  STRW r0,#35112
  LDI r0,#152
  LDI r4,#136
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r4,r4
  ADD r0,r4
  LDI r3,#40
STR r0,r3
  LDRW r0,#128
  STRW r0,#80
  LDRW r0,#132
  STRW r0,#84
  LDRW r0,#136
  STRW r0,#88
  LDRW r0,#140
  STRW r0,#92
  LDI r3,#40
LDR r0,r3
  LDI r3,#128
STR r0,r3
  CALL scp_src
  LDRW r0,#80
  STRW r0,#128
  LDRW r0,#84
  STRW r0,#132
  LDRW r0,#88
  STRW r0,#136
  LDRW r0,#92
  STRW r0,#140
  LDRW r0,#128
  STRW r0,#80
  LDRW r0,#132
  STRW r0,#84
  LDRW r0,#136
  STRW r0,#88
  LDRW r0,#140
  STRW r0,#92
  CALL lex
  LDRW r0,#80
  STRW r0,#128
  LDRW r0,#84
  STRW r0,#132
  LDRW r0,#88
  STRW r0,#136
  LDRW r0,#92
  STRW r0,#140
  LDI r0,#0
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  LDR r0,r1
  PUSH r0
  LDI r0,#100
  PUSH r0
  LDI r0,#1
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  LDR r0,r1
  PUSH r0
  LDI r0,#10
  PUSH r0
  LDI r0,#2
  ADD r0,r0
  ADD r0,r0
  LDI r1,#0
  ADD r1,r0
  LDR r0,r1
  MOV r1,r0
  POP r0
  ADD r0,r1
  MOV r1,r0
  POP r0
  MUL r0,r1
  MOV r1,r0
  POP r0
  ADD r0,r1
  MOV r1,r0
  POP r0
  MUL r0,r1
  HLT
  HLT
printnum_sub:
  PUSH r0
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  MOV r1, r0
  LDI r2, #100
  LDI r3, #0
pn_hun152:
  CMP r1, r2
  JS pn_ten153
  SUB r1, r2
  LDI r0, #1
  ADD r3, r0
  JMP pn_hun152
pn_ten153:
  MOV r4, r1
  LDI r2, #10
  LDI r1, #0
pn_ten2154:
  CMP r4, r2
  JS pn_uni
  SUB r4, r2
  LDI r0, #1
  ADD r1, r0
  JMP pn_ten2154
pn_uni:
  PUSH r1
  LDI r0, #0
  CMP r3, r0
  JZ pn_skip_h155
  LDI r0, #48
  ADD r0, r3
  MOV r1, r0
  LDI r0, #0
  SYSCALL
pn_skip_h155:
  POP r1
  PUSH r1
  LDI r0, #0
  CMP r3, r0
  JZ pn_chk_ten156
  JMP pn_prt_ten157
pn_chk_ten156:
  LDI r0, #0
  CMP r1, r0
  JZ pn_skip_t157
pn_prt_ten157:
  LDI r0, #48
  ADD r0, r1
  MOV r1, r0
  LDI r0, #0
  SYSCALL
pn_skip_t157:
  POP r1
  MOV r0, r4
  LDI r1, #48
  ADD r0, r1
  MOV r1, r0
  LDI r0, #0
  SYSCALL
  POP r4
  POP r3
  POP r2
  POP r1
  POP r0
  RET
strcmp_sub:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  LDI r2,#128
LDR r1,r2
  LDI r2,#132
LDR r2,r2
sc_lp:
  LDR r3,r1
  LDR r4,r2
  CMP r3,r4
  JNZ sc_ne
  LDI r4,#0
  CMP r3,r4
  JZ sc_eq
  LDI r4,#4
  ADD r1,r4
  ADD r2,r4
  JMP sc_lp
sc_ne:
  LDI r0,#1
  JMP sc_ex
sc_eq:
  LDI r0,#0
sc_ex:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
strncpy_sub:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  LDI r2,#128
LDR r1,r2
  LDI r2,#132
LDR r2,r2
  LDI r4,#136
LDR r4,r4
sn_lp:
  LDI r3,#0
  CMP r4,r3
  JZ sn_ex
  LDR r3,r2
  STR r3,r1
  LDI r3,#4
  ADD r1,r3
  ADD r2,r3
  LDI r3,#1
  SUB r4,r3
  JMP sn_lp
sn_ex:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
memset_sub:
  PUSH r1
  PUSH r2
  PUSH r3
  LDI r2,#128
LDR r1,r2
  LDI r2,#132
LDR r2,r2
  LDI r3,#136
LDR r3,r3
ms_lp:
  LDI r0,#0
  CMP r3,r0
  JZ ms_ex
  STR r2,r1
  LDI r0,#4
  ADD r1,r0
  SUB r3,r0
  JMP ms_lp
ms_ex:
  POP r3
  POP r2
  POP r1
  RET
; pp=1719 tok=944
