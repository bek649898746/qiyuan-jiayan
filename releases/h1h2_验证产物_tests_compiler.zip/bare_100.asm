  JMP main_entry
  JMP main_entry
isdig:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  LDI r2,#128
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r0,#47
  LDI r1,#0
  CMP r0,r1
  JZ il5
  LDI r2,#128
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r0,#58
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il6
  LDI r0,#1
  JS il7
il6:
  LDI r0,#0
il7:
  LDI r1,#0
  CMP r0,r1
  JZ il5
  LDI r0,#1
il5:
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il3
  JS il3
  LDI r0,#1
  JMP il4
il3:
  LDI r0,#0
il4:
  LDI r1,#0
  CMP r0,r1
  JZ il1
  JMP il2
il1:
il2:
  LDI r0,#1
  JMP fn_exit0
  LDI r0,#0
  JMP fn_exit0
fn_exit0:
  POP r4
  POP r3
  POP r2
  POP r1
  RET
isidc:
  PUSH r1
  PUSH r2
  PUSH r3
  PUSH r4
  LDI r2,#128
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r0,#96
  LDI r1,#0
  CMP r0,r1
  JZ il13
  LDI r2,#128
LDR r0,r2
  LDI r3,#60
STR r0,r3
  LDI r0,#123
  LDI r3,#64
STR r0,r3
  LDI r3,#60
LDR r0,r3
  LDI r3,#64
LDR r1,r3
  CMP r0,r1
  JZ il14
  LDI r0,#1
  JS il15
il14:
  LDI r0,#0
il15:
  LDI r1,#0
