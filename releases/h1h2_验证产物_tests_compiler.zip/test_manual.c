char src[512];char dbuf[256];int di;
void doc(int c){if(di<255)dbuf[di]=c;di++;dbuf[di]=0;}
int main(void){
 int i=0;
 /* manually copy "int" at stride-4 */
 src[0]=105;src[4]=110;src[8]=116;src[12]=0;
 /* Now check: src[0] should be 'i' */
 di=0;doc(src[0]);doc(src[4]);doc(src[8]);
 putstr(dbuf);
 return 0;
}
